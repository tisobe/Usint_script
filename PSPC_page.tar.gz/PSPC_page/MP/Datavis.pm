package MP::Datavis;

=head1 NAME

MP::Datavis

=head1 PURPOSE

A Perl Extension to parse data from Datavis files.

=head1 SYNOPSIS

  use MP::Datavis;
  ($Coords,$StarFid) = read_datavis($datavis);

=head1 DESCRIPTION

This module supplies one routine: read_datavis() which reads datavis files.  

The datavis file contains information about the target to be observed and the guide stars, aquisition stars, monitor stars and fid lights for the target.  The datavis file has two sections:

=over 

=item * 

a) Contains sequence number, RA, Dec and roll for the target

=item *

b) Contains star type (i.e. aquisition star, guide star, fid light, monitor star), ID number (not the same as obisd), RA, Dec and mag_aca.

=item *

For a):  read_datavis returns hash named DVcoords keyed by 'ra', 'dec', and 'roll' (with the values corresponding to the key names).

=item *

For b): read_datavis returns hash named StarFid.  Keyed by type of star.  Sub hash keyed by ID number, in turn keyed by 'ra', 'dec', and 'mag' (with values corresponding to the key names).

=back

=head2 EXPORTS
    
  read_datavis()

=head2 Methods

=over 8

=item read_datavis

I<Usage>: 

    my ($Coords,$StarFid) = read_datavis($datavis);

I<Provides>: Given a datavis file returns two hashes one keyed by 'ra', 'dec', and 'roll' (with the values corresponding to the key names) and one keyed by type of star.  Sub hash keyed by ID number, in turn keyed by 'ra', 'dec', and 'mag' (with values corresponding to the key names). 

I<Arguments>:

    $datavis = the Datavis file.

I<Output>:

Coords (hash): 
key: ra, value: RA in degrees.
key: dec, value: Dec in degrees.
key: roll, value: Roll in degrees.

StarFid (hash):
keys (hash) - type of star (i.e. aquisition star, guide star, fid light, monitor star):
id (hash) - star ID number (not the same as obisd):
key: ra, value: RA in degrees.
key: dec, value: Dec in degrees.
key: mag, value: Magnitude.

I<Examples>:

  my ($Coords,$StarFid) = read_datavis($datavis);
  print "ra: $Coords->{ra}\n";
  print "dec: $Coords->{dec}\n";
  print "roll: $Coords->{roll}\n";
  foreach my $keys (keys %{$StarFid}){
    print "$keys stars:\n";
    foreach my $id (keys %{$StarFid->{$keys}}){
        print "ID: $id, ";
	print "RA:  $StarFid->{$keys}->{$id}{ra}, ";
	print "Dec: $StarFid->{$keys}->{$id}{dec}, ";
	print "Mag: $StarFid->{$keys}->{$id}{mag}\n";
    }
  }


=back


=head1 EXAMPLES

=over 8 

=item read_datavis

  use MP::Datavis;
  my $datavis = '/data/mp1/SEQNBR/100000/100000.datavis';
  my ($Coords,$StarFid) = read_datavis($datavis);
  print "ra: $Coords->{ra}\n";
  print "dec: $Coords->{dec}\n";
  print "roll: $Coords->{roll}\n";
  foreach my $keys (keys %{$StarFid}){
    print "$keys stars:\n";
    foreach my $id (keys %{$StarFid->{$keys}}){
        print "ID: $id, ";
	print "RA:  $StarFid->{$keys}->{$id}{ra}, ";
	print "Dec: $StarFid->{$keys}->{$id}{dec}, ";
	print "Mag: $StarFid->{$keys}->{$id}{mag}\n";
    }
  }


=back

=head1 NOTES


=head1 DEPENDENCIES

  use strict;
  use Carp;
  use warnings;

  require Exporter;
  use AutoLoader qw(AUTOLOAD);

=head1 VERSION

$Revision: 1.2 $

=head1 AUTHOR

Author:  K Eriksen; rel 9/10/2003

  Last Update:    $Date: 2006/11/20 14:20:58 $ 
  Last Update by: $Author: kkingsbury $


=head1 HISTORY

=over 8

=item Ver: 1.2

- Updated POD, imported into CVS control.

kkingsbury - 11/20/2006


=item Ver: 1.1

Initial revision

K Eriksen - 7/12/2001 

=back

=cut
########################################################################
#                        START CODE                                    #
########################################################################

require 5.005_62;
use strict;
use Carp;
use warnings;

require Exporter;
use AutoLoader qw(AUTOLOAD);

our @ISA = qw(Exporter);
our @EXPORT = qw( &read_datavis );

our $VERSION = '1.2';

my %Key = ( 0, 'acq', 1, 'gui', 2, 'fid', '3', 'mon' );

sub read_datavis {
    my ($datavis) = @_;
    local $_;
   
    my (%StarFid,%DVcoords,$ra,$dec,$roll,$mag,$id);

    open(DATAVIS,"$datavis") or
        carp "Could not open datavis file $datavis. This is going to get messy.\n";
    while(<DATAVIS>){
        s/\s+//;
        if(!/^#/ && !/^$/){
           chop;
	   /(\w+)/;
           if($1 =~ /^(0|1|2|3)$/){
	       ($id,$ra,$dec) = (split)[1,2,3];
	       if( !defined( $mag = (split)[4] ) ){
		   $mag = '';
	       }
	       $StarFid{ $Key{$1} }{$id}{ra}  = $ra;
	       $StarFid{ $Key{$1} }{$id}{dec} = $dec;
	       $StarFid{ $Key{$1} }{$id}{mag} = $mag;
           } else{
	       ($ra,$dec,$roll) = (split)[1,2,3];
	       $DVcoords{ra}   = $ra;
	       $DVcoords{dec}  = $dec;
	       $DVcoords{roll} = $roll;
           }
       }
    }

    close(DATAVIS);
    return (\%DVcoords,\%StarFid);
}

1;
__END__

