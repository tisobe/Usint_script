package MP::Misc;

=head1 NAME

MP::Misc

=head1 PURPOSE

A Perl Extension to provide miscellaneous useful subroutines.

=head1 SYNOPSIS

 use MP::Misc;

 $diff_secs = diff_time($time_1, $time_2);
 $diff_secs = diff_week($week1, $week2);

 $seconds = relative2sec( $relative_time );
 $relative_time = sec2relative( $seconds );

 $chandra_time = absolute2chandra( $absolute_time );
 $absolute_time = chandra2absolute( $chandra_time );

 $mjd  = week2mjd($week);
 $week = mjd2week($mjd);
 $doy  = week2doy($week);
 $week = doy2week($doy, $year);
 $abs  = week2absolute($week);
 $week = absolute2week($abs);
 
 @sorted = sort {week_sort($a,$b)} @weeks

 $boolean = is_absolute( $absolute_time );
 $boolean = is_relative( $relative_time );

 ( $monday_year, $monday_doy ) = monday( $year, $doy );

 $separation = arcdegsep( $ra1, $dec1, $ra2, $dec2 );

 $eci_vector = eci( $ra, $dec );
 ( $ra, $dec ) = uneci( @$eci_vector );

 ( $ra, $dec ) = hms2deg( $hh, $mm, $ss, $dd, $dm, $ds );
 ($hh, $mm, $ss, $dd, $dm, $ds) = deg2hms( $ra, $dec );

 my @obsids = check_obsid(@obsids);

 print "true" if (is_numeric($test));

 ($degra, $degdec) = checkradec($degra, $degdec);
 ($hh, $mm, $ss, $dd, $dm, $ds) = checkradec($hh, $mm, $ss, $dd, $dm, $ds);
 
 print "Cal" if (is_caltarget($obs));

 my $obs = stripleadingzeroes($obsid);

=head1 DESCRIPTION

This module provides miscellaneous routines useful to mission planners.  Most have to do with either time conversions or angle manipulations.  The 'absolute' and 'relative' time formats are defined in the OP-19 document.

=head2 EXPORTS
    
  diff_time()
  relative2sec()
  sec2relative()
  absolute2chandra()
  chandra2absolute()
  week2mjd()
  mjd2week()
  week2doy()
  doy2week()
  week2absolute()
  absolute2week()
  diff_week()
  week_sort()
  is_absolute()
  is_relative()
  monday()
  arcdegsep()
  eci()
  uneci()
  hms2deg()
  deg2hms()
  drop_empty()
  trim()
  pitch_def()
  pitch_range()
  pitch_def_string()
  read_cyclefile()
  check_obsid()
  is_numeric()
  checkradec()  
  is_caltarget()
  stripleadingzeroes()  
  parse_tooddt()
  parse_coord()

=head2 Methods

=over 8

=item  diff_time

I<Usage>: 

    my $sec_diff = diff_time( $abs_time1, $abs_time2 );

I<Provides>: Subroutine to diff times in yyyy:ddd:hh:mm:ss.sss format.

I<Arguments>:
    
    time 1 = time in absolute format
    time 2 = time in absolute format

This subroutine assumes that hh:mm:ss is always provided.  Therefore, something like ddd:hh:mm:ss will work fine, but yyyy:ddd:hh:mm will not work properly.  Most predictable results are given when this subroutine is used in conjunction with the is_absolute() or the is_relative() test.

I<Output>:

Difference in seconds (if negative, time 1 is later than time 2).

I<Examples>:
    
    	print "\nDifference is: \n";
	my $sec  = abs( diff_time( $time1, $time2 ) );
	my $ksec = sprintf "%.3f", $sec/1000;
	print "   $ksec ksec\n";

=item  relative2sec

I<Usage>: 

    $seconds = relative2sec( $relative_time );

I<Provides>: Subroutine to convert times from relative time format to seconds.

I<Arguments>:
    
    time 1 = time in (ddd:)hh:mm:ss(.sss) format

I<Output>:

Time in seconds

I<Examples>:
    
    	print "\nDuration is: \n";
        $sec = relative2sec( $relative_time );
	my $ksec = sprintf "%.3f", $sec/1000;
	print "   $ksec ksec\n";

=item sec2relative

I<Usage>: 

    $relative_time = sec2relative( $seconds );

I<Provides>: Subroutine to unconvert times (ie. to go from seconds to relative time format)

I<Arguments>:
    
    time 1 = time in seconds

I<Output>:

time in ddd:hh:mm:ss.sss format

I<Examples>:
    
  $relative_time = sec2relative( $seconds );

=item absolute2chandra

I<Usage>: 

    $chandra_time = absolute2chandra( $absolute_time );
 

I<Provides>: Converts absolute times (see OP-19 definition, or is_absolute() below) to Chandra times (ie. seconds since Jan. 1, 1998 at midnight). 

I<Arguments>:
    
    $absolute_time = time in ddd:hh:mm:ss.sss format

I<Output>:

Chandra time (sec)

I<Examples>:
    
    $chandra_time = absolute2chandra( $absolute_time );


=item chandra2absolute

I<Usage>: 

    $chandra_time = absolute2chandra( $absolute_time );
 

I<Provides>: Converts Chandra times (ie. seconds since Jan. 1, 1998 at midnight) to absolute times (see OP-19 definition, or is_absolute() below).

I<Arguments>:
    
    $chandra_time = Chandra time (seconds since Jan. 1, 1998 at midnight). 

I<Output>:

Absolute Time in ddd:hh:mm:ss.sss format

I<Examples>:
    
    $absolute_time = chandra2absolute( $chandra_time );

=item week2mjd

I<Usage>: 

    $mjd  = week2mjd($week);

I<Provides>: converts time from MMMDDYY to MJD.

I<Arguments>:
    
    $week = Week in MMMDDYY format.

I<Output>:

Date, in MJD

I<Examples>:
    
 $mjd  = week2mjd($week);

=item  mjd2week

I<Usage>: 

    $week = mjd2week($mjd);

I<Provides>: converts time from MJD to MMMDDYY.

I<Arguments>:
    
    $mjd = Date in MJD.

I<Output>:

Date, in format MMMDDYY

I<Examples>:
    
  $week = mjd2week($mjd);

=item  week2doy

I<Usage>: 

    $doy  = week2doy($week);

I<Provides>: Gives day of year corresponding to given date.

I<Arguments>:
    
    $week = Week in MMMDDYY  (may be lower case).

I<Output>:

Day of year

I<Examples>:
    
   $doy  = week2doy($week);

=item  doy2week

I<Usage>: 

    $week = doy2week($doy,year);
 

I<Provides>: converts date from DOY to MMMDDYY.

I<Arguments>:
    
    $doy = day of year
    $year = year in YYYY.

I<Output>:

Date, in format MMMDDYY

I<Examples>:
    
    $week = doy2week(365, 2006);

=item  week2absolute

I<Usage>: 

  $abs  = week2absolute($week);

I<Provides>: converts time from MMMDDYY to absolute time.

I<Arguments>:
    
    $week = date, in format MMMDDYY (may be lower case)

I<Output>:

Date, in format yyyy:ddd:hh:mm:ss.sss

I<Examples>:
    
    $abs  = week2absolute("JAN2806");

=item  absolute2week

I<Usage>: 

   $week = absolute2week($abs);

I<Provides>: converts time from absolute time to MMMDDYY.

I<Arguments>:
    
    $abs = date, in format yyyy:ddd:hh:mm:ss.sss 

I<Output>:

Date, in format MMMDDYY

I<Examples>:
    
    $week = absolute2week("2006:312:00:00:00.000");

=item  diff_week

I<Usage>: 

   $diff_secs = diff_week($week1, $week2);

I<Provides>: diffs times in MMMDDYY format.

I<Arguments>:
    
    week1 = in format MMMDDYY (may be lower case)
    week2 = in format MMMDDYY (may be lower case)

I<Output>:

Difference in seconds (if negative, date 1 is later than date 2)

I<Examples>:
    
    $diff_secs = diff_week("NOV2106", "NOV2806");

=item week_sort

I<Usage>: 

    @sorted = sort {week_sort($a,$b)} @weeks


I<Provides>: Given two weeks, will determine which one is earlier.  This subroutine may be used in a sorting algorithm, as follows:

    @sorted = sort {week_sort($a,$b)} ($week1, $week2);

@sorted will list the given weeks from earliest to latest.

I<Arguments>:
    
    week1 = in format MMMDDYY (may be lower case)
    week2 = in format MMMDDYY (may be lower case)

I<Output>:

-1 if date 1 is earlier, 0 if date 1 equals date 2, 1 if date 2 is earlier

I<Examples>:
    
   @sorted = sort {week_sort($a,$b)} ($week1, $week2);

=item is_absolute

I<Usage>: 

    $boolean = is_absolute( $absolute_time );
 
I<Provides>:  Subroutine to test whether a value is a properly formatted absolute time

I<Arguments>:
    
    $absolute_time = time to check if in yyyy:ddd:hh:mm:ss.sss format.

I<Output>:

Boolean value (true if absolute, false if not)

I<Examples>:
    
   croak "$abs_time is in invalid format\n" 
	if not is_absolute($abs_time);

=item is_relative

I<Usage>: 

    $boolean = is_relative( $time );

I<Provides>:  Subroutine to test whether a value is a properly formatted relative time.


I<Arguments>:
    
    $time = value top check if in relative time format or not.

I<Output>:

Boolean value (true if absolute, false if not)

I<Examples>:
    
   croak "$time is in invalid format\n" 
	if not is_relative($time);

=item monday

I<Usage>: 

   ( $monday_year, $monday_doy ) = monday( $year, $doy );

I<Provides>:  Subroutine finds the earliest monday before a given date.

I<Arguments>:
    
    $year = year in YYYY
    $doy = Day of Year.

I<Output>:

Nearest monday ( yyyy, ddd )

I<Examples>:
    
  ( $monday_year, $monday_doy ) = monday( 2006, 318 );

=item arcdegsep

I<Usage>: 

   $separation = arcdegsep( $ra1, $dec1, $ra2, $dec2 );

I<Provides>: finds the difference, in arc-separation, between two positions in the sky.

I<Arguments>:
   
    RA1  = RA of target 1 (in decimal degrees)
    Dec1 = Dec of target 1 (in decimal degrees)
    RA2  = RA of target 2 (in decimal degrees)
    Dec2 = Dec of target 2 (in decimal degrees)

I<Output>:

Separation (in decimal degrees)

I<Examples>:
    
  $sep = arcdegsep(10.685000,41.268972, 167.429583,21.761944)

=item eci

I<Usage>: 

   $eci_vector = eci( $ra, $dec );

I<Provides>: converts RA and Dec from decimal degrees to ECI (earth-centered inertial) coordinates.

I<Arguments>:
   
    RA  = RA of target (in decimal degrees)
    Dec = Dec of target (in decimal degrees)

I<Output>:

Reference to array containing normalized ECI (cartesian) position vector 

I<Examples>:
    
    $eci_vector = eci(10.685000,41.268972)
    
or

    my $vector = eci( $ra2, $dec2);
    my $new_x =   $rotation_matrix[0]->[0] * $vector->[0]
	        + $rotation_matrix[0]->[1] * $vector->[1]
                + $rotation_matrix[0]->[2] * $vector->[2];

=item uneci

I<Usage>: 

   ( $ra, $dec ) = uneci( @$eci_vector );

I<Provides>: converts ECI (earth-centered inertial) coordinates to RA and Dec in decimal degrees.

I<Arguments>:
   
    @$eci_vector = ECI x, y, and z

I<Output>:

RA, Dec array in degrees

I<Examples>:
    
    my ($new_ra, $new_dec) = uneci( $new_x, $new_y, $new_z );

=item hms2deg

I<Usage>: 

   ( $ra, $dec ) = hms2deg( $hh, $mm, $ss, $dd, $dm, $ds );


I<Provides>: Converts from RA hours/minutes/seconds and Dec degrees/minutes/seconds to decimal degrees. Calls checkradec() first to validate the coordinates before performing the conversion.

I<Arguments>:
    
    $hh = RA hours
    $mm = RA minutes
    $ss = RA seconds
    $dd = Dec degrees 
    $dm = Dec arcminutes
    $ds = Dec arcseconds

I<Output>:

RA, Dec array in degrees 

I<Examples>:
    
  ( $ra, $dec ) = hms2deg( $hh, $mm, $ss, $dd, $dm, $ds );
 
=item deg2hms

I<Usage>: 

   ($hh, $mm, $ss, $dd, $dm, $ds) = deg2hms( $ra, $dec );

I<Provides>: Converts from decimal degrees to RA hours/minutes/seconds and Dec  degrees/minutes/seconds. Calls checkradec() first to validate the coordinates before performing the conversion.

I<Arguments>:
    
    RA = RA in decimal degrees. 
    Dec = Dec in decimal degrees.

I<Output>:

RA hours, RA minutes, RA seconds, Dec degrees, Dec arcminutes, Dec arcseconds.

I<Examples>:
    
  ($hh, $mm, $ss, $dd, $dm, $ds) = deg2hms( $ra, $dec );

=item trim

I<Usage>: 

    my $text = trim($text);
    my @texts = trim(@texts);

I<Provides>: Trims leading and trailing whitespace.

I<Arguments>:
    
    $text = string or array;

I<Output>:

String with leading and trailing whitespace removed.

I<Examples>:
    
    my $text = trim("       String      ");

=item drop_empty

I<Usage>: 

    my @items = drop_empty(@items);

I<Provides>: Given an array it will return a compact array with whitespace trimmed and any only whitespace elements removed (works well with splits).

I<Arguments>:
    
    @items = Array of strings.

I<Output>:

Array with any empty items or all whitespace items removed.

I<Examples>:
    
     my @items = drop_empty(split("", $text));

=item pitch_def

I<Usage>: 

    my $ranges = pitch_def();

I<Provides>: Parses the pitch definitions and returns the various good and bad pitch zones.

I<Arguments>:
    
    $pitch = Expects a numeric pitch angle (0 - 180 degrees), 
             a text pitch label (e.g., "bad", "good", "pline"), both, 
             or neither.

I<Output>:

Varies based on arguments. 

I<Examples>:
    
    1. my $ranges = &pitch_def;
    2. my $labels = &pitch_def(100);
    3. my $minmax = &pitch_def("good");
    4. my $is_bad = &pitch_def(100, "bad");

=item pitch_range

I<Usage>: 

    my $minmax = &pitch_label("bad");

I<Provides>: Parses the pitch definitions and returns the various good and bad pitch zones.

I<Arguments>:
    
    $area = a text pitch label (e.g., "bad", "good", "pline")

I<Output>:

A reference to a hash of arrays of min and max values

I<Examples>:
    
    my $minmax = &pitch_label("bad");
    print "bad pitch ranges are ", join(" and ", map {$_=>{min} . "-", $_=>{max}} @$minmax);


=item pitch_def_string

I<Usage>: 

    my $ranges = &parse_pitch_defs($PITCHFILE);

I<Provides>: Parses the pitch definitions.

I<Arguments>:
    
    $area = a text pitch label (e.g., "bad", "good", "pline")

I<Output>:

A reference to a hash (of hashes of arrays), undef on error.

I<Examples>:
    
    my $ranges = &parse_pitch_defs('/data/mpcrit1/bin/pitch_defs.txt') || die;

=item read_cyclefile

I<Usage>: 

    my ($cycle, $NEWPOOL, $p1bin, $p2bin, $p3bin) = read_cyclefile() ;

I<Provides>: Reads the Cycle Definition File.

I<Arguments>:
    
None.

I<Output>:

The Cycle number, pool file name and location, poolbins.

I<Examples>:
  
    my ($cycle,
        $POOL_LIST,
        $p1,
        $p2,
        $p3) = read_cyclefile() ;
    my @poolbins = (0, $p1, $p2, $p3);


=item check_obsid

I<Usage>: 

    my (@obsids) = check_obsids(@ARGV);
    $obsids = check_obsids($obs);


I<Provides>: 

Given a single obsid or a list of valid and nonvalid obsids, returns a list of valid 5 digit obsids.

I<Arguments>:
    
Either a single obsids or a list of obsids.

I<Output>:

A single obsid or list of obsids (depending on what you want in return: array or scalar).

I<Examples>:
  
 my $v = check_obsid("9221");
 my @v1 = check_obsid(("8232", undef, "3232"));
 my @v2 = check_obsid(("8232", undef, "3232,1232,12243"));
 my @v3 = check_obsid(("8232      ", undef, "      ", "3232,1232,BREAK,12243"));

=item is_numeric

I<Usage>: 

    my $result = is_numeric($val);


I<Provides>: 

Given a variable will test if it is a numeric value or not.

I<Arguments>:
    
Either a single test value.

I<Output>:

Returns the value if it is a number, otherwise returns null.

I<Examples>:
  
  print "true" if (is_numeric("3434"));       #true
  print "true" if (is_numeric("34A34"));      #false
  print "true" if (is_numeric("3434.21.11")); #false

=item checkradec

I<Usage>: 

    my ($degra, $degdec) = checkradec ($_[0], $_[1]);
    my ($hh, $mm, $ss, $dd, $dm, $ds) = checkradec ($_[0], $_[1], $_[2], $_[3], $_[4], $_[5]);


I<Provides>: 

Given a ra and dec pair in either degrees or hms format, will check that it is a valid RA and DEC in the same format as entered.

I<Arguments>:
    
Either 2 arguments for RA and Dec in degrees, or 6 arguments for hms format.

I<Output>:

Returns the values if they are valid otherwise it returns null.

I<Examples>:
  
    checkradec ("245.23", "-90.00");
    checkradec ("12", "00", "12", "-45", "12" "09");


=item is_caltarget

I<Usage>: 

    my $result = is_caltarget($obsid);

I<Provides>: 

Given an obsid will check if that obsid is in the cal ranges or not.

I<Arguments>:
    
A value to check.

I<Output>:

Returns the value if they are a cal target otherwise it returns null.

I<Examples>:
  
    print "true" if is_caltarget("2452");
    print "false" if is_caltarget("63452");

=item stripleadingzeroes

I<Usage>: 

    my $result = stripleadingzeroes($obsid);

I<Provides>: 

Given an obsid will pull off an leading obsids.

I<Arguments>:
    
A obsid to check.

I<Output>:

Returns the value with any leadiong zeroes removed.

I<Examples>:
  
    print $hashlookup{stripleadingzeroes($obs)};
    print stripleadingzeroes($obsid);

=item parse_coord

I<Usage>: 

    my %coord = parse_coord($COORDFILE);

I<Provides>: 

Given an HTML coordination page will pull off obsid information.

I<Arguments>:
    
The coordination page (HTML format).

I<Output>:

Returns a data structure of obsids to coordination info.

I<Examples>:
  
  foreach my $key (keys %coord){
    my @value = ($coord{$key}[0], $coord{$key}[1], $coord{$key}[2], $coord{$key}[3], $coord{$key}[4]);

    if ($value[4] >= $chandraweek && $value[4] <= $chandraweekend ){
	print "$key($value[0]) - $value[1] , $value[2], $value[3]\n";
    }
  }

=item parse_tooddt

I<Usage>: 

    my %too_ddt = parse_tooddt($TOOFILE);

I<Provides>: 

Given an HTML TOO page will pull off obsid information.
Hash is in the returned format of
  #$obsid =  coord, Targname, type, date, PI, Seqnum, Propnum
		

I<Arguments>:
    
The Too page (HTML format).

I<Output>:

Returns a data structure of obsids to too info.

I<Examples>:
  
  foreach my $key (keys %too_ddt){
      my @value = ($too_ddt{$key}[0], $too_ddt{$key}[1], $too_ddt{$key}[2], $too_ddt{$key}[3]);
    if ($value[3] >= $chandraweek && $value[3] <= $chandraweekend ){
	
	if ($key =~ /\<a.*?\>(\d+)/is){
	    ($key) = ($key =~ /\<a.*?\>(\d+)/is);
	}
	print "$key - $value[0], $value[1], $value[2]\n";
    }
  }

=back

=head1 EXAMPLES

=over 8 

=back

=head1 NOTES

OP-19: http://hea-www.harvard.edu/asclocal/mp/html/op19top.html.

=head1 DEPENDENCIES

  use strict;
  use warnings;
  use AutoLoader qw(AUTOLOAD);
  require Exporter;
  use Carp;
  use Astro::Time;
  use POSIX;

=head1 FILES

=over 8

=item Pitch Definition File

C<my $PITCH_DEFS_FILE => F</data/mpcrit1/bin/pitch_def.txt>

Contains the pitch region definitions.

=item Cycle Definition File

C<my $CYCLE_DEFS_FILE => F</data/mpcrit1/bin/cycle_def.txt>

Contains the cycle definitions: number, pool lists, pool bins.

=back

=head1 VERSION

$Revision: 1.11 $

=head1 AUTHOR

Author:  M. Clarke; rel 7/12/2001

  Last Update:    $Date: 2008/05/20 17:40:24 $ 
  Last Update by: $Author: kkingsbury $


=head1 HISTORY

=over 8

=item Ver: 1.10

parse_too proposal and seqnum were off by one column.

kkingsbury - 05/20/2008


=item Ver: 1.9

- updated parse_too to provide a little more info.

kkingsbury - 05/20/2008


=item Ver: 1.8

- didn't realize my copy was old. Checking in again with merged files.

- Lock issues.

kkingsbury - 05/20/2008


=item Ver: 1.6

-attempting second check in

heidi - 02/08/2008


=item Ver: 1.7

-correct check_radec to pass parameters properly

-add check_radec calls to hms2deg deg2hms

-update documentation on all 3 scripts

heidi - 02/08/2008


=item Ver: 1.5

- Added better numeric checking on check_obsid

kkingsbury - 12/07/2007


=item Ver: 1.4

added new subroutines for input checking.

kkingsbury - 11/09/2007


=item Ver: 1.4

added common input checks: check_obsids, checkradec, is_caltarget, etc.

kkingsbury - 11/09/2007


=item Ver: 1.3

- Fixed floating point rounding error in pitch routine.

kkingsbury - 02/07/2007


=item Ver: 1.2

- Updated POD, imported into CVS Control.

kkingsbury - 11/20/2006


=item Ver: 1.1

Initial revision

M. Clarke - 7/12/2001 

=back

=cut
########################################################################
#                        START CODE                                    #
########################################################################

require 5.005_62;

use strict;
use warnings;
use AutoLoader qw(AUTOLOAD);

require Exporter;

our @ISA = qw(Exporter);
our @EXPORT = qw( 
		  &diff_time
		  &relative2sec
		  &sec2relative
		  &absolute2chandra
		  &chandra2absolute
		  &week2mjd
		  &mjd2week
		  &week2doy
		  &doy2week
		  &week2absolute
		  &absolute2week
		  &diff_week
		  &week_sort
		  &is_absolute
		  &is_relative
		  &monday
		  &arcdegsep
		  &eci
		  &uneci
		  &hms2deg
		  &deg2hms
		  &drop_empty
		  &trim
		  &pitch_def
		  &pitch_range
		  &pitch_def_string
		  &read_cyclefile
		  &stripleadingzeroes
		  &is_caltarget
		  &checkradec 
		  &is_numeric
		  &check_obsid
		  &parse_coord
		  &parse_tooddt
                );

our $VERSION = '1.10';

use Carp;
use Astro::Time;
use POSIX;

# for date conversions
my %Month2Num = ( 'JAN' => 1, 'FEB' => 2, 'MAR' => 3, 'APR' => 4,
                  'MAY' => 5, 'JUN' => 6, 'JUL' => 7, 'AUG' => 8,
                  'SEP' => 9, 'OCT' =>10, 'NOV' =>11, 'DEC' =>12  );
my @Num2Month = ( 'JAN', 'FEB', 'MAR', 'APR',
                  'MAY', 'JUN', 'JUL', 'AUG',
                  'SEP', 'OCT', 'NOV', 'DEC'  );

# for angle conversions
my $pi      = acos(-1.0);
my $deg2rad = $pi/180.0;
my $rad2deg = 180.0/$pi;

# for pitch
my $PITCH_DEFS_FILE = '/data/mpcrit1/bin/pitch_def.txt';
my $CYCLE_DEFS_FILE = '/data/mpcrit1/bin/cycle_def.txt';



# diff_time
#
# Description: subroutine to diff times in 
#   yyyy:ddd:hh:mm:ss.sss format
# Arguments: time 1, time 2
# Output: difference in seconds (if negative, time 1
#   is later than time 2)
# Note: this subroutine assumes that hh:mm:ss is always
#   provided.  Therefore, something like ddd:hh:mm:ss
#   will work fine, but yyyy:ddd:hh:mm will not work
#   properly.  Most predictable results are given
#   when this subroutine is used in conjunction with
#   the &is_absolute test.

sub diff_time {
    
    my @time1 = split /:/, $_[0];
    if ( $#time1 == 4 ) {
        @time1 = @time1;
    } elsif ( $#time1 == 3 ) {
        unshift @time1, '0';
    } elsif ( $#time1 == 2 ) {
        unshift @time1, '0', '0';
    } else {
        carp "Not a valid time\n";
    }

    my @time2 = split /:/, $_[1];
    if ( $#time2 == 4 ) {
        @time2 = @time2;
    } elsif ( $#time2 == 3 ) {
        unshift @time2, '0';
    } elsif ( $#time2 == 2 ) {
        unshift @time2, '0', '0';
    } else {
        carp "Not a valid time\n";
    }

    if ( $time1[0] - $time2[0] == 0 ) {

        # this method is more accurate for time differences
        # that are less than one year

        my $diff  =  ( $time2[1] - $time1[1] ) * 24 * 60 * 60
                   +
                     ( $time2[2] - $time1[2] ) * 60 * 60
                   +
                     ( $time2[3] - $time1[3] ) * 60
                   +
                     ( $time2[4] - $time1[4] );

        if ( 
             (sprintf "%.4f",$diff) <  0.0010
            and
             (sprintf "%.4f",$diff) > -0.0010
           )
        {
            $diff = 0;
        }

        return $diff;

    } else {

        # this method accounts for leap years in calculating
        # time differences, but it is slightly less accurate
        # than the above one because of all the conversions

        my $ut1 = hms2time($time1[2], $time1[3], $time1[4]);
        my $ut2 = hms2time($time2[2], $time2[3], $time2[4]);

        my $mjd1 = dayno2mjd($time1[1], $time1[0], $ut1);
        my $mjd2 = dayno2mjd($time2[1], $time2[0], $ut2);

        my $diff = $mjd2 - $mjd1;
        $diff *= 24 * 60 * 60; 

        if ( 
             (sprintf "%.4f",$diff) <  0.0001
            and
             (sprintf "%.4f",$diff) > -0.0001
           )
        {
            $diff = 0;
        }

        $diff = sprintf "%.6f", $diff;  # that's about as many
                                        # decimal places as it's
                                        # accurate to
        return $diff;
    }
}


# relative2sec
#
# Description: subroutine to convert times from relative
#   time format to seconds
# Argument: time in (ddd:)hh:mm:ss(.sss) format
# Output: time in seconds

sub relative2sec {
     
    my @time = split /:/, $_[0];
    if ( $#time == 3 ) {
	@time = @time;
    } elsif ( $#time == 2 ) {
	unshift @time, '0';
    } else {
	carp "Not a valid time";
    }

    my $time  = ( $time[0] ) * 24 * 60 * 60
	       +
		( $time[1] ) * 60 * 60
	       +
		( $time[2] ) * 60
	       +
		( $time[3] );


    return $time;
}


# sec2relative
#
# Description: subroutine to unconvert times (ie. to go
#   from seconds to relative time format)
# Argument: time in seconds 
# Output: time in ddd:hh:mm:ss.sss format

sub sec2relative {
    
    my $time = $_[0];
    my $remainder;

    my $day     = int( $time / (24 * 60 * 60) );
    $remainder  = $time - ($day * (24 * 60 * 60));

    my $hour    = int( $remainder / (60 * 60) );
    $remainder -= $hour * (60 * 60);

    my $minute  = int( $remainder / 60 );
    $remainder -= $minute * 60;

    my $second  = $remainder;

    $day    = sprintf "%3.3d", $day;
    $hour   = sprintf "%2.2d", $hour;
    $minute = sprintf "%2.2d", $minute;
    $second = sprintf "%2.3f", $second;
    $second = "0$second" if $second < 10;

    $time = "$day:$hour:$minute:$second";

    return $time;
}


# absolute2chandra
#
# Description: converts absolute times (see OP-19 definition,
#   or &is_absolute below) to Chandra times (ie. seconds since
#   Jan. 1, 1998 at midnight).
# Argument: absolute time
# Output: Chandra time (sec)

sub absolute2chandra {

    my $abs_time = $_[0];

    croak "$abs_time is in invalid format\n" 
	if not is_absolute($abs_time);

    # midnight, Jan. 1, 1998
    my $chandra_zero = "1998:001:00:00:00.000";

    my $sec_diff = diff_time( $chandra_zero, $abs_time );

    return $sec_diff;
}


# chandra2absolute
#
# Description: converts Chandra times (ie. seconds since
#   Jan. 1, 1998 at midnight) to absolute times (see OP-19
#   definition, or &is_absolute below).
# Argument: Chandra time (sec)
# Output: absolute time

sub chandra2absolute {

    my $chandra_sec = $_[0];

    # midnight, Jan. 1, 1998 in mjd
    my $chandra_zero = 50814.0;

    my $mjd = $chandra_zero + ( $chandra_sec / (24*60*60) );

    my ($dayno, $year, $ut) = mjd2dayno($mjd);
    my ($sign, $hour, $minute, $second) = time2hms($ut, 'H', 3);

    $dayno  = sprintf "%3.3d", $dayno;
    $hour   = sprintf "%2.2d", $hour;
    $minute = sprintf "%2.2d", $minute;
    $second = sprintf "%.3f",  $second;
    $second = "0$second" if $second < 10;

    return "$year:$dayno:$hour:$minute:$second";

}


# week2mjd
#
# Description: converts time from MMMDDYY to MJD
# Argument: date, in format MMMDDYY (may be lower case)
# Output: date, in MJD

sub week2mjd {

    my $week = $_[0];
    
    croak "$week is not in format MMMDDYY" unless
	$week =~ /^(JAN|FEB|MAR|APR|
                    MAY|JUN|JUL|AUG|
                    SEP|OCT|NOV|DEC)\d{4}$/xi;

    # uppercase the week:
    $week =~ tr/a-z/A-Z/;

    my $m = substr($week, 0, 3);
    my $d = substr($week, 3, 2);
    my $y = substr($week, 5, 2);
    $y = ($y >= 98 ? "19" : "20") . "$y";

    return cal2mjd($d, $Month2Num{$m}, $y, 0);
}


# mjd2week
#
# Description: converts time from MJD to MMMDDYY
# Argument: date, in MJD
# Output: date, in format MMMDDYY (may be lower case)

sub mjd2week {

    my $mjd = $_[0];
    
    my ($d, $m, $y, $ut) = mjd2cal($mjd);
    my $m_name = $Num2Month[$m-1];
    $d = sprintf "%2.2d", $d;
    $y = substr($y, -2, 2);

    return "$m_name$d$y";
}


# week2doy
#
# Description: gives day of year corresponding to given date
# Argument: date, in format MMMDDYY (may be lower case)
# Output: day of year

sub week2doy {

    my $week = $_[0];
    
    croak "$week is not in format MMMDDYY" unless
	$week =~ /^(JAN|FEB|MAR|APR|
                    MAY|JUN|JUL|AUG|
                    SEP|OCT|NOV|DEC)\d{4}$/xi;

    # uppercase the week:
    $week =~ tr/a-z/A-Z/;

    my $m = substr($week, 0, 3);
    my $d = substr($week, 3, 2);
    my $y = substr($week, 5, 2);
    $y = ($y >= 98 ? "19" : "20") . "$y";

    return cal2dayno($d, $Month2Num{$m}, $y);
}


# doy2week
#
# Description: converts date from DOY to MMMDDYY
# Arguments: day of year, year
# Output: date, in format MMMDDYY (may be lower case)

sub doy2week {

    my $doy = $_[0];
    my $y   = $_[1];

    my ($d, $m) = dayno2cal($doy, $y);
    my $m_name = $Num2Month[$m-1];
    $d = sprintf "%2.2d", $d;
    $y = substr($y, -2, 2);

    return "$m_name$d$y";
}


# week2absolute
#
# Description: converts time from MMMDDYY to absolute time
# Argument: date, in format MMMDDYY (may be lower case)
# Output: date, in format yyyy:ddd:hh:mm:ss.sss

sub week2absolute {

    my $week = $_[0];
    
    croak "$week is not in format MMMDDYY" unless
	$week =~ /^(JAN|FEB|MAR|APR|
                    MAY|JUN|JUL|AUG|
                    SEP|OCT|NOV|DEC)\d{4}$/xi;

    # uppercase the week:
    $week =~ tr/a-z/A-Z/;

    my $m = substr($week, 0, 3);
    my $d = substr($week, 3, 2);
    my $y = substr($week, 5, 2);
    $y = ($y >= 98 ? "19" : "20") . "$y";

    my $doy = sprintf "%3.3d", cal2dayno($d, $Month2Num{$m}, $y);

    return "$y:$doy:00:00:00.000";
    
}


# absolute2week
#
# Description: converts time from absolute time to MMMDDYY
# Argument: date, in format yyyy:ddd:hh:mm:ss.sss 
# Output: date, in format MMMDDYY (may be lower case)

sub absolute2week {
    
    my $abs = $_[0];

    croak "$abs not in yyyy:ddd:hh:mm:ss.sss format"
	unless is_absolute($abs);

    my ($y,$doy,$h,$min,$s) = split /:/, $abs;
    my ($d, $m) = dayno2cal($doy, $y);
    my $m_name = $Num2Month[$m-1];
    $d = sprintf "%2.2d", $d;
    $y = substr($y, -2, 2);

    return "$m_name$d$y";
}


# diff_week
#
# Description: diffs times in MMMDDYY format
# Argument: date 1, date 2, in format MMMDDYY 
#   (may be lower case)
# Output: difference in seconds (if negative, date 1
#   is later than date 2)

sub diff_week {

    my $week1 = $_[0];
    my $week2 = $_[1];

    my $abs1 = week2absolute($week1);
    my $abs2 = week2absolute($week2);

    return diff_time($abs1, $abs2);
}


# week_sort
#
# Description: given two weeks, will determine which
#   one is earlier.  This subroutine may be used in
#   a sorting algorithm, as follows:
#   @sorted = sort {week_sort($a,$b)} ($week1, $week2);
#   @sorted will list the given weeks from earliest to
#   latest.
# Argument: date 1, date 2, in format MMMDDYY 
#   (may be lower case)
# Output: -1 if date 1 is earlier, 0 if date 1 equals
#   date 2, 1 if date 2 is earlier

sub week_sort {

    my $week1 = $_[0];
    my $week2 = $_[1];

    my $mjd1 = week2mjd($week1);
    my $mjd2 = week2mjd($week2);

    my $out;
    if ($mjd1 < $mjd2) {
	$out = -1;
    } elsif ( $mjd1 > $mjd2 ) {
	$out = 1;
    } elsif ( $mjd1 == $mjd2 ) {
	$out = 0;
    }

    $out = -1 if $out eq '';

    return $out;
}


# is_absolute
#
# Description: subroutine to test whether a value is a properly
#   formatted absolute time
# Argument: value
# Output: Boolean value (true if absolute, false if not)

sub is_absolute {

    my $value = $_[0];


    # test for absolute times (see OP-19 definition)

    my $abs_time = '(\d{4}:\d{3}:\d{2}:\d{2}:\d{2}(\.\d{3})?)';
        # matches:
        # yyyy:ddd:hh:mm:ss(.sss)
        
    my ($year, $day, $hour, $min, $sec);
        
    if ( $value =~ /^($abs_time)$/ ) {
        ($year, $day, $hour, $min, $sec) = split /:/, $value, 5;
        if ( 
             ( 
               $day  <= 365    and $day  >  0
              or
               (
                 leap($year)
                and
                 $day  <= 366    and $day  >  0
               )
             )
            and
             $hour <= 23     and $hour >= 0
            and
             $min  <= 59     and $min  >= 0
            and
             $sec  <= 59.999 and $sec  >= 0
           ) 
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
    else
    {
        return 0;
    }
}


# is_relative
#
# Description: subroutine to test whether a value is a
#   properly formatted relative time
# Argument: value
# Output: Boolean value (true if relative, false if not)

sub is_relative {

    my $value = $_[0];


    # test for relative times (see OP-19 definition)
    my ($day, $hour, $min, $sec);
    my $rel_time = '(\d{3,4}:)?\d{2}:\d{2}:\d{2}(\.\d{3})?';
        # matches (ddd:)hh:mm:ss(.sss)
        
    if ( $value =~ /^($rel_time)$/ ) {
        if ($value =~ /.*:.*:.*:.*/) {
            ($day, $hour, $min, $sec) = split /:/, $value, 4 ;
        } elsif ($value =~ /.*:.*:.*/) {
            ($hour, $min, $sec) = split /:/, $value, 3;
        }
            
        if ( 
             ( 
               ( 
                 defined($day) 
                and $day >= 0 
                and $day <= 9999 
                and $hour >= 0 
                and $hour <= 23 
               )
              or 
               ( 
                 !defined($day) 
                and $hour >= 0 
                and $hour <= 99
               ) 
             )
            and
             ( 
               $min >= 0 and $min <= 59 and $sec >= 0 and $sec <= 59.999
             )
           )
        {
            return 1;
        }
        else
        {
            return 0;
        }       
    }
    else
    {
        return 0;
    }
}


# monday
#
# Description: This subroutine finds the earliest monday
#    before a given date
# Arguments: year (yyyy), day of year (ddd)
# Output: nearest monday ( yyyy, ddd )

sub monday {

    my $year = $_[0];
    my $day  = $_[1];

    my $known_monday = 52204.0;  # ie. Monday, Oct. 22, 2001
                                 # in Modified Julian Day

    my $mjd = dayno2mjd($day, $year);


    {
        if ( 
             abs( $mjd - $known_monday ) / 7 == 
                  int( abs( $mjd - $known_monday ) / 7 )
           )
        {
            return ($year, $day);
        }
        else
        {
            $mjd--;
            ($day, $year) = mjd2dayno($mjd);
            redo;
        }
    }
}


# arcdegsep
#
# Description: finds the difference, in arc-separation,
#   between two positions in the sky
# Arguments: RA1, Dec1, RA2, Dec2 (in decimal degrees)
# Output: separation (in decimal degrees)

sub arcdegsep {

    my ($ra1, $dec1, $ra2, $dec2) = @_;


    # use rotation matrices to find new coordinates
    # such that (ra1,dec1) is at the top of the
    # celestial sphere -- then, in the new coordinates
    # the distance from (ra1,dec1) to (ra2,dec2) is
    # 90 minus the new declination of (ra2,dec2)
    #
    # see code for /data/mpcrit1/bin/pool_picker.pl
    # for more explanation on the why and how of
    # using rotation matrices

    my $phi   = (90 - $ra1 ) * $deg2rad;
    my $theta = (90 - $dec1) * $deg2rad;
    # psi = 0

    my @rotation_matrix = 
        ( [       cos($phi),           -(sin($phi)),           0      ],
          [ sin($phi)*cos($theta), cos($phi)*cos($theta), -sin($theta)],
          [ sin($phi)*sin($theta), cos($phi)*sin($theta),  cos($theta)] );

    my $vector = eci( $ra2, $dec2);

    my $new_x =   $rotation_matrix[0]->[0] * $vector->[0]
	        + $rotation_matrix[0]->[1] * $vector->[1]
                + $rotation_matrix[0]->[2] * $vector->[2];

    my $new_y =   $rotation_matrix[1]->[0] * $vector->[0]
	        + $rotation_matrix[1]->[1] * $vector->[1]
		+ $rotation_matrix[1]->[2] * $vector->[2];

    my $new_z =   $rotation_matrix[2]->[0] * $vector->[0]
	        + $rotation_matrix[2]->[1] * $vector->[1]
		+ $rotation_matrix[2]->[2] * $vector->[2];
    
    my ($new_ra, $new_dec) = uneci( $new_x, $new_y, $new_z );

    my $deldeg = 90 - $new_dec;
    
    # five decimals is about all the precision this
    # method has, so round off $deldeg

    return sprintf "%.5f", $deldeg;

}


# eci
#
# Description: converts RA and Dec from decimal degrees
#   to ECI (earth-centered inertial) coordinates.
# Arguments: ra, dec in degrees
# Output: reference to array containing normalized ECI 
#   (cartesian) position vector 

sub eci {

    # convert to radians
    my $ra  = $_[0] * $deg2rad;
    my $dec = $_[1] * $deg2rad;
    
    my @eci;
    my $polar = ($pi/2.0) - $dec;

    $eci[0] = sin( $polar ) * cos( $ra );
    $eci[1] = sin( $polar ) * sin( $ra );
    $eci[2] = cos( $polar );

    return \@eci;
}



# uneci
#
# Description: converts ECI (earth-centered inertial) coordinates
#   to RA and Dec in decimal degrees.
# Arguments: ECI x, y, and z
# Output: ra, dec array in degrees

sub uneci {

    my $x = $_[0];
    my $y = $_[1];
    my $z = $_[2];

    my $dec = asin( $z );
    my $ra;

    if ( $x == 0 ) {
        $x = 1e-17;
    }

    $ra = atan2( $y, $x );

    # convert to degrees
    $ra  *= $rad2deg;
    $dec *= $rad2deg;

    # shift to 0->360
    $ra += 360 if $ra < 0;
    $ra -= 360 if $ra >= 360;
    
    return ($ra, $dec);
}


# hms2deg
#
# Description: converts from RA hours/minutes/seconds
#   and Dec degrees/minutes/seconds to decimal degrees
# Arguments: RA hours, RA minutes, RA seconds,
#   Dec degrees, Dec arcminutes, Dec arcseconds
# Output: RA, Dec (decimal degrees)

sub hms2deg {

    my ( $hh, $mm, $ss, $dd, $dm, $ds ) = @_;

    ($hh,$mm,$ss,$dd,$dm,$ds) = checkradec($hh,$mm,$ss,$dd,$dm,$ds);
    return if (! defined($hh) || ! defined($mm) ||
	       ! defined($ss) || ! defined($dd) ||
	       ! defined($dm) || ! defined($ds) );
    #calculate ra
    my $ra = 15 * ($hh + $mm/60 + $ss/3600);
    
    #calculate dec
    $dd =~ s/^\+//;
    if ( $dd =~ /^-/) {
	$dm = -$dm;
	$ds = -$ds;
    }
    my $dec = $dd + $dm/60 + $ds/3600;

    return ($ra, $dec);

}


# deg2hms
#
# Description: converts from decimal degrees to 
#   RA hours/minutes/seconds and Dec 
#   degrees/minutes/seconds
# Arguments: RA, Dec (decimal degrees)
# Output: RA hours, RA minutes, RA seconds,
#   Dec degrees, Dec arcminutes, Dec arcseconds

sub deg2hms {

    my $ra  = $_[0];
    my $dec = $_[1];
    
    ($ra,$dec) = checkradec($ra,$dec);
    return if (! defined($ra) || ! defined($dec) );
    
    #calculate the hms for ra
    my $hh = int( $ra/15 );
    my $mm = int( 60 * ($ra/15 - $hh));
    my $ss = 60 * ( 60 * ($ra/15 - $hh) - $mm);

    #calculate the dms for dec
    $dec =~ s/^\+//;    
    my $dd = int($dec);
    my $dm = int( 60 * ($dec - $dd) );
    my $ds = 60 * ( 60 * ($dec - $dd) - $dm);

    # remove negative signs in front of dec
    # minutes and dec seconds
    # negative sign will be in front of dec hours
    if ( $dec <= 0 ) {
	$dm =~ s/^\-//;
	$ds =~ s/^\-//;
    }

    # format to have leading zeroes if necessary
    $ss = sprintf "%.3f", $ss;
    $ss = '0'.$ss if $ss < 10;
    $ds = sprintf "%.3f", $ds;
    $ds = '0'.$ds if $ds < 10;
    $dd = sprintf "%2.2d", $dd;
    $dd = '+'.$dd if $dec > 0;
    $dm = '0'.$dm if $dm < 10;
    $mm = '0'.$mm if $mm < 10;
    $hh = '0'.$hh if $hh < 10;
    
    
    # force the dec to have a negative sign
    # if the degree is 0 and the dec is negative
    if ($dec < 0 &&
	$dd == 0) {
	$dd = "-" . $dd;
    }
    

    return ( $hh, $mm, $ss, $dd, $dm, $ds );
}

##
## EXPECTS: 	a numeric pitch angle (0 - 180 degrees), a text pitch 
##		label (e.g., "bad", "good", "pline"), both, or neither
## RETURNS: 	varies based on arguments (see EXAMPLES)
## EXAMPLES: 
##	1. my $ranges = &pitch_def;
##	2. my $labels = &pitch_def(100);
##	3. my $minmax = &pitch_def("good");
##	4. my $is_bad = &pitch_def(100, "bad");
##
sub pitch_def
  {
    my @args = @_;

    die "subroutine pitch_def expecting 0, 1, or 2 arguments" 
      if $#args > 1;

    if ($#args == 1)
      {
	return &pitch_is($args[0], $args[1]);
      }
    elsif ($#args == 0)
      {
	if ($args[0] =~ /[a-z]/i)
	  {
	    return &pitch_range($args[0]);
	  }
	else
	  {
	    return &pitch_label($args[0]);
	  }
      }
    else
      {
	return &parse_pitch_defs;
      }
  }

##
## EXPECTS: the name of the pitch_defs file
## RETURNS: a reference to a hash (of hashes of arrays), undef on error
## EXAMPLE: my $ranges = &parse_pitch_defs('/data/mpcrit1/bin/pitch_defs.txt') || die;
##
sub parse_pitch_defs
  {
    my $file = shift || $PITCH_DEFS_FILE;

    open(FILE, $file) or 
      die "cannot open file $file for reading: $!";

    my @lines = grep(!/^\#/, <FILE>);
    chomp(@lines);

    close(FILE);

    my %ranges = ();
    
    for my $line (@lines)
      {
	$line = &trim($line);

	next unless length($line) > 0;

	next if $line =~ /=/;

	my ($label, $min, $max, $comments) = 
	  split(/\s+/, $line, 4);

	die "at least 3 columns expected in input file line: $line" 
	  unless defined($label) and defined($min) and defined($max);

	die "$label min: $min greater than max: $max!" 
	  if $min > $max;

	push @{$ranges{lc($label)}{min}}, $min;
	push @{$ranges{lc($label)}{max}}, $max;
	push @{$ranges{lc($label)}{comments}}, $comments if $comments;
      }

    return \%ranges;
  }

##
## EXPECTS: a solar pitch angle in degrees (0-180) and a pitch
## RETURNS: a reference to an array of corresponding pitch labels
## EXAMPLE: 	my $labels = &pitch_label(105);
##		print "105 degrees is ", join(" and ", @$labels), " pitch";
##
sub pitch_label
  {
    my $pitch_angle = shift;

    my $ranges = &parse_pitch_defs($PITCH_DEFS_FILE);

    my @labels = ();

    for my $label (keys(%$ranges))
      {
	my @min = @{$ranges->{lc($label)}{min}};
	my @max = @{$ranges->{lc($label)}{max}};

	die "uneven number of max and min values for label $label"
	  unless $#min == $#max;

	for my $i (0 .. $#min)
	  {
	    push @labels, lc($label) if 
	      $pitch_angle >= $min[$i] and 
		$pitch_angle <= $max[$i]; 
	  }
	
      }
    
    return \@labels;
  }

##
## EXPECTS: 	a text pitch label (e.g., "bad", "good", "pline")
## RETURNS: 	a reference to a hash of arrays of min and max values
## EXAMPLE: 	my $minmax = &pitch_label("bad");
##		print "bad pitch ranges are ", join(" and ", map {$_=>{min} . "-", $_=>{max}} @$minmax);
##
sub pitch_range
  {
    my $label = shift; 
    
    my $ranges = &parse_pitch_defs($PITCH_DEFS_FILE);
    
    return $ranges->{lc($label)} if $ranges->{lc($label)};
    
    die "no such label $label";
  }

##
## EXPECTS: 	a solar pitch angle in degrees (0-180) and a pitch
##		range label 
## RETURNS: 	1 if the given angle is in the range described by the 
##	 	given label, otherwise 0
## EXAMPLE: 	print "pitch too cold!" if &pitch_is($pitch, "pline");
##
sub pitch_is
  {
    my @args = @_;

    die "subroutine pitch_is() expecting 2 arguments" 
      unless $#args == 1;

    my ($label, $pitch_angle) = ($args[1], $args[0]);

    ($label, $pitch_angle) = ($args[0], $args[1]) if ($args[0] =~ /[a-z]/i);

    my $labels = &pitch_label($pitch_angle);
    
    $label = lc($label);

    return 1 if grep(/^$label$/, @$labels);
    
    return 0;
  }



sub drop_empty { #Drop 0 length items out of array
    my @out;
    my @in = @_;
    for (my $i = 0; $i < scalar(@in); $i++){
        $in[$i] = trim($in[$i]);
        if (length($in[$i]) >= 1){
            push @out, $in[$i];
        }
    }

    return @out;
}


sub read_cyclefile {

    my $cycle_file = $CYCLE_DEFS_FILE;
    my (@cycle, @poolfile, @p1bin, @p2bin, @p3bin) ;
    my ($cycle, $poolfile, $p1bin, $p2bin, $p3bin) ;

    # open pitch definition file for reading
    open (CYCLE, $cycle_file) or
	die "\n\tCould not open $cycle_file for reading.\n\n";
    
    # read in info about the file
    while (<CYCLE>) {
	next if ($_ =~ /^#/);
	if ($_ =~ /Cycle/) {
	    @cycle = split " ", $_;
	    # remove "Cycle" and keep the numbers
	    $cycle = pop @cycle;
	}
	if ($_ =~ /File/) {
	    @poolfile = split " ", $_ ;
	    # remove "File" and keep the numbers
	    $poolfile = pop @poolfile ;
	}
	if ($_ =~ /Poolbin1/) {
	    @p1bin = split " ", $_;
	    # remove "p1bin" and keep the numbers
	    $p1bin = pop @p1bin ;
	}
	if ($_ =~ /Poolbin2/) {
	    @p2bin = split " ", $_;
	    # remove "p2bin" and keep the numbers
	    $p2bin = pop @p2bin ;
	}
	if ($_ =~ /Poolbin3/) {
	    @p3bin = split " ", $_;
	    # remove "p3bin" and keep the numbers
	    $p3bin = pop @p3bin ;
	}
    }
	
    close(CYCLE);
    return ($cycle, $poolfile, $p1bin, $p2bin, $p3bin) ;
}

##
## EXPECTS: a string
## RETURNS: the string with leading and trailing whitespace removed
## EXAMPLE: my $trimmed = &trim(" hello kitty ...  ");
##
sub trim {
    my @out = @_;
    for (@out){
	next if (! defined);
	s/^\s+//;
	s/\s+$//;
    }
    return wantarray ? @out: $out[0];
}

##
## EXPECTS: 	a numeric pitch angle (0 - 180 degrees) or a text pitch 
##		label (e.g., "bad", "good", "pline")
## RETURNS: 	a string of comma-separated labels or pitch ranges 
## EXAMPLES: 
##	1. my $label_string = &pitch_def_string(100);
##	2. my $minmax_string = &pitch_def_string("good");
##
sub pitch_def_string
  {
    my @args = @_;

    die "subroutine pitch_def_string expecting 1 argument" 
      if $#args;

    if ($args[0] =~ /[a-z]/i)
      {
	my $ranges = &pitch_range($args[0]);
	
	my @min = @{$ranges->{min}};
	my @max = @{$ranges->{max}};
	
	my @ranges = ();

	for my $i (0 .. $#min)
	  {
	    push @ranges, sprintf "%.0f-%.0f", $min[$i], $max[$i];
	  }

	return join(",", @ranges);
	  
      }
    else
      {
	my $labels = &pitch_label($args[0]);
	
	return join(",", @$labels);
      }
}

##
## EXPECTS: 	a single obsid or a list of obsids.
## RETURNS: 	a zero padded list of obsids or a single zero padded obsidtring of comma-separated labels or pitch ranges, or zero if no obsids found. 
## EXAMPLES: 
##    my $v = check_obsid("9221");
##    my @v1 = check_obsid(("8232", undef, "3232"));
##    my @v2 = check_obsid(("8232", undef, "3232,1232,12243"));
##    my @v3 = check_obsid(("8232      ", undef, "      ", "3232,1232,BREAK,12243"));


sub check_obsid {
    
    my @obsids = @_;
    my @out;
    
    return if scalar(@obsids) < 1;
    
    while (@obsids) {
	#pop off args from array
	my $obsid = trim(shift(@obsids));
	next if ((! defined($obsid)) || (! length($obsid)));
	#check if a comma is there. If it is take first and 
	#   add rest to the obsid queue
	my @other = split(",", $obsid);
	$obsid = $other[0];
	push @obsids, @other[1..$#other];
	
	#check is a number and then is a 1 to 5 digit number
	next if (! is_numeric($obsid));
	next if ($obsid !~ /^\d{1,5}$/);
	
	#push formatted onto out
	push @out, sprintf("%05d", $obsid);
    }
    
    #return array or value depending on what they want
    if (scalar(@out)){
        return wantarray ? @out : $out[0]; 
    } else {
        return;
    }
}




##
## EXPECTS: 	any kind of scalar input.
## RETURNS: 	a value if the input is a number otherwise undef.
## EXAMPLES: 
##    is_numeric("9221");
##    is_numeric("999A");

sub is_numeric {
    use POSIX qw(strtod);
    my $str = trim(shift);
    $! = 0;
    return if (! defined($str));
    my ($num, $unparsed) = strtod($str);
    if (($str eq '') || ($unparsed != 0) || $!) {  
        return;
    } else {
        return $num;
    }
}


## EXPECTS: 	either 6 or 2 inputs.
## RETURNS: 	Properly formated RA and DEC.
## EXAMPLES: 
##    checkradec ("245.23", "-90.00");
##    checkradec ("12", "00", "12", "-45", "12" "09");
sub checkradec {
    if (scalar(@_) == 2){
	return (checkdegRA($_[0]), checkdegDec($_[1]));
    } elsif (scalar(@_) == 6){
	return (checkhmsRA(@_[0..2]), checkhmsDec(@_[3..5]));
    } else {
	return undef;
    }

}



sub checkdegRA {
    my $ra = $_[0];
 
    if (! defined(is_numeric($ra))){
	return;
    } elsif (($ra < 0) || ($ra > 360)){
	return;
    } else {
	$ra = 0 if ($ra == 360);
	return sprintf("%02.6f", $ra);
    }
}


sub checkdegDec {
    my $dec = $_[0];
    if (! defined(is_numeric($dec))){
	return;
    } elsif (abs($dec) > 90){
	return;
    } else {
	return sprintf("%02.6f", $dec);
    }
}


sub checkhmsRA {

    return if (scalar(@_) != 3);

    my ($hh, $mm, $ss) = @_;
    return if (! defined(is_numeric($hh)) || 
	       ! defined(is_numeric($mm)) || 	      
	       ! defined(is_numeric($ss)));

    return if ( ($ss < 0) || ($ss >= 60) ||
		($mm < 0) || ($mm >= 60) ||
		($hh < 0) || ($hh > 24) );

    #check against 24 10 23 or something over 24
    return if (($hh == 24) && (!(($ss == 0) && ($mm == 0))));
    $hh = 0 if (($hh == 24) && (($ss && $mm) == 0));

    # format to have leading zeroes if necessary
    $ss = sprintf "%.3f", $ss;
    $ss = '0'.$ss if $ss < 10;

    return (sprintf("%02d", $hh), 
	    sprintf("%02d", $mm),
	     $ss);
 
	
}

sub checkhmsDec {

    return if (scalar(@_) != 3);

    my ($dd, $dm, $ds) = @_;
    return if (! defined(is_numeric($dd)) || 
	       ! defined(is_numeric($dm)) || 	      
	       ! defined(is_numeric($ds)));
    return if (abs($dd) > 90);
    #check against 90 01 23 or something over 90
    return if ((abs($dd) == 90) && 
	       (!((abs($dm) == 0) && (abs($ds) == 0))));
    return if	( abs($dm) >= 60);
    return if	( abs($ds) >= 60);
    
    #prevent against some user inputting -19 -34 -23
    my $numofnegs = 0;
    $numofnegs++ if ($dd < 0);
    $numofnegs++ if ($dm < 0);
    $numofnegs++ if ($ds < 0);
    
    return if ($numofnegs > 1);

    #checks to make sure there aren't formats like 19 -13 43 or 19 13 -43
    return if ( ($dm < 0) && !($dd == 0));
    return if ( ($ds < 0) && !(($dd == 0) && ($dm == 0)));

    #if dd is of the type -1 to -9, we need to insert a zero after the - sign
    if (abs($dd) < 10)
    {
	$dd =~ s/^\-+([1-9])/\-0$1/ ;
    }
    #scripts like radec.pl can't handle -00 from the command line 
    #while using the GetOption routine, so if the dec is -00 14 23
    #it will be entered as as 00 -14 23 and we'll need to reformat that
 
    if ( (($dm < 0) || ($ds < 0)) && ($dd == 0)) {
	($dm, $ds ) = map { abs($_) } ($dm, $ds);
	$dd = "-".$dd if ($dd !~ /^-\d+/);

    }


    # format to have leading zeroes if necessary
    $ds = sprintf "%.3f", $ds;
    $ds = '0'.$ds if $ds < 10;
    if ($dd =~ /^-/)
    {
	$dd = sprintf("%03s",$dd);
    }else{ 
	$dd = sprintf(" %02d",$dd);
    }
    $dm = sprintf("%02d", $dm);

    return ($dd, $dm, $ds);

	
}


sub is_caltarget {
    my $obs = check_obsid($_[0]);
    if (! $obs){
	die "Not a valid obsid!";
    } else {
	if ($obs > 50000 || ($obs >= 45000 && $obs <= 47500)){
	    return $obs;
	} else {
	    return;
	}
    }
}

sub stripleadingzeroes {
    my $obsid = $_[0];
    
    #Check Argument
    if (! defined ($obsid)){
        $obsid = undef;
    } else {
        $obsid =~ s/^0+//;
    }
    return $obsid;
}
sub parse_coord {
    
    my $in = shift; 
    my (%coord); 
    my ($page);
    my @obsids; 

    open (my $COORDS, "<$in") || die "Cannot Open Coord Page: $in\n";
    {
	local $/; 
	while (<$COORDS>){
	    $page .= $_;
	}
    }
    close($COORDS);
    

   
    ($page) = ($page =~ /\<tr class=\"head\"\>(.*)\<\/table\>/is); 
    my @coord = split /<\/tr>/i, $page;

    for (my $i=0; $i<@coord; $i++){
	if ($coord[$i] =~ /<tr class=\"entry\">|<tr class=\"entry_too\">/){
	    my @elements = split /<td>/i, $coord[$i];
	
	    for (my $j=0; $j < @elements; $j++){
		$elements[$j] = trim($elements[$j]);
		
	    }
	    
	    # need to strip out link part of obsid list
	    $elements[4]=~ /<a href(.*)\">([0-9]{5})<\/a>/; 
	    my $obsid = check_obsid($2); 
	    my $CDATE = ($elements[7] =~ /[A-Z]{3}[0-9]{4}/)? absolute2chandra(week2absolute($elements[7])) : 0;
	    
	    # storing constr/pref,targetname,observatories,simultaneity constr
	    # date (in chandra time) in the hash 
	    
	    $coord{$obsid} = [$elements[2], $elements[5],$elements[9],$elements[11], $CDATE];
	   
	}
    }

  return %coord; # return hash of info
}

sub parse_tooddt {

    my $in = shift; 
    my (%tooddt); 
    my ($page);

    open (my $TOOS, "<$in") || die "Cannot Open TOO/DDT Page: $in\n";
    {
	local $/; 
	while (<$TOOS>){
	    $page .= $_;
	}
    }
    close($TOOS);

    
    my (@block) = ($page =~ /.*?\<table border=1\>(.*?)\<\/table\>.*?\<table border=1\>(.*)\<\/table\>.*/is);
    for (my $z=0; $z<@block; $z++){
	my @type = qw(DDT TOO);
	my @toos = split /<tr.*?>/is, $block[$z];
	for (my $i=0; $i < @toos; $i++){
	    next unless ($toos[$i] =~ /<td/is);
	    my @elements = split /\<td\>/is, $toos[$i];
	    
	    for (my $j=0; $j < @elements; $j++){
		$elements[$j] =~ s/\<.*?\>//g;
		$elements[$j] = trim($elements[$j]);
	    }
	    
	    $elements[4] = check_obsid($elements[4]);
	    my $CDATE = ($elements[8] =~ /([A-Z]{3}[0-9]{4})/)? absolute2chandra(week2absolute($1)) : 0;

	    # if there's no obs-id, eg in the case of a pending DDT, then
	    # skip it since it won't affect the weeek. -swr
	    if($elements[4]){
		#$obsid =  coord, Targname, type, date, PI, Seqnum, Propnum
		$tooddt{$elements[4]} = [$elements[5], $elements[6], $type[$z], $CDATE, $elements[7], $elements[3], $elements[2]];
	    }
	}
    }
    return %tooddt;
}



1;

__END__

