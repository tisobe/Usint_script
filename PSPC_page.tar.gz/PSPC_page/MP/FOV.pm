package MP::FOV;

=head1 NAME

MP::FOV

=head1 PURPOSE

A Perl Extension to draw Chandra FOV's on FITS images.

=head1 SYNOPSIS

  use MP::FOV;
  make_fov(\%Obsids,$datavisType);
       or 
  ltsoverlay($MPcatID,\@obsid,\@roll);

=head1 DESCRIPTION

This module uses PDL, PGPLOT, CFITSIO, and WCSLib to create GIF images of the Chandra FOV plotted on top of images of the sky. The function make_fov() takes two arguments: 1) a hash reference with a number of mandatory and optional fields, and 2) a string that determines the type of datavis file from which to get the RA, dec, and roll for each obsid. The two allowed values for this parameter are "lts" or "soe", meaning, that make_fov() will read either the "$MPDIR/(seqnbr)/(seqnbr).(obsid).datavis" files (created by the SFE) or the "$MPDIR/(seqnbr)/(seqnbr).(obsid).soe.datavis" files (created by the Mission Schedule Comparator).

The first keys of the %Obsids hash should be obsids. The other keys should be:

SeqNbr (required): The sequence number for the obsid

SI     (required): The SI for the obsid

zsim   (optional): The Z sim (trans) offset, in mm

RA     (optional): (not used for plotting FOV) The RA label on the plot.

dec    (optional): (not used for plotting FOV) The dec label.

yoff   (optional): (not used for plotting FOV) The yoff label. Must be a string (not a number)!

zoff   (optional): (not used for plotting FOV) The zoff label. Must be a string!

SIMode (optional):  If si is ACIS and SIMode is either a SIMode or a Parameter Block it will download the neccessary chip info from mit and show the chips which are on and plot the subarray (if there is one).

ccdi0 to ccds5 (optional): For optional ACIS chips. A chip is either on, 'Y', off 'N', or optional (with number), 'O1'.
 

So, you might populate this hash with something like:

  $Obsid{'00711'}{SeqNbr} = 700001;       # obsid 711 has seqnbr 700001
  $Obsid{'00711'}{SI}     = 'ACIS-I';     # it's an ACIS-I observation
  $Obsid{'00711'}{zsim}   = 0.1;          # zsim offset of 0.1mm
  $Obsid{'00711'}{yoff}   = '0 arcmin';   # must be a string
  $Obsid{'00711'}{zoff}   = '0.1 arcmin'; # must be a string
  $Obsid{'00711'}{ccdi3}   = 'O1'; #I3 is the first optional chip.

The drawing algorithm makes use of the target_offset() C code. I have written some Perl XS code to interface this code with Perl. However, the target_offset() code itself is dependent on a routine from the Slalib code, which, if I recall correctly, has some copyright issues. However, the SFE and MSC make use of the target_offset() code, so this must have been worked around at some point. Some library dependencies will need to be changed in the Makefile.PL file for this module before it can be incoporated into the data system.

ltsoverlay() is basically just a wrapper to make_fov() that can be used by any program to easily create an overlay.  It currently however should be used in more long term planning and not short term scheduling although this ability could be easily added if the need arises.

=head2 EXPORTS
    
    make_fov()
    ltsoverlay()

=head2 Methods

=over 8

=item  make_fov

I<Usage>: 

    make_fov(\%Obsids, "soe");

I<Provides>: Given a Hash that contains obsids and information and the strring "soe" or "lts" the 3 overlays are created for the obsid.

I<Arguments>:

    \%Obsids  = hash reference:
      SeqNbr (required): The sequence number for the obsid
      SI     (required): The SI for the obsid
      zsim   (optional): The Z sim (trans) offset, in mm
      RA     (optional): (not used for plotting FOV) The RA label on the plot.
      dec    (optional): (not used for plotting FOV) The dec label.
      yoff   (optional): (not used for plotting FOV) The yoff label. Must be a string (not a number)!
      zoff   (optional): (not used for plotting FOV) The zoff label. Must be a string!
      SIMode (optional):  If si is ACIS and SIMode is either a SIMode or a Parameter Block.
                          it will download the neccessary chip info from mit and show the chips 
                          which are on and plot the subarray (if there is one).
      ccdi0 to ccds5 (optional): For optional ACIS chips. A chip is either on, 'Y', off 'N', or optional (with number), 'O1'.

    string    = "soe" or "lts"

I<Output>:

Produces 3 overlays for each of the different Surveys.

I<Examples>:
    
    make_fov(\%Obsids, "soe");

=item  ltsoverlay

I<Usage>: 

    ltsoverlay($MPcatID,\@obsidarray,\@rollarray);

I<Provides>: Given a reference to an MPCAT and list of obsids and rolls the 3 overlays are created for the obsid (info is passed to make_fov() ).

I<Arguments>:

    $MPcatID = Reference to a parsed MPCAT.
    @obsidarray = list of obsids.
    @rollarray = list of rolls.

I<Output>:

Produces 3 overlays for each of the different Surveys.

I<Examples>:
    
    ltsoverlay($MPcatID,\@obsidarray,\@rollarray);

=back


=head1 EXAMPLES

=over 8 

=item make_fov

Create a Overlay for observations in Products:

  make_fov(\%Obsids, "soe");

=item ltsoverlay

Create a Overlay for observations in the LTS:

  ltsoverlay($MPcatID,\@obsidarray,\@rollarray);

=back

=head1 NOTES


=head1 DEPENDENCIES

  use strict;
  use warnings;
  use Carp;
  use File::Copy;
  use MP::SkyView;
  use MP::Datavis;
  require Exporter;
  require DynaLoader;
  use AutoLoader;
  use PDL;
  use PDL::Graphics::PGPLOT;
  use PGPLOT;
  use CFITSIO;
  use WCSTools::LibWCS;
  use HTTP::Request::Common qw(GET);
  use LWP::UserAgent;

=head1 VERSION

$Revision: 1.6 $

=head1 AUTHOR

Author:  K Eriksen & J Grimes; rel 7/12/2001

  Last Update:    $Date: 2008/02/14 15:21:28 $ 
  Last Update by: $Author: patnaude $


=head1 HISTORY

=over 8

=item Ver: 1.7

no changes.

patnaude - 02/14/2008


=item Ver: 1.6

- A don't copy check was left out.

kkingsbury - 11/20/2006


=item Ver: 1.4

- Installed to wrong location, retrying.

kkingsbury - 11/20/2006


=item Ver: 1.3

- Forgot to add MANIFEST

kkingsbury - 11/20/2006


=item Ver: 1.2

- Added POD, imported into CVS Control.

- Added ACIS Dropped Chip information.

kkingsbury - 11/20/2006


=item Ver: 1.1

Initial revision

K Eriksen - 7/12/2001 

=back

=cut
########################################################################
#                        START CODE                                    #
########################################################################

require 5.005_62;
use strict;
use warnings;
use Carp;
use File::Copy;
use MP::SkyView;

require Exporter;
require DynaLoader;
use AutoLoader;
use Data::Dumper;

our @ISA = qw(Exporter DynaLoader);
our @EXPORT = qw( &make_fov &ltsoverlay);
our $VERSION = '1.7';


#
# This routine was automatically generated by h2xs
#
sub AUTOLOAD {
    # This AUTOLOAD is used to 'autoload' constants from the constant()
    # XS function.  If a constant is not found then control is passed
    # to the AUTOLOAD in AutoLoader.

    my $constname;
    our $AUTOLOAD;
    ($constname = $AUTOLOAD) =~ s/.*:://;
    croak "& not defined" if $constname eq 'constant';
    my $val = constant($constname, @_ ? $_[0] : 0);
    if ($! != 0) {
	if ($! =~ /Invalid/ || $!{EINVAL}) {
	    $AutoLoader::AUTOLOAD = $AUTOLOAD;
	    goto &AutoLoader::AUTOLOAD;
	}
	else {
	    croak "Your vendor has not defined MP::FOV macro $constname";
	}
    }
    {
	no strict 'refs';
	# Fixed between 5.005_53 and 5.005_61
	if ($] >= 5.00561) {
	    *$AUTOLOAD = sub () { $val };
	}
	else {
	    *$AUTOLOAD = sub { $val };
	}
    }
    goto &$AUTOLOAD;
}

bootstrap MP::FOV $VERSION;

# Preloaded methods go here.

use PDL;
use PDL::Graphics::PGPLOT;
use PGPLOT;
use CFITSIO;
use WCSTools::LibWCS;

use MP::Datavis;

our $MPDIR   = '/data/mp1/SEQNBR';
our $CDODIR  = '/data/udoc1/targets';
our @SURVEYS = qw(dss pspc rass);

# J Grimes
my $NACISROWS=1024;
my $ACISWEBPATH="http://acis.mit.edu/cgi-bin/get-atbls?tag=";
my @ACISPB=("fepCcdSelect","subarrayStartRow","subarrayRowCount");
use HTTP::Request::Common qw(GET);
use LWP::UserAgent;


my $ARCSEC_MM   =  20.4;     # plate scale
my $BORESIGHT_Y =  0.019333; # crude Y offset for boresight correction
my $BORESIGHT_Z = -0.015667; # crude Z offset for boresight correction

my @acisi = ([1,  23.5, -26.5],
	     [1, -26.5, -26.5],
	     [1, -26.5,  23.5],
	     [1,  23.5,  23.5],
	     [1,  23.5, -26.5],
	     [0,  -1.5, -26.5],
	     [1,  -1.5,  23.5],
	     [0,  23.5,  -1.5],
	     [1, -26.5,  -1.5], # end I chips
	     [0, -81.0,  55.9],
	     [1,  69.0,  55.9],
	     [1,  69.0,  30.9],
	     [1, -81.0,  30.9],
	     [1, -81.0,  55.9],
	     [0,  44.0,  30.9],
	     [1,  44.0,  55.9],
	     [0,  19.0,  55.9],
	     [1,  19.0,  30.9],
	     [0,  -6.0,  30.9],
	     [1,  -6.0,  55.9],
	     [1, -31.0,  55.9],
	     [1, -31.0,  30.9],
	     [1, -56.0,  30.9],
	     [1, -56.0,  55.9],
	     [0,  -1.5,  -1.5]);

my @aciss = ([1, -81.0,  12.5],
	     [1,  69.0,  12.5],
	     [1,  69.0 ,-12.5],
	     [1, -81.0, -12.5],
	     [1, -81.0,  12.5],
	     [0,  44.0, -12.5],
	     [1,  44.0,  12.5],
	     [0,  19.0,  12.5],
	     [1,  19.0, -12.5],
	     [0,  -6.0, -12.5],
	     [1,  -6.0,  12.5],
	     [0, -31.0,  12.5],
	     [1, -31.0, -12.5],
	     [0, -56.0, -12.5],
	     [1, -56.0,  12.5], # end S chips
	     [0,  23.5, -69.9],
	     [1, -26.5, -69.9],
	     [1, -26.5, -19.9],
	     [1,  23.5, -19.9],
	     [1,  23.5, -69.9],
	     [0,  -1.5, -69.9],
	     [1,  -1.5, -19.9],
	     [0,  23.5, -44.9],
	     [1, -26.5, -44.9],
	     [0, -1.5, -44.9]);

my @hrci = ([1,   0.0, -62.4],
	    [1, -62.4,  -0.0],
	    [1,   0.0,  62.4],
	    [1,  62.4,  -0.0],
	    [1,   0.0, -62.4],);

my @hrcs = ([1,  154.0, -10.00],
	    [1,  154.0,  10.00],
	    [1, -146.0,  10.00],
	    [1, -146.0, -10.00],
	    [1,  154.0, -10.00],
	    [0,   36.7, 10.00],
	    [1,   36.7,  5.35],
	    [1,  154.0,  5.35],
	    [0, -146.0,  5.35],
	    [1,  -28.7,  5.35],
	    [1,  -28.7, 10.00],
	    [0, -146.0,   -4.00],
	    [1,  -15.7,   -4.00],
	    [1,  -15.7, 10.00],
	    [0,  154.0,   -4.00],
	    [1,   15.7,   -4.00],
	    [1,   15.7, 10.00],);

my @aca = ([1,  123.5, -123.5],
	   [1, -123.5, -123.5],
	   [1, -123.5,  123.5],
	   [1,  123.5,  123.5],
	   [1,  123.5, -123.5],);

my @ichiplabs = ([0, -11.5, -11.5],
		 [1,  11.5, -11.5],
		 [2, -11.5,  11.5],
		 [3,  11.5,  11.5],
		 [4, -67.0,  43.4], # start S chips
		 [5, -42.0,  43.4],
		 [6, -17.0,  43.4],
		 [7,   9.0,  43.4],
		 [8,  33.0,  43.4],
		 [9,  58.0,  43.4],);

my @schiplabs = ([4, -67.0,   0.0],
		 [5, -42.0,   0.0],
		 [6, -17.0,   0.0],
		 [7,   9.0,   0.0],
		 [8,  33.0,   0.0],
		 [9,  58.0,   0.0],
		 [0, -11.5, -54.9],
		 [1,  11.5, -54.9],
		 [2, -11.5, -31.9],
		 [3,  11.5, -31.9],);

my %SI = ('ACIS-I' => \@acisi,
	  'ACIS-S' => \@aciss,
	  'HRC-I'  => \@hrci,
	  'HRC-S'  => \@hrcs  );

my %ChipLab = ('ACIS-I', => \@ichiplabs,
	       'ACIS-S', => \@schiplabs,);


#J Grimes - chip info


my %acis_chipinfo = (
	  'ACIS-I' => [[ [-26.5,-26.5], [-1.5,-1.5] ],
		[ [23.5, -1.5], [-1.5, -26.5] ],
		[ [-26.5,-1.5], [-1.5,23.5] ],
		[ [23.5, 23.5], [-1.5,-1.5] ],
		[ [-81,55.9], [-56, 30.9] ],
		[ [-56,55.9], [-31, 30.9] ],
		[ [-31,55.9], [-6, 30.9] ],
		[ [-6,55.9], [19,30.9] ],
		[ [19,55.9], [44,30.9] ],
		[ [44,55.9], [69,30.9]]],
	  'ACIS-S' => [[ [-26.5,-69.9], [-1.5,-44.9] ],
		[ [23.5, -44.9], [-1.5, -69.9] ],
		[ [-26.5,-44.9], [-1.5,-19.9] ],
		[ [23.5, -19.9], [-1.5,-44.9] ],
		[ [-81,12.5], [-56, -12.5] ],
		[ [-56,12.5], [-31, -12.5] ],
		[ [-31,12.5], [-6, -12.5] ],
		[ [-6,12.5], [19, -12.5] ],
		[ [19,12.5], [44, -12.5] ],
		[ [44,12.5], [69, -12.5]]],
		);









our %Units = ('dss'  => 'POSS scaled density',
	      'pspc' => 'PSPC cts/s/pixel',
	      'rass' => 'RASS counts');

our %StarSize = ('acq' => 20,
		 'gui' => 10,
		 'mon' => 30,);

our %StarColor = ('acq' => 12,
		  'gui' => 8,
		  'mon' => 6,);

our %StarType = ('acq' => 'Acq Star',
		 'gui' => 'Guide Star',
		 'mon' => 'Mon Star'   );

our %DefColor = ('dss'  => 4,
		 'pspc' => 4,
		 'rass' => 4,);

our %Histogram = ('pspc' => 1);

#J Grimes
my $ChipOnColor=13;
my $SubarrayColor=8;
my $TargPtrColor=2;



our $verbose = 0;

sub make_fov {


#J Grimes-set PGPLOT env values
    $ENV{PGPLOT_FONT}="/data/mpcrit1/pgplot/grfont.dat";
    $ENV{PGPLOT_RGB}="/data/mpcrit1/pgplot/rgb.txt";


    my($Obsids,$datavisType) = @_;

    umask 0002;

    local $| = 1 if $verbose;

   
    croak "datavis file type $datavisType not recognized...dying\n" unless
	$datavisType =~ /soe|SOE|lts|LTS/;

    my $type; # my $type == "sylvia"
    $type = 'soe.' if $datavisType =~ /soe|SOE/;
    $type = ''     if $datavisType =~ /lts|LTS/;

# J Grimes
# Get ACIS PB Data
    my %acis_data;
    my $ua = LWP::UserAgent->new;
    foreach my $key (keys %$Obsids) {
	next if ($Obsids->{$key}->{SI}!~m/ACIS/ || !$Obsids->{$key}->{SIMode}) ;
	if (!exists $acis_data{$Obsids->{$key}{SIMode}}) {
	    print "Retrieving ACIS Parameter Block Info for ",$Obsids->{$key}{SIMode},"\n" if $verbose;
	    $acis_data{$Obsids->{$key}{SIMode}}{Get}=
		$ua->request(GET $ACISWEBPATH . $Obsids->{$key}{SIMode});
	    foreach my $t (@ACISPB) {
		($acis_data{$Obsids->{$key}{SIMode}}{$t})=
		    $acis_data{$Obsids->{$key}{SIMode}}{Get}->{_content}=~m/$t\s*=\s*(.+)/;
		(defined $acis_data{$Obsids->{$key}{SIMode}}{$t} && 
		 $acis_data{$Obsids->{$key}{SIMode}}{$t} ne "") or 
		     $acis_data{$Obsids->{$key}{SIMode}}{$t}=0;		
		$acis_data{$Obsids->{$key}{SIMode}}{"fepCcdSelect"}=~s/(10|\s)//g if $acis_data{$Obsids->{$key}{SIMode}}{"fepCcdSelect"}=~m/\s/;
	    }
	    if ($Obsids->{$key}{SIMode} =~m/^(CC_|WC)/) {
		$acis_data{$Obsids->{$key}{SIMode}}{$ACISPB[1]}=0;
		$acis_data{$Obsids->{$key}{SIMode}}{$ACISPB[2]}=1023; 
	    }
	}
    }
    
    



    my @bad; # return a hash with the obsids of that CFITSIO choked on

    my $obsid;
    OUTER: foreach $obsid (keys %$Obsids){

	# test $CDODIR for disk space -- if it is
	# too low, abort the overlay creation

	my @df = `/usr/ucb/df $CDODIR/.`;
	for my $line (@df) {
	    my @line = split " ", $line;
	    next unless @line==6 and $line[1] =~ /^\d+$/;
	    my $avail   = $line[3];
	    my $percent = $line[4];

	    if ( $avail < 350 ) {

		# this is about the maximum size (in kb)
		# of a single FOV GIF

		print "\nWARNING!!\n$CDODIR is out of space; ",
		      "no more GIFs will be created\n\n";
		last OUTER;
	    }

	    last;
	}


	my $Obs = $Obsids->{$obsid};
	my $seq = $Obs->{SeqNbr};
	my $si  = $Obs->{SI};
	my $datavis = "$MPDIR/$seq/$seq.$obsid.$type" . "datavis";
	my ($Coords,$StarFid) = read_datavis($datavis);

	my $tra  = $Coords->{ra};
	my $tdec = $Coords->{dec};
	my $roll = $Coords->{roll};
	
	my $name=undef;
	if (exists $Obs->{name}) {
	    $name = $Obs->{name};

	    # limit the length of the target name
	    if (length($name) > 20) {
		$name = substr($name,0,20) . '...';
	    }
	}

	my $or_ra=$Obs->{RA};
	my $or_dec=$Obs->{dec};

	#
	# now loop over DSS, PSPC, and RASS images for each target
	#
	my $survey;
	foreach $survey (@SURVEYS){

	    carp "$CDODIR/$seq does not exist...creating!\n" unless -d "$CDODIR/$seq";
	    mkdir "$CDODIR/$seq" unless -d "$CDODIR/$seq";
	    carp "$MPDIR/$seq does not exist...creating!\n" unless -d "$MPDIR/$seq";
	    mkdir "$MPDIR/$seq" unless -d "$MPDIR/$seq";

	    my $fitsfile = "$MPDIR/$seq/$seq.$survey.fits";
		
	    #
	    # This is some CFITSIO stuff to get the size of the images
	    # and FITS header info for the WCSLIB routines
	    #
	    my $status = 0;
	    my $bitpix = 0;
	    my $naxes;
	    my $fptr = CFITSIO::open_file($fitsfile, CFITSIO::READONLY(), $status);
	    next if check_status($status,$fitsfile,$obsid,$survey,\@bad); # be a good CFITSIO citizen
	
	    $fptr->get_img_parm($bitpix,undef,$naxes,$status);
	    next if check_status($status,$fitsfile,$obsid,$survey,\@bad); # be a good CFITSIO citizen

	    my($naxis1, $naxis2) = @$naxes;

	    my $hdr;
	    $fptr->get_image_wcs_keys($hdr,$status);
	    next if check_status($status,$fitsfile,$obsid,$survey,\@bad); # be a good CFITSIO citizen

	    $fptr->close_file($status);
	    next if check_status($status,$fitsfile,$obsid,$survey,\@bad); # be a good CFITSIO citizen

	    #
	    # now, initialize the WCS object and get target pixels
	    #
	    my $wcs = WCSTools::LibWCS::wcsinit($hdr);  # WCS object. ick.
	    my ($xt,$yt);
	    my $offscale = 0;  # not sure what this does
	    $wcs->wcs2pix($tra,$tdec,$xt,$yt,$offscale);

	    #
	    # On the count of three....DRAW!
	    #
	    my $gif    = "$seq.$obsid." . $type . "$survey.gif";
	    my $mpgif  = "$MPDIR/$seq/$gif";
	    my $cdogif = "$CDODIR/$seq/$gif";

	    print "Creating FOV overlay $gif..." if $verbose;

	    my $pgplot = PDL::Graphics::PGPLOT::Window->new({
		Device => "$cdogif/gif",
#		Device => "./$gif/gif",
		Axis   => 'Empty',
		HardLW => 1,
		HardCH => 1,
		AxisColor => 1,
	    });
	    pgpap(0,1.0);  # preserve 1:1 aspect ratio
	    pgsfs(2);
	    $pgplot->env(0,$naxis1-1,0,$naxis2-1);

	    my $img = rfits $fitsfile;  # PDL::IO::Misc::rfits
	    my ($min,$max) = image_stretch($img,$survey);

	    my $bad = 0;
	    if( $min == $max && $max == 0.0){
		$max += 0.0001;
		$img->set(1,1,$max);
		$bad = 1;
	    }

	    $pgplot->imag($img, {Min => $min, Max => $max});

	    pgsci($DefColor{$survey});
	    pgpt(1,[$xt],[$yt],11);  # put a point at the target position
	    #actually this is really at the offset position above?
	    #think this is the HRMA pointing position really

	    #J Grimes #Actually put a cross at the target position
	    $wcs->wcs2pix($or_ra,$or_dec,$xt,$yt,$offscale);

	    my $lw;
	    pgqlw($lw);
	    pgsci($TargPtrColor);
	    pgsch(2.5);
	    pgslw(2*$lw);
	    pgpt(1,[$xt],[$yt],5);
	    pgsci($DefColor{$survey});
	    pgsch(1.0);
	    pgslw($lw);



	    my $siarray = [ @{ $SI{$si} } ];
	    my $point   =  shift @$siarray;
	    
	    my $zsim = 0;
	    $zsim = $Obs->{zsim} if $Obs->{zsim};
	    my $xoff = $point->[1] * $ARCSEC_MM / 3600.0;
	    my $yoff = ($point->[2] + $zsim) * $ARCSEC_MM / 3600.0;
	    my ($x,$y) = getxy($wcs,$tra,$tdec,$roll,$xoff,$yoff);
	    pgmove($x,$y);
	    foreach $point (@$siarray){
		$xoff = $point->[1] * $ARCSEC_MM / 3600.0;
		$yoff = ($point->[2] + $zsim) * $ARCSEC_MM / 3600.0;
		($x,$y) = getxy($wcs,$tra,$tdec,$roll,$xoff,$yoff);
		pgdraw($x,$y) if $point->[0];
		pgmove($x,$y) unless $point->[0];
	    }

#Test optional Chips:
	    my @crossS = (
			 [3, 12, 2, 13],
			 [13, 11, 12, 10],
			 [10, 8, 11, 9],
			 [9, 7, 8, 6],
			 [6, 4, 7, 5],
			 [5, 1, 4, 0], #end ACIS-S
			 [22, 19, 15, 23], #ACIS-I
			 [23, 18, 19, 21],
			 [16, 23, 22, 20],
			 [20, 21, 23, 17],
			 );
	    my @crossI = (
			  [12, 21, 11, 22],
			  [22, 20, 21, 19],
			  [19, 17, 20, 18],
			  [18, 16, 17, 15],
			  [15, 13, 16, 14],
			  [14, 10, 13, 9],
			  [0, 23, 7, 4],
			  [4, 6, 23, 3],
			  [1, 23, 7, 5],
			  [5, 6, 23, 2],
			  );


	    #124 252   034 139  34  	51 	153 	0
	    pgscr(3,(51/255),(153/255),(0/255));
	    pgsci(3);
	    pgsch(0.6);
	    # fake an 'off' chip to test:
            #$Obsids->{$obsid}{"ccds5"} = 'O6';
	    my $optionalchips = 0;
	    if ($si =~ /ACIS-(?:I|S)/){
		foreach my $key (keys %{$Obsids->{$obsid}}){
		    if ($key =~ /^ccd((?:i|s))(\d{1})$/i){
			my ($array, $chip) = ($1, $2);
			my $chip_digit = $chip; 
			#0-5 is s 6-9 is i
			$chip += 6 if $array eq "i";
			if ($Obsids->{$obsid}{$key} =~ /^O(\d{1,2})$/i){
			    $optionalchips++;
			    my $optional = $1;
			    
			    #acisi = 0-3, acisi 4-9
			    my $chipwebnumber = $chip_digit;
			    $chipwebnumber += 4 if  $array eq "s";
				
                            #Draw Cross if chip is off: 
			    if ( $Obsids->{$obsid}{SIMode} && $acis_data{$Obsids->{$obsid}{SIMode}}{"fepCcdSelect"}!~m/$chipwebnumber/) {
				for (my $j=0; $j<=1; $j++){
				    my @xs;
				    my @ys;
				    my $corners; 
				    if ($si =~ /ACIS-S/){
					$corners = $crossS[$chip];
				    } else {
					$corners = $crossI[$chip];
				    }
				    
				    $point = $siarray->[$corners->[0+(2*$j)]];
				    $xoff = $point->[1] * $ARCSEC_MM / 3600.0;
				    $yoff = ($point->[2] + $zsim) * $ARCSEC_MM / 3600.0;
				    ($x,$y) = getxy($wcs,$tra,$tdec,$roll,$xoff,$yoff);
				    push @xs, $x;
				    push @ys, $y;
				    $point = $siarray->[$corners->[1+(2*$j)]];;
				    $xoff = $point->[1] * $ARCSEC_MM / 3600.0;
				    $yoff = ($point->[2] + $zsim) * $ARCSEC_MM / 3600.0;
				    ($x,$y) = getxy($wcs,$tra,$tdec,$roll,$xoff,$yoff);
				    push @xs, $x;
				    push @ys, $y;
				    pgline(2, \@xs, \@ys);
				}
			    }

			    # Now Number:
			    my $corners; 
			    if ($si =~ /ACIS-S/){
				$corners = $crossS[$chip];
			    } else {
				$corners = $crossI[$chip];
			    }
			    my $midxa = ($siarray->[$corners->[0]]->[1] * $ARCSEC_MM / 3600.0);
			    my $midxb = ($siarray->[$corners->[1]]->[1] * $ARCSEC_MM / 3600.0);
			    my $midya = (($siarray->[$corners->[0]]->[2]+$zsim) * $ARCSEC_MM / 3600.0);			
			    my $midyb = (($siarray->[$corners->[1]]->[2]+$zsim) * $ARCSEC_MM / 3600.0);
			    my $textx = (($midxa + $midxb)/2);
			    my $texty = (($midya + $midyb)/2);
			    my $shiftx = abs($midxb - $midxa)/4;
			    my $shifty = abs($midyb - $midya)/4;
			    if (($roll >= 315  && $roll <= 360)  || ($roll >= 0  && $roll < 45)){
				$texty -= $shifty;
			    } elsif ($roll >= 45  && $roll < 135){
				#$texty -= $shifty;
				$textx += $shiftx;
			    } elsif ($roll >= 135  && $roll < 225){
				$texty += $shifty;	     
			    } else {
				#$roll >= 225  && $roll < 315){
				$textx -= $shiftx;
			    }
			    ($x,$y) = getxy($wcs,$tra,$tdec,$roll,$textx,$texty);
			    pgptxt($x,$y,0,0.5,$optional);
			    #pgmtxt('B', -0.5,
			}
		    }
		}
	    }
	    if ($optionalchips){
		pgptxt(($naxis2/2),10,0,0.5,"Green denotes presence and ordering of optional ACIS chips");
	    }
	    
# J Grimes
	    if ($si=~/ACIS/ && $Obsids->{$obsid}{SIMode} && 
		$acis_data{$Obsids->{$obsid}{SIMode}}{"subarrayRowCount"}!=1023) {
		for(my $n=0;$n<length($acis_data{$Obsids->{$obsid}{SIMode}}{"fepCcdSelect"});$n++) {
		    my $chip=substr($acis_data{$Obsids->{$obsid}{SIMode}}{"fepCcdSelect"},$n,1);
		    
		    my $startrow=$acis_data{$Obsids->{$obsid}{SIMode}}{"subarrayStartRow"};
		    my $endrow=$startrow+$acis_data{$Obsids->{$obsid}{SIMode}}{"subarrayRowCount"};


		    my ($xoff,$yoff,$xoff2,$yoff2);
		    if ($chip<4) {
			$xoff = ($startrow*($acis_chipinfo{$si}[$chip][1][0]-$acis_chipinfo{$si}[$chip][0][0])
				    /$NACISROWS)+$acis_chipinfo{$si}[$chip][0][0];
			$yoff = ($acis_chipinfo{$si}[$chip][0][1] + $zsim);
			$xoff2 = ($endrow*($acis_chipinfo{$si}[$chip][1][0]-$acis_chipinfo{$si}[$chip][0][0])
				    /$NACISROWS)+$acis_chipinfo{$si}[$chip][0][0];
			$yoff2 = ($acis_chipinfo{$si}[$chip][1][1] + $zsim);
		    } else {
			$xoff = $acis_chipinfo{$si}[$chip][0][0];
			$yoff = ($startrow*($acis_chipinfo{$si}[$chip][1][1]-$acis_chipinfo{$si}[$chip][0][1])
				 /$NACISROWS + $acis_chipinfo{$si}[$chip][0][1] + $zsim);
			$xoff2 = $acis_chipinfo{$si}[$chip][1][0];
			$yoff2 = ($endrow*($acis_chipinfo{$si}[$chip][1][1]-$acis_chipinfo{$si}[$chip][0][1])
				 /$NACISROWS + $acis_chipinfo{$si}[$chip][0][1] + $zsim);
		    }
		    pgsci($SubarrayColor);
		    my ($x1,$y1) = getxy($wcs,$tra,$tdec,$roll,$xoff*$ARCSEC_MM/3600,$yoff*$ARCSEC_MM/3600);
		    my ($x2,$y2) = getxy($wcs,$tra,$tdec,$roll,$xoff*$ARCSEC_MM/3600,$yoff2*$ARCSEC_MM/3600);
		    my ($x3,$y3) = getxy($wcs,$tra,$tdec,$roll,$xoff2*$ARCSEC_MM/3600,$yoff2*$ARCSEC_MM/3600);
		    my ($x4,$y4) = getxy($wcs,$tra,$tdec,$roll,$xoff2*$ARCSEC_MM/3600,$yoff*$ARCSEC_MM/3600);
		    pgmove($x1,$y1);
		    pgdraw($x2,$y2);
		    pgdraw($x3,$y3);
		    pgdraw($x4,$y4);
		    pgdraw($x1,$y1);
		}
	    }






	    # now chip labels;
	    if( $si =~ /ACIS/ ){
		foreach $point (@{ $ChipLab{$si} }){
		    my $chip = $point->[0];
		    
		    # J Grimes
		    if ( $Obsids->{$obsid}{SIMode} && $acis_data{$Obsids->{$obsid}{SIMode}}{"fepCcdSelect"}=~m/$chip/) {
			pgsci($ChipOnColor);
			pgsch(1.0);
		    } else {
			pgsci($DefColor{$survey});
			pgsch(.7);
		    }

		    $xoff    = $point->[1] * $ARCSEC_MM / 3600.0;
		    $yoff    = ($point->[2] + $zsim) * $ARCSEC_MM / 3600.0;
		    ($x,$y)  = getxy($wcs,$tra,$tdec,$roll,$xoff,$yoff);
		    
		    # J Grimes
		    my $achip= $chip > 3 ? $chip-4 : $chip;
		    pgptxt($x,$y,0,0.5,$achip);
		}
	    }
	    pgsci($DefColor{$survey});
	    pgsch(1.0);


	    # for the DSS, plot stars and ACA FOV
	    if( $survey eq 'dss' ){
		my @acatmp = @aca;
		($xoff,$yoff) = @{ shift @acatmp }[1,2];
		$xoff *= $ARCSEC_MM / 3600.0;
		$yoff *= $ARCSEC_MM / 3600.0;  # no zsim offsets for the ACA
		my ($bra,$bdec) = offset($tra,$tdec,$roll,$BORESIGHT_Y,$BORESIGHT_Z);
		($x,$y) = getxy($wcs,$bra,$bdec,$roll,$xoff,$yoff);
		pgmove($x,$y);

		foreach $point (@acatmp){
		    $xoff = $point->[1] * $ARCSEC_MM / 3600.0;
		    $yoff = $point->[2] * $ARCSEC_MM / 3600.0;
		    ($bra,$bdec) = offset($tra,$tdec,$roll,$BORESIGHT_Y,$BORESIGHT_Z);
		    ($x,$y) = getxy($wcs,$bra,$bdec,$roll,$xoff,$yoff);
		    pgdraw($x,$y);
		}

		# Star and Fid data
		my $star_type;
		foreach $star_type ('acq','gui','mon'){
		    my $id;
		    my $offscale = 0;
		    foreach $id (keys %{$StarFid->{$star_type}}){
			my $star = $StarFid->{$star_type}{$id};
			my $ra   = $star->{ra};
			my $dec  = $star->{dec};
			$wcs->wcs2pix($ra,$dec,$x,$y,$offscale);
			pgsci($StarColor{$star_type});
			pgcirc($x,$y,$StarSize{$star_type}/(1024/$naxis1));
		    }
		}
		my @fidx = ();
		my @fidy = ();
		my $fid;
		foreach $fid (keys %{$StarFid->{'fid'}}){
		    my $ra  = $StarFid->{'fid'}{$fid}{ra};
		    my $dec = $StarFid->{'fid'}{$fid}{dec};
		    $wcs->wcs2pix($ra,$dec,$x,$y,$offscale);
		    push @fidx, $x;
		    push @fidy, $y;
		}
		my $fidnum = @fidx; 
		pgsci(2);
		pgsch(0.5);
		pgpt($fidnum,\@fidx,\@fidy,19);
		pgsch(1);

		# label stars and fids
		if( $StarFid ){
		    my $text_y = int($naxis2 / 20);
		    my $text_x = int($naxis1 / 20);
		    my $x_step = $naxis2/4;
		    my $t_off  = 30;
		    foreach $star_type ('gui','acq','mon'){
			pgsci($StarColor{$star_type});
			pgcirc($text_x,($text_y + ($StarSize{$star_type}/2)),
			       $StarSize{$star_type}/(1024/$naxis1));
			pgptxt($text_x + $t_off,$text_y,0,0,$StarType{$star_type});
			$text_x += $x_step;
		    }
		    pgsci(2);
		    pgsch(0.5);
		    pgpt(1,[$text_x],[$text_y],19);
		    pgsch(1);
		    pgptxt($text_x + $t_off,$text_y,0,0,"Fid Light");
		}
	    }
		
	    #
	    # Label the RA, dec, and roll using basically the same
	    # algorithm as for the stars and fids above
	    #
	    my $text_y = int( $naxis2 - $naxis2/20 );
	    my $text_x = int( $naxis1/20 );
	    my $x_step = $naxis2/3;
	    $Obs->{RA}   = $tra unless $Obs->{RA};
	    $Obs->{dec}  = $tdec unless $Obs->{dec};
	    pgsci($DefColor{$survey});
	    pgptxt($text_x,$text_y,0,0,"RA = $Obs->{RA}");
	    $text_x += $x_step;
	    pgptxt($text_x,$text_y,0,0,"DEC = $Obs->{dec}");
	    $text_x += $x_step;
	    pgptxt($text_x,$text_y,0,0,"ROLL = $roll");

	    # 
	    # Now, label offsets if they're defined;
	    #
	    $text_x  = int( $naxis1/20 );
	    $text_y -= int( $naxis2/20 );
	    pgptxt($text_x,$text_y,0,0,"YOFF = $Obs->{yoff}") if $Obs->{yoff};
	    $text_x += $x_step;
	    pgptxt($text_x,$text_y,0,0,"ZOFF = $Obs->{zoff}") if $Obs->{zoff};
	    $text_x += $x_step;
	    pgptxt($text_x,$text_y,0,0,"ZSIM = $zsim mm");
	    $text_x += $x_step;

	    $text_x  = int( $naxis1/20 );
	    $text_y -= int( $naxis2/20 );
	    
	    pgptxt($text_x,$text_y,0,0,"ACIS PB = $Obs->{SIMode}") if ($datavisType =~ /SOE|soe/ && $Obs->{SIMode});
	    pgptxt($text_x,$text_y,0,0,"SI Mode = $Obs->{SIMode}") if ($datavisType =~ /LTS|lts/ && $Obs->{SIMode});

	    # 
	    # if $img contains no useful data ($bad > 0),
	    # print a message on the image
	    #
	    pgptxt(50,20,0,0,
		   "*** The $survey has no data at this pointing ***")
		if $bad;

	    #
	    # Now, make the nice box with coordinates
	    #
	    my ($ra1,$dec1,$ra2,$dec2);
	    $wcs->pix2wcs(1,1,$ra1,$dec1);
	    $wcs->pix2wcs($naxis1,$naxis2,$ra2,$dec2);

	    if ( $ra1 < $ra2 ) {
		$ra1 += 360;
	    }
	    if ( $dec2 < $dec1 ) {
		$dec2 += 180;
	    }

	    pgsci(11);
	    pgsch(.85);
	    pgswin($ra1,$ra2,$dec1,$dec2);

	    # get nearest minute for beginning RA label
	    my ($hh, $mm, $ss) = deg2hms($ra1);
	    my $begin_ra = hms2deg($hh,$mm,0);

	    # get RA scale so we know how often to label
	    # the axis (otherwise labels will overlap at
	    # high declinations)
	    my $diff = abs( $ra1 - $ra2);
	    my $label_int;
	    if ( $diff > 10) {
		$label_int = 12;
	    } elsif ( $diff >= 7 and $diff < 10) {
		$label_int = 9;
	    } elsif ( $diff >= 5 and $diff < 7) {
		$label_int = 6;
	    } elsif ( $diff >= 3 and $diff < 5) {
		$label_int = 3;
	    } else {
		$label_int = 2;
	    }


	    # get RAs every minute and draw tickmarks,
	    # labelling every $label_int minutes

	    pgbox('B',0,0,'',0,0);
	    my $radelta = .25;

	    my $j = $label_int;
	    for ( my $ra = $begin_ra; $ra > $ra2; $ra -= $radelta ) {

		my $frac = abs( ($ra - $ra1) / ($ra2 - $ra1) );
		# this tells PGPLOT where to put the tickmark,
		# in terms of a fraction of the total distance
		# along the axis
		
		if ( $j == $label_int ) {
		    # label with hms RA every $label_int arcmin.
		    my $ra_tmp = $ra;
		    $ra_tmp -= 360 if $ra_tmp >=360;
		    my ($h,$m,$s) = deg2hms($ra_tmp);
		    my $hms = sprintf "%2.2dh%2.2dm", $h, $m;
	
		    pgtick($ra1,$dec1,$ra2,$dec1,$frac,0.75,0.0,0.5,0.0,$hms);
		    $j = 0;
		} 
		else {
		    # only draw the tickmark
		    pgtick($ra1,$dec1,$ra2,$dec1,$frac,0.25,0.0,0.5,0.0,'');
		}

		$j++;
	    }

	    
	    # do it again for the top axis, only in degrees
	    # (increment by .2 degrees, label every degree,
	    # starting with the nearest .2 degree)
	    pgbox('C',0,0,'',0,0);

	    my $begin_ra2 = sprintf "%.1f", $ra1;
	    my $tmp_ra = int($begin_ra2 * 10);
	    while ( ($tmp_ra/2) != int($tmp_ra/2) ) {
		$tmp_ra--;
		$tmp_ra = int($tmp_ra);
		if ($tmp_ra < -360) {
		    croak "something went wrong";
		}
	    }
	    $begin_ra2 = sprintf "%.1f", $tmp_ra/10;

	    my $radelta2 = .2;
	    for ( my $ra = $begin_ra2; $ra > $ra2; $ra -= $radelta2 ) {
		
		my $frac = abs( ($ra - $ra1) / ($ra2 - $ra1) );
		
		$ra = sprintf "%.1f", $ra;
		if ( $ra == int($ra) ) {
		    my $ra_tmp = $ra;
		    $ra_tmp -= 360 if $ra_tmp >=360;
		    $ra_tmp = sprintf "%d", $ra_tmp;
		    pgtick($ra1,$dec2,$ra2,$dec2,
			   $frac,0.0,0.75,-0.5,0.0,$ra_tmp);
		} 
		else {
		    pgtick($ra1,$dec2,$ra2,$dec2,
			   $frac,0.0,0.25,-0.5,0.0,'');
		}

	    }


	    # get nearest 10 arcminutes for beginning Dec label
	    my ($dd, $dm, $ds) = deg2dms($dec1);
	    $dm = 10 * int($dm/10);
	    $dm += 10 if $dec1 < 0;
	    if ( $dec1 < 0 and $dec1 > -1 ) {
		$dd = -.000000001;
	    }
	    my $begin_dec = dms2deg($dd, $dm, 0);

	    # get Decs every 10 arcminutes and draw
	    # tickmarks, labelling every 20 arcmin.
	    pgbox('',0,0,'BC',0,0);

	    my $decdelta = (1/6);
	    my $k = 0;
	    for ( my $dec = $begin_dec; $dec < $dec2; $dec += $decdelta ) {

		my $frac = abs( ($dec - $dec1) / ($dec2 - $dec1) );
		
		if ( $k == 2 ) {
		    my $dec_tmp = $dec;
		    $dec_tmp -= 180 if $dec_tmp > 90;
		    
		    my ($d,$m,$s) = deg2dms($dec);
		    my $dms;
		    if ($dec < 0 and $dec > -1) {
			$dms = sprintf "-%2.2d %2.2d'", $d, $m;
		    } else {
			$dms = sprintf "%2.2d %2.2d'", $d, $m;
		    }
		    
		    pgtick($ra1,$dec1,$ra1,$dec2,
			   $frac,0.0,0.75,-0.5,0.0,$dms);

		    $k = 0;
		} 
		else {
		    pgtick($ra1,$dec1,$ra1,$dec2,
			   $frac,0.0,0.25,-0.5,0.0,'');
		}

		$k++;
}


	    pgsch(1);


	    
	    pgwedg('RG',0.25,3,$min,$img->max,"$Units{$survey}");

	    my $sched = '';
	    $sched = 'Prelim. Roll' if $datavisType =~ /LTS|lts/;
	    $sched = 'ST Scheduled' if $datavisType =~ /soe|SOE/;

	    my $title="Seq \# $seq, Obsid $obsid, $sched";
	    $title="Name $name, Seq \# $seq, Obsid $obsid, $sched" if defined $name;

	    $pgplot->label_axes('RA (J2000)',
				'Dec (J2000)',
				$title,
				{Color => 11});

	    pgsci(11);
	    pgiden();
	    $wcs->free;
	    print "done.\n" if $verbose;
	}
    }

    # now copy the GIFs over to the MP area (is this still useful?)
    if ($MPDIR !~ /$CDODIR/) {
	print "copying gifs to MP area ..." if $verbose;
	foreach $obsid (keys %$Obsids){
	    my $Obs = $Obsids->{$obsid};
	    my $seq = $Obs->{SeqNbr};
	    my $survey;
	    foreach $survey (@SURVEYS){
		my $gif = "$seq.$obsid." . $type . "$survey.gif";
		my $cdogif = "$CDODIR/$seq/$gif";
		my $mpgif  = "$MPDIR/$seq/$gif";
		copy $cdogif, $mpgif;
	    }
	}
	print "done.\n" if $verbose;
    }
    return \@bad;
}

#
# Return image min and max values, unless $Histogram{$survey}
# is set, in which case do a crude histogram equalization
#
sub image_stretch {
    my ($img,$survey) = @_;

    my $long = $img->copy;
    my $numl = $long->nelem;

    my $hcut;
    if( $Histogram{$survey} ){
	$long = $long->where($long > -1);  # gets rid of those annoying -1's in the PSPC images
	$long = qsort( $long->reshape($numl) );
	my $idx  = int( $numl * 0.999 );
	$hcut = $long->at($idx);
    }

    my $min  = $long->min;
    my $max  = $long->max;

    $max = $hcut if $Histogram{$survey};

    return ($min,$max);
}

sub getxy {
    my ($wcs,$tra,$tdec,$roll,$xoff,$yoff) = @_;

    my ($x,$y,$offscale);

    my ($ra,$dec) = offset($tra,$tdec,$roll,$xoff,$yoff);
    $wcs->wcs2pix($ra,$dec,$x,$y,$offscale);

    return $x,$y;
}

# check CFITSIO status
sub check_status {
    my $s = shift;
    my $f = shift;
    if ($s != 0) {
        my $txt;
      CFITSIO::fits_get_errstatus($s,$txt);
        carp "CFITSIO error ($f): $txt";
	my($obsid,$survey,$bad) = @_;
	push @$bad, [$obsid, $survey];
        return 1;
    }

    return 0;
}


#Created J Grimes 10/23/01
sub ltsoverlay {
    my ($MPcatID,$obsidptr,$rollptr)=@_;

    my %Obsids;

    for (my $k=0;$k<scalar(@$obsidptr);$k++) {
	my $obsid=$$obsidptr[$k];
	my $roll=$$rollptr[$k];
	my $ra   = $MPcatID->{$obsid}{ra};
	my $dec  = $MPcatID->{$obsid}{dec};

	$Obsids{$obsid}{RA}  = sprintf "%9.5f", $ra;
	$Obsids{$obsid}{dec} = sprintf "%9.5f", $dec;
	
	my $yoff = 0.0;
	my $zoff = 0.0;
	my $zsim = 0.0;
	$yoff = $MPcatID->{$obsid}{'y-detector-offset'} if $MPcatID->{$obsid}{'y-detector-offset'};
	$zoff = $MPcatID->{$obsid}{'z-detector-offset'} if $MPcatID->{$obsid}{'z-detector-offset'};
	$zsim = $MPcatID->{$obsid}{'sim-trans-offset'} if $MPcatID->{$obsid}{'sim-trans-offset'};
	$Obsids{$obsid}{yoff} = sprintf "%5.2f'", $yoff;
	$Obsids{$obsid}{zoff} = sprintf "%5.2f' ", $zoff;
	$Obsids{$obsid}{zsim} = sprintf "%7.3f", $zsim;
	$Obsids{$obsid}{SeqNbr} = $MPcatID->{$obsid}{'seq-nbr'};
	$Obsids{$obsid}{SI}     = $MPcatID->{$obsid}{si};
	$Obsids{$obsid}{name}   = $MPcatID->{$obsid}{'name'} if $MPcatID->{$obsid}{'name'};
	

	my $seq= $MPcatID->{$obsid}{'seq-nbr'};
	
	if( abs($yoff) > 0 || abs($zoff) > 0 ){
	    # J Grimes added negative to zoff
	    ($ra,$dec) = MP::FOV::offset($ra,$dec,$roll,$yoff/60.0,-1*$zoff/60.0);
	}
	
	write_datavis($MPcatID->{$obsid}{'seq-nbr'},$obsid,$ra,$dec,$roll);
	
	if ($MPcatID->{$obsid}{si}=~m/ACIS/ && $MPcatID->{$obsid}{'si-mode'}) {
	    $Obsids{$obsid}{SIMode}=$MPcatID->{$obsid}{'si-mode'};
	}
	
	# Optional I
	my $field = "ccd";
	for (my $i =0; $i<4; $i++){
	    $Obsids{$obsid}{$field . "i" .$i} = $MPcatID->{$obsid}{$field."i".$i};
	}

	# Optional S
	for (my $s =0; $s<6; $s++){
	    $Obsids{$obsid}{$field . "s" .$s} = $MPcatID->{$obsid}{$field."s".$s};
	}
    }
	
    # create overlays
    # get FITS images from SkyView that had troubles,
    # and try again (this code lifted from weekly.pl)
    my $badfits = make_fov(\%Obsids,"lts");
    my $numbad  = @$badfits;

    # these are bad FITS images -- get them from SkyView and try again
    if( $numbad > 0 ){
        print "\n\n *** Some of the FITS images were either missing or corrupt ***\n";
        print " *** I'm going to get them from SkyView and try again ***\n\n";
	
        my (@tryagain, %TryAgain);
        my $corrupt;
        foreach $corrupt (@$badfits){
            my ($obsid,$survey) = @$corrupt;
            my $seq = $Obsids{$obsid}{SeqNbr};
            my $badfile = "$MP::FOV::MPDIR/$seq/$seq.$survey.fits";
            unlink $badfile if -e $badfile;
            push @tryagain, $obsid;
            $TryAgain{$obsid} = $Obsids{$obsid};
        }
        get_ims(\@tryagain, $MPcatID);
	
        my $badagain = make_fov(\%TryAgain,"lts");
	
        if( @$badagain ){
            print STDERR "\n *** Uh-oh...looks like there are still bad FITS file ***\n";
            print STDERR " *** this is probably a bug with HEASARC's SkyView, giving up ***\n";
        }
    }

}

sub write_datavis {
    my($seq,$obsid,$ra,$dec,$roll) = @_;

    my $date = localtime;
    my $me = getpwuid($<);
    my $datavis = "$MP::FOV::MPDIR/$seq/$seq.$obsid.datavis";

    open(DATAVIS,">$datavis") or
        warn "could not open datavis file $datavis for writing: $!\n" and return;

    print DATAVIS "#\n";
    print DATAVIS "# This file created by ltspage.pl on $date by $me\n";
    print DATAVIS "# note that there are no stars and fids -- run the sfe if you want them\n";
    print DATAVIS "#\n";
    print DATAVIS "# Seq_Nbr   RA (deg)    Dec (deg)  Roll (deg)\n";
    print DATAVIS "# -------  ----------  ----------  ----------\n";
    printf DATAVIS "  %s   %9.5f    %9.5f   %7.3f\n",$seq,$ra,$dec,$roll;

    close(DATAVIS);
}

sub deg2hms {

    my $ra = $_[0];

    my $hh = int( $ra/15 );
    my $mm = int( 60 * ($ra/15 - $hh));
    my $ss = 60 * ( 60 * ($ra/15 - $hh) - $mm);

    $ss = 0 if $ss < .00001;
    if ( $ss > 59.999 ) {
	$ss = 0;
	$mm++;
	if ($mm >= 60) {
	    $mm -= 60;
	    $hh++;
	}
    }
    
    return ($hh,$mm,$ss);
}

sub deg2dms {

    my $dec = $_[0];

    $dec =~ s/^\+//;    
    my $dd = int($dec);
    my $dm = int( 60 * ($dec - $dd) );
    my $ds = 60 * ( 60 * ($dec - $dd) - $dm);

    if ( $dm < 0 ) {
	$dm = -$dm; 
    } 
    if ( $ds < 0 ) {
	$ds = -$ds;
    }

    $ds = 0 if $ds < .00001;
    if ( $ds > 59.999 ) {
	$ds = 0;
	$dm++;
	if ($dm >= 60) {
	    $dm -= 60;
	    $dd++;
	}
    }

    return ($dd,$dm,$ds);

}

sub hms2deg {

    my $hh = $_[0];
    my $mm = $_[1];
    my $ss = $_[2];

    my $ra = 15 * ($hh + $mm/60 + $ss/3600);
    
    return $ra;
}

sub dms2deg {

    my $dd = $_[0];
    my $dm = $_[1];
    my $ds = $_[2];

    $dd =~ s/^\+//;
    if ( $dd < 0 ) {
	$dd = 0 if ( abs($dd) < .00000001 );
        $dm = -$dm if $dm > 0;
        $ds = -$ds if $ds > 0;
    }

    my $dec = $dd + $dm/60 + $ds/3600;

    return $dec;

}




1;
__END__

