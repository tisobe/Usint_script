#!/data/mpcrit1/bin/perl -w

use blib;

($foo,$bar) = MP::FOV::offset(0.0,0.0,0.0,0.0,0.0);
