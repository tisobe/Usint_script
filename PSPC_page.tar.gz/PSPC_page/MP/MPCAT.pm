package MP::MPCAT;

=head1 NAME

MP::MPCAT

=head1 PURPOSE

A Perl Extension  to parse an MPCAT file.

=head1 SYNOPSIS

  use MP::MPCAT;
  $MPcatID = read_mpcatID( $mpcatfilename );
  $MPcat   = read_mpcat( $mpcatfilename );
  $MPcatID = quickread_mpcatIDs(@obsids);

=head1 DESCRIPTION

This module supplies three routines, read_mpcatID() , read_mpcat() , and diff_mpcats , that take an MPCAT filename as an argument, and return a Perl reference to a hash that contains the info in the MPCAT file. There is another routine, quickread_mpcatIDs, that takes a list of obsids as an argument and returns a hash of selected information for those obsid from the mpcat XML file. In general, since sequence numbers do not necessarily have a single obsid, you want to use read_mpcatID() . For sequence numbers with multiple obsids, the hash returned by read_mpcat() will only point to the info in one obsid (the last one listed in the MPCAT). You've been warned!

The returned data structure is a "hash of hashes". This may sound complicated, but it's actually quite simple. Each obsid or sequence number (depending on whether you called read_mpcatID() or read_mpcat() ) has is its own hash in which the MPCAT keywords (e.g. :id, :name, :ra, etc.) minus the leading ":"'s are the keys, and the MPCAT values are the hash values. These obsid hashes are contained in another hash whose keys are the obsids or sequence numbers. Still confused? Perhaps some examples will help...

diff_mpcats() takes 2 mpcat file names and returns an array pointer.  It literally diffs the 2 mpcats and returns the obsids in the first mpcat that are different in the second mpcat (or did not exist).  It can also optionally take a array pointer as its third argument that is the name of a key in an mpcat and it will then only diff those keys.


=head2 EXPORTS
    
    read_mpcatID()
    read_mpcat()
    diff_mpcats()
    quickread_mpcatIDs()

=head2 Methods

=over 8

=item read_mpcatID

I<Usage>: 

      my $MPcatID = read_mpcatID($MPCATfilename)

I<Provides>: Given a MPCAT File it returns a hash of hashes containing the contents of the MPCAT with the keys being the obsid.

I<Arguments>:

     $MPCATfilename  = A MPCAT filename to open.

I<Output>:

A hash of hashes contain the information in the MPCAT.

I<Examples>:

    my $MPcatID = read_mpcatID($MPCATfilename)
    my $RA = $MPcatID->{$obsid}{'ra'};
    my $Dec = $MPcatID->{$obsid}{'dec'};
    my $ltplan = $MPcatID->{$obsid}{'lt-plan'};

=item read_mpcat

I<Usage>: 

      my $MPcatID = read_mpcat($MPCATfilename)

I<Provides>: This is an outdated routine. Most scripts should be using read_mpcatID() instead! Given a MPCAT File it returns a hash of hashes containing the contents of the MPCAT with the key being the sequence number but if multiple obsids exist it will return only the last one in the file.

I<Arguments>:

     $MPCATfilename  = A MPCAT filename to open.

I<Output>:

A hash of hashes contain the information in the MPCAT keyed on sequence number.

I<Examples>:

    my $MPcatID = read_mpcat($MPCATfilename)
    my $RA = $MPcatID->{$seq}{'ra'};
    my $Dec = $MPcatID->{$seq}{'dec'};
    my $ltplan = $MPcatID->{$seq}{'lt-plan'};

=item diff_mpcats

I<Usage>: 

      my $changed_obs = diff_mpcats($NEWMPCAT,$OLDMPCAT,\@checkflags);


I<Provides>: Given two MPCAT Files and a optional list of fields (default is all) to check it will return a list of obsids that are different between the two mpcats.

I<Arguments>:

    $NEWMPCAT    = The filename of a new mpcat.
    $OLDMPCAT    = The filename of the older mpcat.
    \@checkflags = an array of fields to check (ex: "ra", "dec") 
                   (if not provided then default is all).

I<Output>:

A reference to an array of obsids that differ in the two MPCATS for the flaged fields.

I<Examples>:

    my @checkflags = ("ra","dec");
    my $changed_obs = diff_mpcats($NEWMPCAT,$OLDMPCAT,\@checkflags);


=item quickread_mpcatIDs

I<Usage>: 

      my $ref = quickread_mpcatIDs(@obsids);
      my $ref = quickread_mpcatIDs(7401,8523, 9465, 8799);
       


I<Provides>: Given a list of obsids returns a hash containing selected MPCAT information for the obsids.

I<Arguments>:

    @obsids    = List of obsids. Warning: If not in 5 digit format the resulting hash will have 5 digit obsids in it.
    
I<Output>:

A reference to a hash containing the selected infromation from the MPCAT.

I<Examples>:

    my @obsids = qw(7401 8523 9465 8799);
    my $ref2 = quickread_mpcatIDs(@obsids);
    print $ref2->{'08523'}{'name'}; #Notice needed leading zero!
    

=back

=head1 EXAMPLES

=over 8 

=item read_mpcatID

Read a MPCAT and get some information:

    my $MPcat = read_mpcatID($NEWMPCAT);
    my $RA = $MPcat->{$obsid}{"ra"};

=item read_mpcat

Read a MPCAT and get some information (outdated, should use read_mpcatID() ):

    my $MPcat = read_mpcat($NEWMPCAT);
    my $RA = $MPcat->{$seq}{"ra"};

=item diff_mpcats

Diff two MPCATS according to ra and dec:

    my @checkflags = ("ra","dec");
    my $changed_obs = diff_mpcats($NEWMPCAT,$OLDMPCAT,\@checkflags);

Diff two MPCATS according to any field:

    my $changed_obs = diff_mpcats($NEWMPCAT,$OLDMPCAT);

=item quickread_mpcatIDs

Get Target Name for a obsid:

    my $ref2 = quickread_mpcatIDs(8523);
    print $ref2->{'08523'}{'name'}; #Notice needed leading zero!
    

=back

=head1 NOTES

For quickread_mpcatIDs the fields available are found in the script L<mpc2xml.pl|proj::web-icxc::htdocs::mp::mp-pod::mpc2xml>


=head1 DEPENDENCIES

  use strict;
  use warnings;
  use AutoLoader qw(AUTOLOAD);
  require Exporter;
  use Carp;
  use MP::Misc;
  use Data::Dumper;

=head1 VERSION

$Revision: 1.3 $

=head1 AUTHOR

Author:  K Eriksen and J Grimes; rel 7/12/2001

  Last Update:    $Date: 2008/05/28 17:50:13 $ 
  Last Update by: $Author: kkingsbury $


=head1 HISTORY

=over 8

=item Ver: 1.3

- Added the quickread_mpcatIDs function and updated the POD.

kkingsbury - 05/28/2008


=item Ver: 1.2

- Updated POD, imported into CVS control.

kkingsbury - 11/20/2006


=item Ver: 1.1

Initial revision

K Eriksen - 7/12/2001 

=back

=cut
########################################################################
#                        START CODE                                    #
########################################################################

require 5.005_62;
use strict;
use warnings;
use AutoLoader qw(AUTOLOAD);

require Exporter;

use Carp;
use MP::Misc;
use Data::Dumper;

our @ISA = qw(Exporter);
our @EXPORT = qw( &read_mpcatID 
		  &read_mpcat 
		  &diff_mpcats
		  &quickread_mpcatIDs
		  );

our $seqok = 0;

#DEFAULT XML FILE TO USE:
my $XMLFILE = "/data/mpcrit1/mpcats/all.xml";

our $VERSION = '1.3';

sub read_mpcatID {
    my $mpcat = shift;
    open(MPCAT,$mpcat) or
	croak "Could not open MPCAT $mpcat for reading!!\n";
    my(%MPcat,%DummyHash,$line,$key,$value,$obsid);

    local $_;
    $_ = <MPCAT>;
    
    until(/^\(/){
	defined ($_ = <MPCAT>) or
	    croak "not a valid MPCAT file\n";
    }

LOOP:
    while(<MPCAT>){
	$line = '';
	until( /^\)$/ ){
	    chop;
	    unless( /^$/ ){
		$line = "$line $_";
	    }
       	    defined( $_ = <MPCAT> ) or next LOOP; #ugly, fix this
	}
	while( $line =~ /:([a-z0-9,-]{1,}) (.*?)(?=($|\s:[a-z0-9]))/g ){
	    $key   = $1;
	    $value = $2;
	    $value =~ s/\s+$//;
	    $DummyHash{$key} = $value;
	}

	$obsid = $DummyHash{'id'};
	$MPcat{$obsid} = { %DummyHash };
	%DummyHash = ();
    }

    close(MPCAT);
    return \%MPcat;
}

# Ted Williams hit .406 in 1941 
# (.344 lifetime, 6th all time, behind Cobb, Hornsby, Delahanty,
#  Speaker, and Hamilton)

sub read_mpcat {
    my $mpcat = shift;

    carp <<EOP unless $seqok;

 You are using the outdated routine read_mpcat()! This probably is NOT
 what you want. Email Kris to figure out how to shut up this message, or
 change your code.
EOP
    
    my $MPcatID = read_mpcatID( $mpcat );
    my %Byseq;

    my $obsid;
    foreach $obsid (keys %$MPcatID){
	my $seq = $MPcatID->{$obsid}{'seq-nbr'};
	$Byseq{$seq} = $MPcatID->{$obsid};
    }

    return \%Byseq;
}




sub diff_mpcats {


  my $new = read_mpcatID( shift() );
  my $old = read_mpcatID( shift() );

  my $keysptr=shift || "ALL";
  my (@changed);


  my @new=keys %$new;
  my @old=keys %$old;

  my $obsid;



  if ($keysptr eq "ALL") {

      foreach $obsid (@new) {
	
	  if (!exists $old->{$obsid}) {
	      push @changed,$obsid;
	      next;
	  }
  
	  push @changed,$obsid if 
	      scalar(keys %{$new->{$obsid}}) != scalar(keys %{$old->{$obsid}});

	  foreach my $k (keys %{$new->{$obsid}}) {
	      push @changed,$obsid if 
		  !exists $old->{$obsid}{$k} || 
		  $old->{$obsid}{$k} ne$new->{$obsid}{$k}; 
	  }
      }
  } else {

      foreach my $k (@$keysptr) {
	  
	  foreach $obsid (@new) {
	
	      if (!exists $old->{$obsid} && exists $new->{$obsid}{$k}) {
		  push @changed,$obsid;
		  next;
	      }
  
	      push @changed,$obsid if  exists $new->{$obsid}{$k} && 
		  (!exists $old->{$obsid}{$k} ||  $old->{$obsid}{$k} ne $new->{$obsid}{$k});
	  }
      }  

  }


  my @final_changed;

  foreach $obsid (@changed) {
      push @final_changed,$obsid if !grep {$_ eq $obsid } @final_changed;
  }

  return \@final_changed;
}

#Given a list of obsids returns a hash structure if the obsid is in the XML file otherwise a undef value. If a list is given then a hash is returned containing the obsids found otherwise undef if none were found.
sub quickread_mpcatIDs {
    my @obsids = check_obsid(@_); #in ids;
    my %ref; #out hash

    #prep the egrep line and exec:
    my $exec = "egrep '^<id num=\"(" . join("|", @obsids) .")\"' $XMLFILE";
    my $raw = `$exec`;
    
    #go through results;
    return if (! length $raw); #nothing found
    my @lines = split("\n", $raw);  #Split by obsids
    foreach my $line (@lines){
	my $back = parsequick($line); #parse structure
	foreach my $key (keys %$back){ #add each key into the returned array.
	    $ref{$key} = $back->{$key};
	}
    }
    return \%ref;
}

#Helper Function: Takes a obsid line from the XML file and parses it into a hash object.
sub parsequick {
    my $text = $_[0];
    my %object;

    #Look for ID and grab everything in between
    (my $id, $text) = ($text =~ /<id\s+num=\"(\d{1,5})\">(.*)<\/id>/i);
    #Basically split on key values:
    while ($text =~ /<([\-\_\d\w]+)>(.*?)<\/([\-\_\d\w]+)>/g){
	my ($st, $val, $et) = ($1, $2, $3);
	#ideally should do a $st == $et sanity check
	if ($st ne $et){
	    print STDERR "Warning: For Obsid $id tags $st and $et Don't match!\n";
	    next;
	}
	
	#Clean Up:
	$object{$id}{$st} = xmlunclean($val);
    }
    return \%object;
}


#Helper Function: Converts XML unfriendly characters from the HTML ASCII entities back to the proper characters. mpc2xml has the reverse function.
sub xmlunclean {
    my $in = $_[0];
    $in =~ s/\&amp;/\&/g; 
    $in =~ s/\&lt;/\</g;
    $in =~ s/\&gt;/\>/g;
    $in =~ s/\&apos;/\'/g;
    $in =~ s/\&quot;/\"/g;
    return $in;
}


1;
__END__
