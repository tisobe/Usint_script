package MP::SkyView;

=head1 NAME

MP::SkyView

=head1 PURPOSE

A Perl Extension to grab FITS images from SkyView.

=head1 SYNOPSIS

  use MP::SkyView;
  get_ims(\@obsids, $MPcatID);

=head1 DESCRIPTION

This module provides the function get_ims() , which takes a reference to a list of obsids and a hash reference returned by MP::MPCAT::read_mpcatID() and fetches FITS images from HEASARC's SkyView.

For each obsid in the list, get_ims() will check to see, for each survey (RASS, PSPC, and DSS by default) if there exists a corresponding image in the MP SEQNBR directory. (See below how to change the default surveys and location.) If the FITS image doesn't exist, get_ims() forks the skvbatch.pl program (supplied by HEASARC) and fetches the image.

This module is dependent on two Perl scripts supplied by HEASARC, L<skvbatch.pl|proj::web-icxc::htdocs::mp::mp-pod::skvbatch> and L<webquery.pl|proj::web-icxc::htdocs::mp::mp-pod::webquery>. These programs, hacked by K. Eriksen, live in /data/mpcrit1/bin. With some snooping through the SkyView.pm code, you can change the dependence on these programs, but don't do it unless you know what you're doing.

=head2 Changing defaults

You can muck around with the location of the HEASARC scripts, the retrieved images, and the requested survey and image sizes by fiddling with the $MPDIR, $MPBIN, and %Survey variables. Something like:

 use MP::SkyView;
 $MP::SkyView::MPDIR = '/data/foobar';

will put the images in /data/foobar/(seq nbr).

=head2 Known Problems

If the skyview servers get overloaded corrupt fits files (actually html files warning about the overload) are returned.  

Lowering the value of $MAXPROCS (how many fits files are being downloaded at one) can help with this.  This generally only happens when downloading large numbers of images (like a new ao).  Trying again later also can help.

=head2 EXPORTS
    
    get_ims()

=head2 Methods

=over 8

=item get_ims

I<Usage>: 

  get_ims(\@obsids, $MPCAT)

I<Provides>: Given a reference to a list of obsids and a reference to a hash produced by MPCAT::Read_mpcatID(). Fetches the FITS files for the three different surveys for each obsid and copies them to the $MPDIR/$seq directory.

I<Arguments>:
  
  obsids  = reference to a list of obsids.
  MPCAT = refernce to a hash of a parsed MPCAT.

I<Output>:

Returns nothing but an effect is that 3 FITS for the 3 surveys are copied to the $MPDIR/seq directory. 

I<Examples>:

      get_ims( \@obsids, $MPCAT )

=back

=head1 EXAMPLES

=over 8 

=item get_ims

Get Images for a list of obsids:

  $MP::SkyView::MPDIR = $cwddir;
  my @obsids = (5555,6666);
  my $mpcat="/data/mpcrit1/mpcats/all.mpc";
  my $MPcatID = read_mpcatID( $mpcat );
  get_ims(\@obsids, $MPcatID);

I<Returns>:
    Nothing

I<Effects>:
    3 FITS are fetched into the $MPDIR/$seq directory.

=back

=head1 NOTES

=head1 DEPENDENCIES

  use strict;
  use warnings;
  use Carp;
  use POSIX "sys_wait_h";
  require Exporter;

Runs:

L<skvbatch.pl|proj::web-icxc::htdocs::mp::mp-pod::skvbatch>

Which calls:

L<webquery.pl|proj::web-icxc::htdocs::mp::mp-pod::webquery>

=head1 VERSION

$Revision: 1.4 $

=head1 AUTHOR

Author:  K Eriksen; rel 10/09/2001

  Last Update:    $Date: 2006/11/14 18:17:40 $ 
  Last Update by: $Author: kkingsbury $


=head1 HISTORY

=over 8

=item Ver: 1.4

- Fixed some POD Formatting.

kkingsbury - 11/14/2006


=item Ver: 1.3

- Reinstall to default location.

kkingsbury - 11/14/2006


=item Ver: 1.2

- Added POD.

- Created MANIFEST

- First Install since importing into CVS.

kkingsbury - 11/14/2006


=item Ver: 1.1

Initial revision

K Eriksen - 10/9/2001 

=back

=cut
########################################################################
#                        START CODE                                    #
########################################################################

require 5.005_62;
use strict;
use warnings;
use Carp;

require Exporter;

our @ISA = qw(Exporter);
our @EXPORT = qw( &get_ims );	

our $VERSION = '1.4';

use POSIX "sys_wait_h";

our $MPDIR = '/data/mp1/SEQNBR';
our $MPBIN = '/data/mpcrit1/bin';

my $fork_cnt = 0;

# this makes $verbose available to
# programs that call get_ims, so you can shut up the
# info messages
our $verbose  = 2;

# maximum number of processes to be  fork()'d. set higher to piss off Goddard
our $MAXPROCS = 2;  

my %Survey = (
	      dss  => { name => 'Digitized Sky Survey', size => 1024 },
	      pspc => { name => 'PSPC 2.0 Deg-Inten',   size => 512  },
	      rass => { name => 'RASS-Cnt Broad',       size => 512  },
	      );

my %Image;
my %Pending;

#
# Takes 2 args:
#     reference to list of obsids
#     MPCAT Hash produced by MPCAT::read_mpcatID()
#
sub get_ims {
    my($obsids, $MPcatID) = @_;

    umask 0002;

    local $SIG{CHLD} = \&REAPER;

    my $obsid;
    foreach $obsid (@$obsids){
	my $seq;
	unless( defined( $seq = $MPcatID->{$obsid}{'seq-nbr'} ) ) {
	    carp "obsid $obsid not found in MPCAT file! Skipping...\n";
	    next;
	}

	my $dir = "$MPDIR/$seq";
	if( !-e $dir ){
	    print STDERR "creating directory $dir\n";
	    mkdir $dir, 0775;
	    chmod 0775,$dir;   # why don't the permissions get set correctly above?!?!
	}

	my $ra  = $MPcatID->{$obsid}{ra};
	my $dec = $MPcatID->{$obsid}{dec};

	my $survey;
	foreach $survey (keys %Survey){
	    my $image = "$dir/$seq.$survey.fits";

	    #
	    # This hack prevents you from trying to get multiple
	    # copies of the same file for sequence numbers that have 
	    # more than one obsid (grumble grumble)
	    #
	    next if $Pending{$image};
	    $Pending{$image} = 1;

	    if( !-e $image ){
		print STDERR "$image does not exist.\n" if $verbose > 1;
		my $get = qq($MPBIN/skvbatch.pl \\
			     file="$image" \\
			     VCOORD="$ra, $dec" \\
			     SURVEY="$Survey{$survey}{name}" \\
			     SFACTR='2' \\
			     PIXELX="$Survey{$survey}{size}" \\
			     PIXELY="$Survey{$survey}{size}" \\
			     );

		#
		# fork() skvbatch.pl commands
		# but keep the number of child processes less
		# than or equal to $MAXPROCS
		#
		while( $fork_cnt >= $MAXPROCS ){
		    sleep 15;
		}
	      FORK:
		my $pid;
		if( $pid = fork() ){
		    $fork_cnt++;
		    $Image{$pid} = $image;
		} elsif( defined $pid ) { # child process
		    print STDERR "retrieving image $image from SkyView (this may take some time)\n" 
			    if $verbose > 1;
#		    print $get,"\n";
		    exec $get;
		} else {
		    carp "Uh-oh. could not fork() skvbatch.pl!\n";
		    sleep 5;
		    carp "trying again.\n";
		    goto FORK;
		}

	    }
	}
    }
    while( $fork_cnt > 0 ){
	sleep 15;
    }

#    $SIG{CHLD} = 'IGNORE';  # don't need this for 'local $SIG{CHLD}' -- hopefully
    return;
}

#
# Handles SIGCHLD (thrown when a child process exits)
# (note the $SIG{CHLD} = \&REAPER;  above)
#
# good UNIX programming practice says that signal 
# handlers should just reap the PID of the child, and
# that anything else that malloc()'s (like print) risks a core dump.
# However, I seem to get away with this...cross your fingers
# when you run it...
#
sub REAPER {
    my $pid = wait;
    if( $pid > 0 ){
	$fork_cnt--;
	if( exists $Image{$pid} ){
	    print STDERR "$Image{$pid} retrieved.\n" unless $verbose > 0;
	    delete $Pending{ $Image{$pid} };
	} else {
	    print STDERR "got someone else's SIGCHLD? hmmm...\n";
	}
    }
    else {
	carp "funny child exit status: $pid  $?\n";
	$fork_cnt--;
    }
}

1;
