package MP::Signoff;

=head1 NAME

MP::Signoff

=head1 PURPOSE

A Perl Extension to read USINT's signoff list.

=head1 SYNOPSIS

  use MP::Signoff;
  %{ $Signoff } = read_signoff();

=head1 DESCRIPTION

This routine parses USINT's signoff list and returns a hash reference whose keys are obsids,  and whose values are a string of the form "(USINT username) (date)". If the obsid in which you are interested is not in the hash, it's not signed off. Simple, huh?

=head2 EXPORTS

  read_signoff()

=head2 Methods

=over 8

=item  read_signoff

I<Usage>: 

    my $Signoff = read_signoff();

I<Provides>: Takes no arguments and returns a reference to a hash of signed off obsids.

I<Arguments>:

  None.

I<Output>:

Outputs a hash of obsids and their sign off information. If obsid does not exist in the hash then it is not signed off.

I<Examples>:
     
    my $Signoff = read_signoff();
    my $sig = '*** not signed off ***';
    if exists $Signoff->{$obsid}{
      print "Signed off!\n";
    } else {
      print "Not Signed off!\n";
    }


=back

=head1 EXAMPLES

=over 8 

=item read_signoff

Check if an obsid is signed off or not:

    my $Signoff = read_signoff();
    my $sig = '*** not signed off ***';
    $sig = $Signoff->{$obsid} if exists $Signoff->{$obsid};
    if ( $Info{$obsid} ) {
	print "$Info{$obsid} $sig\n";
    } elsif ($opt_id) {
	print "$obsid $sig\n";
    }

=back

=head1 FILES

=over 8

=item I< Signoff File >

C<$SIGNOFF => F</data/udoc1/ocat/approved>

The USINT signoff File.

=back

=head1 DEPENDENCIES

  use strict;
  use warnings;
  use Carp;
  require Exporter;
  use AutoLoader qw(AUTOLOAD);

=head1 VERSION

$Revision: 1.2 $

=head1 AUTHOR

Author:  K Eriksen; rel 7/12/2001

  Last Update:    $Date: 2006/11/20 14:24:36 $ 
  Last Update by: $Author: kkingsbury $


=head1 HISTORY

=over 8

=item Ver: 1.2

- Updated POD, imported into CVS control.

- added check to make sure get 3 items from usint file (no more parse errors if there are stray characters).

kkingsbury - 11/20/2006


=item Ver: 1.1

Initial revision

K Eriksen - 7/12/2001 

=back

=cut
########################################################################
#                        START CODE                                    #
########################################################################

require 5.005_62;
use strict;
use warnings;
use Carp;

require Exporter;
use AutoLoader qw(AUTOLOAD);

our @ISA = qw(Exporter);
our @EXPORT = qw( &read_signoff );
our $VERSION = '1.2';

our $SIGNOFF = '/data/udoc1/ocat/approved';

sub read_signoff {
    open(SIGNOFF,"$SIGNOFF") or
	die "$0:could not open signoff file $SIGNOFF...dying";

    my %Signoff;

    local $_;
    while(<SIGNOFF>){
	chop;
	my($obsid,$who,$date) = (split)[0,2,3];
	next if ! defined($date);
	$obsid = sprintf "%05d", $obsid;
	$Signoff{$obsid} = "$who  $date";
    }

    close(SIGNOFF);

    return \%Signoff;
}

#
# Is it not nifty? http://www.sluggy.com
#


#
# for legacy's sake, the routine for the old system
# you should never have to use this.
# and the $OLD file may cease to exist 
# at any moment. Use at your own risk!!!
#
our $OLD = '/data/udoc1/ocat/updates_table.list'; 
sub old_signoff {
    open(SIGNOFF,"$OLD") or
        croak "could not open signoff list $OLD: $!";

    local $_;
    my %Check;
    while(<SIGNOFF>){
        my ($id,$whodate) = (split(/\t/,$_))[0,4];
        $id =~ s/([0-9]+).*/$1/;
        my $obsid = sprintf("%05d",$id);
        unless( $whodate =~ /NA/ ) {
            $Check{$obsid} = $whodate or
                print "$_";
        }
    }

    close(SIGNOFF);

    return \%Check;
}

1;
__END__

