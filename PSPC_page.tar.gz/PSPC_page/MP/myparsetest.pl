#!/data/mpcrit1/bin/perl -w


use strict;       # for safer programming
use MP::SOE;
use Getopt::Long;
use Data::Dumper;


my $soe = shift;
my $soe_ref = read_soe( $soe );

my @soe_obsids;
foreach my $record (@$soe_ref){
    my $type = $record->{'odb_rec_type'};

    if ( $type eq 'OBS' ) {
	my $obsid = $record->{'odb_req_id'};
	$obsid =~ s/\s//g;
	$obsid =~ s/^(\d{5}).*/$1/;
	push @soe_obsids, $obsid;
    }
}

print "OBSIDS:" . join(",", @soe_obsids) . "\n";
