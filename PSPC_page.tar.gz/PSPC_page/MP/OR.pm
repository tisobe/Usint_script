package MP::OR;

=head1 NAME

MP::OR

=head1 PURPOSE

A Perl Extension for dealing with OR lists.

=head1 SYNOPSIS

  use MP::OR;
  my @ors = MP::OR::parse_file( 'file.or' );
  MP::OR::write_file( 'file.or', @ors );
  $or_version = MP::OR::version;

=head1 DESCRIPTION

This module provides some functions for reading and writing OR lists.
OR's are stored as hashes with the following keys:

=over 8

=item tag

The value of this element is a string indicating the type of OR
(C<HDR>, C<COMMENT>, C<OBS>, etc.).

=item fields

This is a reference to a hash containing fields in the OR and their
values, keyed off of the field names.  If the field is a scalar (like
C<ID> or C<SI>), the value of the hash element is a scalar.  If the
field is a list (like C<TARGET>, which has RA, Declination, and name
), the value is a reference to an array containing the list.

For example, if C<$or{tag}> is C<'HDR'>, then 

     $or{fields}{HDR_ID}

contains the Header ID.

If C<$or{tag}> is C<'OBS'>, 

  $or{fields}{TARGET}->[0]

is the RA,

  $or{fields}{TARGET}->[1]

is the Declination, and

  $or{fields}{TARGET}->[2]

is the Target Name.

=item comments

If the OR is of type C<COMMENT>, this will be a reference to an array
containing the comment lines, in the order in which they appeared.

For example,

  $or{comments}->[0]

is the first comment, etc.

=item line

If the OR is read in by MP::OR::parse_file, this will contain the line
number of the start of the OR's record

=back

Lists of OR's are stored as Perl arrays of references to the OR hashes.

For example, 

 my @or = ( 
	    {
	      'line' => 1,
	      'tag' => 'HDR',
	      'fields' => {
			    'HDR_ID' => 'ORS_OAC'
			  }
	    },
	    {
	      'line' => 3,
	      'comments' => [
			     'OR list for Chandra OAC Phase 2.',
			     'Version: 4.2 released 1999 June 9.'
			   ],
	      'tag' => 'COMMENT',
	      'fields' => {
			    'ID' => 49999
			  }
	    },
	    {
	      'line' => 53,
	      'tag' => 'OBS',
	      'fields' => {
			    'SI_MODE' => 'TE_00066',
			    'DITHER' => [
					  'ON',
					  '0.002222',
					  '0.3600',
					  '0.0',
					  '0.002222',
					  '0.5091',
					  '0.0'
					],
			    'PRIORITY' => 5,
			    'GRATING' => 'NONE',
			    'SI' => 'ACIS-S',
			    'ID' => '01051',
			    'DURATION' => [
					    '1000.000000'
					  ],
			    'TARGET' => [
					  '98.940000',
					  '-75.270000',
					  '{PKS0637-752}'
					],
			    'STAR' => [ [194.911460,47.103035,10.08,BOTH,453393848],
				        [195.010336,47.442343,9.11,BOTH,453391088]]
			  }
	    },
          );


Thus, to get the first OR's tag, you would use

  $or[0]->{tag}

The second OR's ID is

  $or[1]->{fields}{ID}

The RA for the third OR is

  $or[2]->{fields}{TARGET}->[0]

etc.

=head2 EXPORTS
    
    parse_file()
    write_file()
    version()

=head2 Methods

=over 8

=item parse_file


I<Usage>: 

  @ors = MP::OR::parse_file( $file )

I<Provides>: This function will read and parse OR records from the passed file.It returns a list of references to OR's.  The argument may be either a file handle ( as in \*STDIN, or \*INPUT), or the name of a file.

If there's an error, it will B<croak> with an appropriate message. Use B<eval{}> to catch the B<croak>, if you like.

I<Arguments>:

    $file = OR list file

I<Output>:

A list of references to OR's.

I<Examples>:
 
  my @firstorl=MP::OR::parse_file($ARGV[0]);
  for my $firstor ( @firstorl ) {
    if ($firstor->{'tag'} eq 'OBS') {
	print $firstor->{'fields'}{'ID'},"\n";
	my $foundmatch=0;
    }
  }    


=item B<write_file>

I<Usage>: 

  MP::OR::write_file( $file, @ors )


I<Provides>: This function will write an OR list to a file.

If there's an error, it will B<croak> with an appropriate message.
Use B<eval{}> to catch the B<croak>, if you like.

I<Arguments>:
    
    $file = file to write append to or create.
    @ors = references to the OR entries.

I<Output>:

A file containing the ORs.

I<Examples>:

    MP::OR::write_file( $orl, @new_ors );
    unless ( -e $orl ) {
	print "MP::OR::write_file( $orl, @new_ors ) failed";
    } else {
	print "New OR list is: $orl\n",
	"Old OR list is: $orl.unstripped\n\n";
    }


=item version

I<Usage>: 

  $or_version = MP::OR::version;

I<Provides>: It returns the version of the B<OR> module

I<Arguments>:

None.

I<Examples>:

  $or_version = MP::OR::version;

=back

=head1 EXAMPLES

Here's an example of iterating over an OR list.  Notice that
the elements in the list are references.

  my @ors = MP::OR::parse_file( $fh );
  for my $or ( @ors )
  {
    print "$or->{tag}:\n";
    while( my ( $field, $value ) = each %{$or->{fields}} )
    {
      if ( 'ARRAY' eq ref( $value ) )
      {
	print "  $field => [ ", join( ', ', @$value ), " ]\n";
      }
      else
      {
	print "  $field => $value\n";
      }
    } 

    if ( 'COMMENT' eq $or->{tag} )
    {
      foreach my $comment ( @{$or->{comments}} )
      {
	print "    > $comment\n" 
      }
    }
  }

=head1 NOTES


=head1 DEPENDENCIES

  use strict;
  use warnings;

  use FileHandle;
  use Carp;

  require Exporter;
  use AutoLoader qw(AUTOLOAD);


=head1 VERSION

$Revision: 1.2 $

=head1 AUTHOR

Author:  Diab Jerius ( djerius@cfa.harvard.edu ) rel 9/10/2001

incorporated in MP-Perl 1.0 with minor changes by K. Eriksen (keriksen@cfa.harvard.edu)

  Last Update:    $Date: 2006/11/20 14:29:16 $ 
  Last Update by: $Author: kkingsbury $


=head1 HISTORY

=over 8

=item Ver: 1.2

- Updated POD, placed under CVS control.

kkingsbury - 11/20/2006


=item Ver: 1.1

Initial revision

K Eriksen - 9/10/2001 

=back

=cut
########################################################################
#                        START CODE                                    #
########################################################################


require 5.005_62;
use strict;
use warnings;

use FileHandle;
use Carp;

require Exporter;
use AutoLoader qw(AUTOLOAD);

our @ISA = qw(Exporter);

our @EXPORT = qw(
     &parse_file &write_file &version
);

our $VERSION = '1.2';


sub parse_file
{
  my $file = shift;

  my ( $rec, $line );
  my ( $tag, $value );

  my @ors;

  my $fh = new FileHandle;

  if ( ref($file) )
  {
    $fh->fdopen( $file, 'r' ) or croak( "unable to attach to file");
  }
  else
  {
    $fh->open( $file, 'r' ) or croak( "unable to open $file" );
  }

  eval
  { 
    while ( ( $rec, $line ) = get_record( $fh ) )
    {
      
      my %data;
      
      ( $data{tag}, $data{fields} ) = parse_record( $rec, $line );
      
      $data{line} = $line;
      
      if ( 'BEGIN_COMMENT' eq $data{tag} )
      {
	my @comments;
	# read until get END_COMMENT tag
	while( <$fh> )
	{
	  chomp;
	  last if /^\s*END_COMMENT\s*$/;
	  push @comments, $_;
	}
	
	croak( "$.: missing END_COMMENT (BEGIN_COMMENT at $line)" )
	  unless /^\s*END_COMMENT\s*$/;
	
	$data{'tag'} = 'COMMENT';
	$data{'comments'} = \@comments;
      }
      
      push @ors, \%data;
    }
  };

  croak( "$file: ", $@ ) if $@;
  $fh->close unless ref($file);

  return @ors;
}


sub write_file
{
  my ( $file, @ors ) = @_;
  
  my $fh = new FileHandle;
  
  if ( ref($file) )
  {
    $fh->fdopen( $file, 'w' ) or croak( "unable to attach to file");
  }
  else
  {
    $fh->open( $file, 'w' ) or croak( "unable to open $file" );
  }
  
  foreach my $or ( @ors )
  {
    my @fields;

    # fields are output with ID first and PRECEDING last
    {
      my %fs;
      @fs{ keys %{$or->{fields}} } = ();
      delete $fs{ID};
      delete $fs{PRECEDING};

      @fields = sort keys %fs;
      unshift @fields, 'ID' if exists $or->{fields}{ID};
      push @fields, 'PRECEDING' if exists $or->{fields}{PRECEDING};
    }

    if ( $or->{tag} eq 'COMMENT' )
    {
      print $fh 'BEGIN_COMMENT';
    }
    else
    {
      print $fh "$or->{tag}";
    }

    if ( @fields )
    {
      print $fh ",\n  ", 
      join( ",\n  ", 
	    map
	    { 
		my $value = $or->{fields}{$_};
		if ( $_ =~ /STAR|FID/ ) {
		    if ( 'ARRAY' eq ref( $value ) ) 
		    {
			my @tmp;
			for my $array (@$value) {
			    if ( 'ARRAY' eq ref( $array ) ) 
			    {
				push @tmp, "$_=( " . 
                                           join( ', ', @$array ) . 
                                           " )";
			    }
			    else
			    {
				push @tmp, "$_=$array";
			    }
			}
			join( ",\n  ", @tmp );
		    }
		    else
		    {
			"$_=$value";
		    }
		}
		elsif ( 'ARRAY' eq ref( $value ) )
		{
		    "$_=( " . join( ', ', @$value ) . " )";
		}
		else
		{
		    "$_=$value";
		}
	    } @fields ), "\n";
    }
    else
    {
      print $fh "\n";
    }

    if ( 'COMMENT' eq $or->{tag} )
    {
      print $fh join( "\n", @{$or->{comments}} ), "\n";
      print $fh "END_COMMENT\n";
    }

    print $fh "\n";
  }

  $fh->close unless ref($file);
}


sub version
{
  return $VERSION;
}

#########################################################################
# ( $tag, $value ) = parse_record( $rec )
#
# Parse a OR logical record.  It returns the OR tag and a reference to
# a hash containing the fields and their values (see above for structure
# layout).
#
# it croaks with an appropriate message upon error

sub parse_record
{
  my ( $rec, $line ) = @_;

  # each OR record begins with a tag, followed by optional subfields
  # separated by commas.  


  
  # ok, now have a single line logical record.  break it up into 
  # the fields.  we have to be careful, because
  # the subfields may contain comma separated list of values.
  # do this the hard way, just to make sure regexp don't miss
  # anything, as I'm not sure exactly what's allowed in here

  # now, parse the record splitting it up into fields.
  # the assumed format for a field is
  #    field
  #    field=scalar
  #    field=(list)
  # where list is a comma separated bunch of values.  a value may
  # be enclosed in curly brackets, which seems to indicate a quoted
  # string.  that string *may* have commas in it (I'm not sure if
  # that's allowed, but I'm going to assume it is).  I assume that
  # you can't embed an opening curly bracket in a quoted string.


  my $tag;
  my $value;
  my $field;

  # first field is tag
  ( $rec, $tag, $value ) = parse_field( $rec, $line );

  # $values had better be undef
  croak( "$line: tag ($tag) should have no value!" )
    if defined $value;

  my %value;
  while( length( $rec ) )
  {
    ( $rec, $field, $value ) = parse_field( $rec, $line );

    if ($field=~m/STAR|FID/) {
	push @{$value{ $field }},$value;
    } elsif (defined $value{ $field }) {
	warn "$line: Error: $field already defined!\n";
    } else {
	$value{ $field } = $value;
    }

  }

  return ( $tag, \%value );

}


#########################################################################
# ( $rec, $line ) = get_record( $fh )

# Read a logical record from filehandle $fh.  Logical records may
# consist of multiple physical lines, with a trailing comma as the
# continuation character.

# It returns an array containing the record and the line number of the
# first physical line upon success, () upon EOF.

sub get_record
{
  my $fh = shift;

  # first skip blank lines
  while( <$fh> )
  {
    last unless /^\s*$/;
  }

 
  my $rec = $_;
  my $line = $.;

  # check for eof
  return () unless defined $rec;

  chomp $rec;

  # trim off trailing white space
  $rec =~ s/\s+$//;
  
  while ( substr( $rec, -1, 1 ) eq ','  && defined( $_ = <$fh>) )
  {
    chomp;

    # ignore empty records; probably the result of a stray comma.
    if ( /^$/ )
    {
      warn( "$line: Extra comma at end of logical record!!! Continuing...\n" );
      $rec =~ s/,$//;
      last;
  }

    $rec .= $_;

    # trim off possible trailing white space
    $rec =~ s/\s+$//;
  }
  

  return ( $rec, $line );
}


#########################################################################
#  ( $rec, $field, $value ) = parse_field( $rec, $line )
#
# This routine parses the next field out of an OR record ($rec), updating
# it so it's ready for another pass through parse_field.
#
# It returns the updated record, the field name, and the field value,
# which may either be UNDEF if the field had no value, a scalar if the
# field had one value, or a reference to an array, if the field was a
# list.
#
# it croak with an appropriate message upon error

sub parse_field
{
  my ( $rec, $line ) = @_;
  
  my $field;
  my $value;
  
  # trim off leading white space
  $rec =~ s/^\s+//;

  # if it's an empty string, return straight off
  return () unless length($rec);

  # find the positions of the next comma or equals sign.  if a comma
  # occurs first, the field has no value.
  my $comma = index($rec, ',' );
  my $eq    = index($rec, '=' );
  
  # from now on, we just care about the character which comes first,
  # ignoring the other one.  if the character isn't found set things
  # up so that a simple comparison gives us the first existent one.
  $comma = length($rec) + 1 if $comma == -1;
  $eq    = length($rec) + 1 if $eq    == -1;
  
  # if comma comes first ( $comma < $eq ) or no comma or equal sign
  # ($comma == $eq ), it's a simple field with no value.  in the latter
  # case it's also the end of the record.
  if ( $comma <= $eq )
  {
    # store the field name
    $field = substr( $rec, 0, $comma );

    # no value
    $value = undef;
    
    # now zap used part of record
    substr( $rec, 0, $comma+1 ) = '';
  }
  
  # equals comes first, so must have a value.
  else
  {
    # field name
    $field = substr( $rec, 0, $eq );
    
    my @values;
    my $subvalue;
    my $end;
    
    # now zap used part of record and trim leading white space
    substr( $rec, 0, $eq+1 ) = '';
    $rec =~ s/^\s+//;
    
    # are we in list mode ?
    if ( substr( $rec, 0, 1 ) eq '(' )
    {
      substr( $rec, 0, 1 ) = '';

      $end = find_char( $line, $rec, ')' );

      croak( "$line: missing closing parenthesis" )
	if ( -1 == $end );

      my $delim;
      for( my $start = 0 ; $start < $end ; $start += $delim + 1)
      {
	$delim = find_char( $line, substr( $rec, $start, $end - $start ), ',', 1 );
	clean( $subvalue = substr( $rec, $start, $delim ) );
	push @values, $subvalue;
      }

      $value = \@values;
      # advance $end so closing paren gets zapped below
      $end++;
    }
    
    # no
    else
    {
      # keep going until next comma, but be careful of 
      # brackets, which seem to enclose strings with included white space

      $end = find_char( $line, $rec, ',', 1 );

      clean($value = substr( $rec, 0, $end ));

    }
    
    # zap value(s)
    substr( $rec, 0, $end ) = '';

    # next character must be comma or EOS
    $rec =~ s/^\s+//;
    
    if ( length($rec) && substr( $rec, 0, 1 ) ne ',' )
    {
      croak( "$line: missing comma" ) ;
    }
      
    # zap comma
    substr( $rec, 0, 1 ) = '';

  }
  
  clean($field);

  return ( $rec, $field, $value );
  
}



#########################################################################
# find_char( $line, $str, $char [, $anchor] )
#
# search a string for the specified character, being mindful of quoted
# strings and sub-lists.
#
# returns the index into the string at which the character is found.
# if it can't find it, it returns -1, unless $anchor is true, in which case
# it returns the index of the imaginary character just after the end
# of the string.
#
# it croaks with an appropriate message upon error (unbalanced quotes)

sub find_char
{
  my ( $line, $str, $char, $anchor ) = @_;

  # initialize anchor
  $anchor = defined $anchor ? length($str) : -1;

  my $start = 0;

  while( 1 )
  {
    # position of first character in string
    my $char_pos = index( $str, $char, $start );
    
    # if the character doesn't show, abort
    return $anchor
      if -1 == $char_pos ;
    
    # position of opening bracket
    my ( $bra, $ket_char );
    {
      my $b = index( $str, '{', $start );
      my $p = index( $str, '(', $start );

      if ( -1 == $b && -1 == $p )
      {
	$bra = -1;
      }
      elsif ( -1 == $b || $p > -1 && $p <= $b )
      {
	$bra = $p;
	$ket_char = ')';
      }
      elsif ( -1 == $p || $b > -1 && $b <= $p)
      {
	$bra = $b;
	$ket_char = '}';
      }
    }
    
    # if no bracket, or character shows up before bracket, we're done
    return $char_pos 
      if -1 == $bra || $char_pos < $bra;
    
    # well, now we have to parse the quoted string.
    
    # position of ending bracket
    
    my $ket = index( $str, $ket_char, $start );
    
    # we've got problems!!
    croak( "$line: missing $ket_char" )
      if $ket == -1;
    
    # start all over past the curly bracket
    $start = $ket + 1;
  }

  # Not Reached, dude!
  croak( "$line: internal error" );
}


sub clean
{
  $_[0] =~ s/^\s+//;
  $_[0] =~ s/\s+$//;
}




1;
__END__
