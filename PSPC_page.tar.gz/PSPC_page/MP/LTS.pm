package MP::LTS;

=head1 NAME

MP::LTS

=head1 PURPOSE

A Perl Extension for dealing with the LTS.

=head1 SYNOPSIS

  use MP::LTS;
  $ltshash = lts_bins($lts);
  $Ltsdiff = diff_lts($lts,$oldlts);
  $ltsbins = lts_bybin($lts);

=head1 DESCRIPTION

This module does parsing and comparisons for an LTS file. It can generate a hash that contains obsids by bin, it can diff two different LTS files, and it can provide a list of observations by bin header and date.

=head2 EXPORTS
    
  lts_bins() 
  diff_lts() 
  lts_bybin()

=head2 Methods

=over 8

=item lts_bins

I<Usage>: 

  $ltshash = lts_bins($lts)

I<Provides>: Given a LTS it generates a hash of obsids with the start date of the week or 'unscheduled' if the observation is not scheduled.

I<Arguments>:

      $lts  = a LTS file.

I<Output>: Returns a hash of obsids and the start date of their bin.

I<Examples>:

     $ltshash = lts_bins($lts)
     foreach my $obs (keys %{$ltshash}){
       print "Obsid: $obs is sheduled for $ltshash->{$obs} \n";
     } 

=item diff_lts

I<Usage>: 

  my $Ltsdiff = diff_lts($lts,$oldlts);

I<Provides>: Given a current LTS and an old LTS the routine checks if an obsid is in the old lts and current lts and whether the obsid has been moved to a different bin between the two schedules.  This routine returns a hash of hashes and arrays: 

I<Arguments>:

      $lts  = a LTS file.

I<Output>: Return a hash of hashes and arrays:

moved (hash): for observations that have moved between the two schedules. key: obsid, value: array starting date in current lts  and starting date in old lts

notin1 (array): obsids not in current lts

notin2 (array): obsids not in old lts

lts1 (hash): for current lts. key: obsid, value: starting date of week

lts2 (hash): for old lts. key: obsid, values: starting date of week

I<Examples>:

  my $Ltsdiff = diff_lts($lts, $oldlts);
  print "Obsids that have moved to different weeks:\n";
  foreach my $ob (keys %{$Ltsdiff ->{moved}}){
    print "$ob: $Ltsdiff->{moved}{$ob}[1] to $Ltsdiff->{moved}{$ob}[0]\n";
  }

  print "Obsids not in current LTS:\n";
  foreach my $ob (@{$Ltsdiff -> {notin1}}){
    print "$ob\n";
  }

  print "Obsids not in old LTS:\n";
  foreach my $ob (@{$Ltsdiff -> {notin2}}){
    print "$ob\n";
  }

  print "Current Lts obsids with starting dates: \n";
  foreach my $ob (keys %{$Ltsdiff->{lts1}}){
    print "$ob: $Ltsdiff->{lts1}->{$ob}\n";
  }

  print "Old Lts obsids with starting dates: \n";
  foreach my $ob (keys %{$Ltsdiff->{lts2}}){
    print "$ob: $Ltsdiff->{lts2}->{$ob}\n";
  }

=item lts_bybin

I<Usage>: 

  my $ltsbins = lts_bybins($lts)

I<Provides>: Given a LTS it gives header, date & obsid for each week. 

I<Arguments>:

      $lts  = a LTS file.

I<Output>: Returns an array of hashes, with the array subscripted by bin number.hash of obsids and the start date of their bin.

lts (array):

subscript: bin number

value: Bin (hash)

key - string,      value - header of lts week

key - date,        value - starting date of week

key - keys         value - array of obsids in the week   

I<Examples>:

  # prints out the header, starting date and obsids for each week
  print "\n\nThe header, starting date and obsids for each week:\n\n";
  my $ltsbins = lts_bybin( $lts );
  my $i = 0;
  for my $bin (@$ltsbins) {
    last if $bin;
    $i++;
  }

  for my $bin ($i..@$ltsbins) {
    if ($ltsbins->[$bin]->{string}){
   	print "header: $ltsbins->[$bin]->{string}\n" ;
	print "date: $ltsbins->[$bin]->{date}\n";
	print "obsids: ";
	for my $key (@$ltsbins->[$bin]->{keys}){
	      for my $temp (@$key){
	       print "$temp  ";
              }
	}
	print "\n\n";
     }
   }

=back

=head1 EXAMPLES

  use strict;
  use MP::LTS;
  my $lts = '/data/mpcrit1/mplogs/2003/SEP1503/scheduled/sep1503.lts';
  my $oldlts = '/data/mpcrit1/mplogs/2003/SEP0803/scheduled/sep0803.lts';

=over 8 

=item lts_bins

  $ltshash = lts_bins($lts)
  foreach my $obs (keys %{$ltshash}){
     print "Obsid: $obs is sheduled for $ltshash->{$obs} \n";
  }

=item diff_lts
    
  my $Ltsdiff = diff_lts($lts, $oldlts);
  print "Obsids that have moved to different weeks:\n";
  foreach my $ob (keys %{$Ltsdiff ->{moved}}){
    print "$ob: $Ltsdiff->{moved}{$ob}[1] to $Ltsdiff->{moved}{$ob}[0]\n";
  }

  print "Obsids not in current LTS:\n";
  foreach my $ob (@{$Ltsdiff -> {notin1}}){
    print "$ob\n";
  }

  print "Obsids not in old LTS:\n";
  foreach my $ob (@{$Ltsdiff -> {notin2}}){
    print "$ob\n";
  }

  print "Current Lts obsids with starting dates: \n";
  foreach my $ob (keys %{$Ltsdiff->{lts1}}){
    print "$ob: $Ltsdiff->{lts1}->{$ob}\n";
  }

  print "Old Lts obsids with starting dates: \n";
  foreach my $ob (keys %{$Ltsdiff->{lts2}}){
    print "$ob: $Ltsdiff->{lts2}->{$ob}\n";
  }  

=item lts_bybin

  # prints out the header, starting date and obsids for each week
  print "\n\nThe header, starting date and obsids for each week:\n\n";
  my $ltsbins = lts_bybin( $lts );
  my $i = 0;
  for my $bin (@$ltsbins) {
    last if $bin;
    $i++;
  }

  for my $bin ($i..@$ltsbins) {
    if ($ltsbins->[$bin]->{string}){
   	print "header: $ltsbins->[$bin]->{string}\n" ;
	print "date: $ltsbins->[$bin]->{date}\n";
	print "obsids: ";
	for my $key (@$ltsbins->[$bin]->{keys}){
	      for my $temp (@$key){
	       print "$temp  ";
              }
	}
	print "\n\n";
     }
   }


=back

=head1 NOTES

=head1 DEPENDENCIES

  use strict;
  use warnings;
  use Carp;
  require Exporter;
  use AutoLoader;

=head1 VERSION

$Revision: 1.4 $

=head1 AUTHOR

Author:  K Eriksen; rel 9/09/2003

  Last Update:    $Date: 2006/11/14 18:17:07 $ 
  Last Update by: $Author: kkingsbury $


=head1 HISTORY

=over 8

=item Ver: 1.4

- Fixed some POD formatting.

kkingsbury - 11/14/2006


=item Ver: 1.3

- Fixed missing end tag.

kkingsbury - 11/14/2006


=item Ver: 1.2

- Added POD, first install since being imported into CVS.

kkingsbury - 11/14/2006


=item Ver: 1.1

Initial revision

K Eriksen - 10/9/2001 

=back

=cut
########################################################################
#                        START CODE                                    #
########################################################################
require 5.005_62;
use strict;
use warnings;

use Carp;

require Exporter;
use AutoLoader qw(AUTOLOAD);

our @ISA = qw(Exporter);

our @EXPORT = qw(&lts_bins &diff_lts &lts_bybin );

our $VERSION = '1.4';

# LTS <--> LSD? Hmmm....

sub lts_bins {
    my $lts = shift;

    my (%Lts,$bin);

    open(LTS,"$lts") or
	croak "Could not open LTS $lts for reading...\n";

    $_ = <LTS>;
    until(/^Scheduled /){
	$_ = <LTS>;
    }
    
    while(<LTS>){
	if(/^Segment/){
	    /(\d{2}-\w{3}-\d{4})/;
	    $bin = $1;
	}
	if(/^Unscheduled/){
	    $bin = 'unscheduled';
	}
	if(/(^[0-9]{6})/ || /^X([0-9]{5})/ ){
	    $Lts{$1} = $bin;
#	    print "$lts  $1  $bin\n";
	}
    }
    close(LTS);

    return \%Lts;
}

#
# Manny Ramirez's lifetime slugging pct 
# after the 2000 season:      .697 
# Babe Ruth, all time leader: .692
#

sub diff_lts {
    my ($lts1,$lts2) = @_;

    my($Lts1,$Lts2);
    $Lts1 = lts_bins($lts1);
    $Lts2 = lts_bins($lts2);

    my ($seq,@moved,
	@notin1,@notin2,
	%Ltsdiff);

    foreach $seq (keys %{$Lts1}){
	if( defined($Lts2->{$seq}) ){
	    if($Lts1->{$seq} ne $Lts2->{$seq}){
		$Ltsdiff{moved}{$seq} = [$Lts1->{$seq}, $Lts2->{$seq} ];
	    }
	} else {
	    push @notin2, $seq;
	}
    }

    foreach $seq (keys %{$Lts2}){
	if( !defined($Lts1->{$seq}) ){
	    push @notin1, $seq;
	}
    }


    $Ltsdiff{notin1} = [@notin1];
    $Ltsdiff{notin2} = [@notin2];
    $Ltsdiff{lts1}   = $Lts1;
    $Ltsdiff{lts2}   = $Lts2;

    return \%Ltsdiff;
}

sub lts_bybin {
    my $lts = shift;

    my @lts;

    open(LTS,"$lts") or
	croak "Could not open LTS $lts for reading: $!\n";

    local $_ = <LTS>;
    until( /^Scheduled /){
	$_ = <LTS>;
    }

    my(%Bin,@bin);
    while(<LTS>){
	%Bin = ();
	@bin = ();

	if(/^Segment.*?([0-9]+)/){
	    my $bin = $1;
	    chop;
	    $Bin{string} = $_;
	    /(\d{2}-\w{3}-\d{4})/;
	    $Bin{date} = $1;
	    
	  LOOP:
	    until( /^$/ ){
		(/(^[0-9]{6})/ || /^X([0-9]{5})/) and
		    push @bin, $1; 
		defined ($_ = <LTS>)
		    or next LOOP;
	    }
	    $Bin{keys} = [ @bin ];
#	    push @lts, { %Bin };	    
	    $lts[$bin] = { %Bin };
	}	
    }

    return \@lts;
}

1;
__END__


