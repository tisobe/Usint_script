#!/data/mpcrit1/bin/perl -w

use blib;
use MP::FOV;

$Obs{'01042'}{SeqNbr} = '500108';
$Obs{'01042'}{SI}     = 'ACIS-S';
$Obs{'01042'}{RA}     = '286.889068';
$Obs{'01042'}{dec}    = '7.109017';
$Obs{'01042'}{yoff}   = '0 arcmin';
$Obs{'01042'}{zoff}   = '0 arcmin';
$Obs{'01042'}{zsim}   = '-11';


@MP::FOV::SURVEYS = qw(dss);

make_fov(\%Obs,"lts");

print "done.\n";

exit;

