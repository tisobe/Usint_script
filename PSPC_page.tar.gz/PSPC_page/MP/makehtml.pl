#!/data/mpcrit1/bin/perl -w

#J Grimes
# hack to make html doc pages for mp-perl-package


my $DOCDIR="/home/mp_user/mp-perl-package/MP/blib/lib/MP/";
my $OUTDIR=$DOCDIR . "/html";

while (<$DOCDIR*.pm>) {
    my ($fname)=/$DOCDIR(\S*)\.pm/;
    my $curfname=$fname . ".pm";
    `rm $OUTDIR/$fname.html`;
    `/data/mpcrit1/bin/pod2html $curfname > $OUTDIR/$fname.html`;
}
