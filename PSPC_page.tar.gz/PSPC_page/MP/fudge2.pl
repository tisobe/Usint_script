#!/data/mpcrit1/bin/perl -w

#use strict 'refs';

use blib;
use MP::FOV;
use MP::MPCAT;
use MP::SkyView;

#$Obs{'02454'}{SeqNbr} = '700393';
#$Obs{'02454'}{SI}     = 'ACIS-S';
#$Obs{'02454'}{RA}     = '213.301789';
#$Obs{'02454'}{dec}    = '-65.339960';
#$Obs{'02454'}{yoff}   = '0 arcmin';
#$Obs{'02454'}{zoff}   = '0 arcmin';
#$Obs{'02454'}{zsim}   = 0;

$Obs{'01658'}{SeqNbr} = '800126';
$Obs{'01658'}{SI}     = 'ACIS-I';
$Obs{'01658'}{RA}     = '17.367083';
$Obs{'01658'}{dec}    = '31.823000';
$Obs{'01658'}{yoff}   = '0 arcmin';
$Obs{'01658'}{zoff}   = '0 arcmin';
$Obs{'01658'}{zsim}   = -7.752000;


@MP::FOV::SURVEYS = qw(pspc);
$MP::FOV::MPDIR   = '/data/mp1/SEQNBR_test';
$MP::FOV::CDODIR  = '/pool14/eriksen';

$Missing = make_fov(\%Obs,"lts");

$num = @$Missing;
print "num missing: $num\n";

foreach $row (@$Missing){
    ($obsid,$survey) = @$row;
    $seq = $Obs{$obsid}{'SeqNbr'};
    # delete corrupt files if they exist
    $file = "$MP::FOV::MPDIR/$seq/$seq.$survey.fits";
    unlink $file if -e $file;
    push @obsids, $obsid;
}

$MP::SkyView::MPDIR = '/data/mp1/SEQNBR_test';
$MPcatID = read_mpcatID( '700393.mpc' );
get_ims(\@obsids, $MPcatID);

exit;

