package MP::NomRoll;

=head1 NAME

MP::NomRoll

=head1 PURPOSE

A Perl Extension for Calculating Chandra's Nominal Roll for a date.

=head1 SYNOPSIS

  use MP::NomRoll;
  $roll = nominal_roll( $ra, $dec, $jd );

=head1 DESCRIPTION

This subroutine takes an RA and dec (in degrees), and a Julian Day, and returns Chandra's nominal roll for that day. This code was ported from the Fortran program roll_date.f, which resides in /data/mpcrit1/bin, and was written by Pat Slane (slane@head-cfa.harvard.edu).

=head2 EXPORTS
    
    nominal_roll()

=head2 Methods

=over 8

=item nominal_roll

I<Usage>: 

    my $roll = nominal_roll($RA, $DEC, $jd)

I<Provides>: Given a RA and DEC in degress and a julian date (not mjd). Returns the Roll.

I<Arguments>:

      RA  = the RA in degrees.
      Dec = the Dec in degrees.
      jd  = the date in julian date format.

I<Output>:

      roll in degrees.

I<Examples>:

      my $roll = nominal_roll( 275.124583333333, -16.1791388888889, 2454009.5 )
      roll =  272.391448310641

=back


=head1 EXAMPLES

=over 8 

=item nominal_roll

Find Nominal Roll for a date:

  my $roll = nominal_roll( 275.124583333333, -16.1791388888889, 2454009.5 )

Returns:

  $roll =  272.391448310641

=back

=head1 NOTES


=head1 DEPENDENCIES

  use strict;
  use warnings;
  require Exporter;
  use AutoLoader qw(AUTOLOAD);
  use POSIX;

=head1 VERSION

$Revision: 1.9 $

=head1 AUTHOR

Author:  K Eriksen; rel 7/12/2001

  Last Update:    $Date: 2006/11/14 18:16:00 $ 
  Last Update by: $Author: kkingsbury $


=head1 HISTORY

=over 8

=item Ver: 1.9

- Fixed some POD formatting.

kkingsbury - 11/14/2006


=item Ver: 1.8

- Installed to different location, changing checkin to install to 'site_perl/5.6.0/sun4-solaris/'

kkingsbury - 11/14/2006


=item Ver: 1.7

- yet another failed reinstall, trying again (bugs in cvscommit.pl, hopefully fixed now).

kkingsbury - 11/14/2006


=item Ver: 1.6

- Reinstall failed, trying again.

kkingsbury - 11/14/2006


=item Ver: 1.5

- Installed to incorrect location, reinstalling to correct locations.

kkingsbury - 11/14/2006


=item Ver: 1.4

- Fixed POD formating, added Dependencies

kkingsbury - 11/14/2006


=item Ver: 1.3

- Changes and README were not updated automatically. Fixed and retrying

kkingsbury - 11/03/2006


=item Ver: 1.2

- Placed under CVS control. Added POD.

kkingsbury - 11/03/2006


=item Ver: 1.1

Initial revision

K Eriksen - 7/12/2001 

=back

=cut
########################################################################
#                        START CODE                                    #
########################################################################

require 5.005_62;
use strict;
use warnings;

require Exporter;
use AutoLoader qw(AUTOLOAD);

use POSIX;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration	use MP::NomRoll ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(
	
) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(&nominal_roll
	
);

#Will be auto updated during check-in:
our $VERSION = '1.9';

my $pi  = acos(-1.0);
my $tpi = $pi * 2.0;
my $deg2rad = $pi/180.0;

# Preloaded methods go here.
sub nominal_roll {
    my ($ra,$dec,$jd) = @_;
    
    my $alpha = $ra  * $deg2rad;
    my $delta = $dec * $deg2rad;

#c
#c >>> 	get sun vector
#c
    my @sun = postsun($ra,$jd);
    
#c
#c >>>   normalize the sun vector
#c
    my $snorm  = sqrt($sun[0]**2 + $sun[1]**2 + $sun[2]**2);
    $sun[0] = $sun[0]/$snorm;
    $sun[1] = $sun[1]/$snorm;
    $sun[2] = $sun[2]/$snorm;

    my $t1  = 0.;
    my $t2  = -$sun[0] * cos($alpha) * sin($delta) - $sun[1] * sin($alpha)* sin($delta) 
	+ $sun[2] * cos($delta);
    my $t3  = -$sun[0]* sin($alpha) + $sun[1] * cos($alpha);
    my $eta = atan2($t2,$t3);
    
#c
#c >>>	  calculate roll
#c
    my $phi = $eta + acos(-$t1/sqrt($t2*$t2 + $t3*$t3));
    $phi = $phi/$deg2rad;
    $phi += 360.0 if $phi < 0;

    return $phi;
}

sub postsun {
    my ($ra,$jd) = @_;

    my $xdays = $jd - 2451545.0;
        
    # Mean longitude of sun (corrected for aberration)
    my $xml = 4.894950 + 0.017202792 * $xdays;
    $xml = fmod( $xml, $tpi );
    $xml += $tpi if $xml < 0.0;

    # mean anomaly (g), ecliptic longitude (xlam), and obliquity of ecliptic (eclip)
    my $g     = 6.24004 + 0.01720197 * $xdays;
    my $xlam  = $xml + 0.033423*sin($g) + 0.000349*sin(2.0 * $g);
    my $eclip = 0.409088 - 6.98e-9 * $xdays;

    # determine RA and dec of siun

    my $t = tan($eclip/2.0)**2.0;
    my $rasun  = $xlam - $t*sin(2.0*$xlam) + 0.5 * $t**2.0 * sin(4.0*$xlam);
    my $decsun = asin( sin($eclip) * sin($xlam) );
    my $radsun = 1.00014 - 0.01671 * cos($g) - 0.00014 * cos(2.0*$g) * $ra;

    #c  Convert right ascension/declination to an ECI position vector (from S/C 
    #c  to sun).  It is assumed that the S/C is at Earth center of mass -- for 
    #c  low earth orbiters (i.e., less than 2000 km altitude) this assumption 
    #c  produces a maximum angular error of about 0.003 degrees.
    
    my @xsun;
    $xsun[0] = $radsun * cos($decsun) * cos($rasun);
    $xsun[1] = $radsun * cos($decsun) * sin($rasun);
    $xsun[2] = $radsun * sin($decsun);

    return @xsun;
}

# Autoload methods go after =cut, and are processed by the autosplit program.

1;
__END__
