package MP::Visibility;

=head1 NAME

MP::Visibility

=head1 PURPOSE

A Perl Extension to provide visibility, roll angle, and pitch angle calculation routines.

=head1 SYNOPSIS

  use MP::Visibility;

  $orbits = parse_ephem();

  $percent_visibility = vis_per_orbit( $target_ra, $target_dec, $jd, $orbits );
  $nominal_roll = roll( $target_ra, $target_dec, $jd, $orbits );
  $pitch = pitch( $target_ra, $target_dec, $jd, $orbits );

  $ephemeris_line = interpolate( $jd, $orbits );
  $actual_visibilities = vis( $target_ra, $target_dec, $ephemeris_line );

  %reason = low_vis_reason ( $target_ra,$target_dec,$start_jd,$end_jd, $orbits );

=head1 DESCRIPTION

This module provides routines for calculation of visibility, 
roll, and pitch.  

Nearly all routines require that parse_ephem() is called from the script to provide a Perl-ified version of the latest MPVis-style ephemeris.  This routine may be called with an explicit ephemeris to parse, eg. 

    $orbits = parse_ephem( "/data/mpcrit1/bin/visplot/cxo.cycle4.eph" );

or it may be called without arguments, eg.

    $orbits = parse_ephem();

in which case it will default to using the $ASCDS_MPVIS_EPHEMERIS, if this environment variable is set, or else it will default to a hard-coded default ephemeris, which is currently set to  

    $EPHEMERIS = "/data/mpcrit1/bin/visplot/cxo.cycle9.eph";

This variable should be changed in Visibility.pm whenever a new ephemeris is required.  For reference, the current ephemeris columns are:

  0:  Elapsed time (minutes)
  1:  whole Julian date
  2:  fractional Julian date
  3:  mean anomaly
  4:  Earth RA  (satellite FOR)
  5:  Earth dec
  6:  Earth distance
  7:  Moon RA
  8:  Moon dec
  9:  Moon distance
  10: Sun RA
  11: Sun dec

The routine vis_per_orbit() , takes a target RA and Dec, a Julian Date, and a reference to a parsed ephemeris (from parse_ephem() ).  It calculates the total time in the orbit that includes the specified JD, and returns the percent of this time that the target is visible from Chandra.  

The routine roll() calculates the nominal roll angle for Chandra at a given RA and Dec on the given Julian Date.  It returns a reference to a two-element array containing the nominal roll angle and the maximum allowed off-nominal roll, both in degrees.  Please note that it differs from the routine supplied in MP::NomRoll only in that: (1) it uses a current ephemeris to interpolate sun position angles, rather than calculating them, as MP::NomRoll does, and (2) it returns the tolerance on the nominal roll as well as the roll angle itself.

The routine pitch() calculates the pitch angle for Chandra at a given RA and Dec on the given Julian Date.  It returns the pitch angle as a scalar value, in units of degrees.

The routine vis() calculates actual Boolean visibilities of a target, given an RA, Dec, and reference to an ephemeris line (eg. the first line from the first orbit in a parsed ephemeris called $orbits from parse_ephem() would be $orbits->[0]->[0]).  At any given time, a target is either visible to Chandra or it is not.  vis() returns a total visibility of 1 if the target is visible and 0 if it is not, but it also provides the breakdown of why a target is or is not visible: it returns a reference to an array containing:

  0:  total visibility (0 or 1)
  1:  sun visibility (0 or 1)
  2:  earth visibility (0 or 1)
  3:  moon visibility (0 or 1)
  4:  radzone visibility (0 or 1)

Total visibility is only 1 if all other visibilities are also 1.

The routine low_vis_reason() takes a target RA and Dec, a start and end date (in Julian Date), and a reference to a parsed ephemeris (from parse_ephem() ).  It determines the orbits that including and between the specified JDs, and returns hash of JDs from the ephems in which the target is NOT visible from Chandra. The hash keys are the JDs and values are a one letter reason for the low visibility (s=sunblock, m=moonblock, e=earthblok and r=radzone).

The routine interpolate() is a routine used internally by MP::Visibility to find appropriate ephemeris values for a JD not listed explicitly in the ephemeris.  It is not expected to be used as much as the other supplied routines, but it is exported as part of the package because it may be used (1) with the vis routine to calculate actual visibilities on arbitrary dates (see Example 2 below), and (2) to return interpolated ephemeris values, such as sun positions, on arbitrary dates.

=head2 EXPORTS

  parse_ephem()
  vis_per_orbit() 
  roll() 
  pitch() 
  interpolate() 
  vis()
  low_vis_reason()

=head2 Methods

=over 8

=item parse_ephem

I<Usage>: 

    $orbits = parse_ephem($EPHEMERIS)

I<Provides>: This subroutine takes an ephemeris file name, opens the file, and parses the fields into a usable format, splitting it into an array of orbits, each containing an array of ephemeris lines, split into an array of ephemeris fields.

I<Arguments>:

  Ephemeris file name.

I<Output>:

Reference to array of ephemeris fields, split by orbits
    
     Structure:
     $orbits -> ( orbit_0 -> ( line_0 -> ( field_0, field_1 ... ),
                               line_1 -> ( field_0, field_1 ... ),
                               ... ),
                  orbit_1 -> ( line_0 -> ( field_0, field_1 ... ),
                               line_1 -> ( field_0, field_1 ... ),
                               ... ),
                  ...)

I<Examples>:
     
    my $orbits = parse_ephem($EPHEMfilename);

=item vis_per_orbit

I<Usage>: 

    $percent_vis = vis_per_orbit($ra, $dec, $mjd, $orbits )

I<Provides>: This routine vis_per_orbit() , takes a target RA and Dec, a Julian Date, and a reference to a parsed ephemeris (from &parse_ephem).  It calculates the total time in the orbit that includes the specified JD, and returns the percent of this time that the target is visible from Chandra.  

I<Arguments>:

    RA = target RA in deg.
    Dec = taregt Dec in deg.
    jd = Julian Date of time you wish to know.
    orbits = parsed ephemeris file.

I<Output>:
    
    percent visibility in orbit containing jd (from 0 to 1, such as 0.69441).

I<Examples>:
     
    my $perc = vis_per_orbit( $targ_ra, $targ_dec, $eph_line->[1], $orbits );
    print ($perc*100) . "% Visible\n";

=item roll

I<Usage>: 
    
    my $roll = roll( $ra, $dec, $jd, $ephem );

I<Provides>: Calculates the nominal roll angle and maximum off-nominal roll.
The routine roll() calculates the nominal roll angle for Chandra at a given RA and Dec on the given Julian Date.  It returns a reference to a two-element array containing the nominal roll angle and the maximum allowed off-nominal roll, both in degrees.  Please note that it differs from the routine supplied in MP::NomRoll only in that: (1) it uses a current ephemeris to interpolate sun position angles, rather than calculating them, as MP::NomRoll does, and (2) it returns the tolerance on the nominal roll as well as the roll angle itself.


I<Arguments>:

    RA = target RA in deg.
    Dec = taregt Dec in deg.
    jd = Julian Date of time you wish to know.
    orbits = parsed ephemeris file.

I<Output>:
    
  Nominal roll angle (deg), max. off-nominal roll (deg)


I<Examples>:
     
  my $roll  = roll( $ra, $dec, $jd, $ephem );


=item pitch

I<Usage>: 
    
  my $pitch = pitch( $ra, $dec, $jd, $ephem );
		

I<Provides>: calculates Chandra's pitch angle for a given RA/Dec. The routine pitch() calculates the pitch angle for Chandra at a given RA and Dec on the given Julian Date.  It returns the pitch angle as a scalar value, in units of degrees.

I<Arguments>:

    RA = target RA in deg.
    Dec = taregt Dec in deg.
    jd = Julian Date of time you wish to know.
    orbits = parsed ephemeris file.

I<Output>:
    
  angle between sun and target (in degrees)

I<Examples>:
     
   my $pitch = pitch( $ra, $dec, $jd, $ephem );


=item interpolate

I<Usage>: 
    
    my $ephemeris_line = interpolate( $jd, $orbits );
  

I<Provides>: This subroutine finds ephemeris values for arbitrary dates within the overall range of the ephemeris. The routine interpolate() is a routine used internally by MP::Visibility to find appropriate ephemeris values for a JD not listed explicitly in the ephemeris.  It is not expected to be used as much as the other supplied routines, but it is exported as part of the package because it may be used (1) with the vis routine to calculate actual visibilities on arbitrary dates (see Example 2 below), and (2) to return interpolated ephemeris values, such as sun positions, on arbitrary dates.



I<Arguments>:

    jd = Julian Date of time you wish to know.
    orbits = orbit ephemeris reference (from parse_ephem() )

I<Output>:

Reference to an interpolated ephemeris line. Format is same as that from parse_ephem() -- whole JD is added to the fractional JD.

I<Examples>:
     
    my $eph_line = interpolate( $jd, $orbits );
    my $sunx = eci( $eph_line->[10], $eph_line->[11] );


=item low_vis_reason

I<Usage>: 

    $percent_vis = low_vis_reason($ra, $dec, $jd1, $jd2, $orbits )

I<Provides>: jd times and reasons for low visibility in the specified time range. This routine low_vis_reason() , takes a target RA and Dec, a starting and ending Julian Date, and a reference to a parsed ephemeris (from &parse_ephem). It determines the orbits that including and between the specified JDs, and returns hash of JDs from the ephems in which the target is NOT visible from Chandra. The hash keys are the JDs and values are a one letter reason for the low visibility (s=sunblock, m=moonblock, e=earthblok and r=radzone).

I<Arguments>:

    RA = target RA in deg.
    Dec = taregt Dec in deg.
    jd1 = Julian Date of the beginning of the window you wish to know.
    jd2 = Julian Date of the end of the window you wish to know.
   orbits = parsed ephemeris file.

I<Output>:
    
    hash of julians dates with their values set to the low vis reason (s=sunblock, m=moonblock, e=earthblok and r=radzone)

I<Examples>:
     
    my %reason = low_vis_reason( $targ_ra, $targ_dec, $jd1, $jd2, $orbits );
    for my $date (sort { $a <=> $b }keys( %reason)) {
         my ($doy,$yr,$ut) = mjd2dayno(jd2mjd($date));
         print "Low vis on doy $doy for $reason{$date}";
    }

=item vis

I<Usage>: 
    
  my $vis = vis( $ra, $dec, $eph_line ); 

I<Provides>: Calculates Boolean values for visiblity of target at a given RA and Dec with respect to the Sun, Earth, Moon, and Radiation Zones, as well as a total visibility.  Values are: 1 if visible, 0 if not.  Total visibility will be zero unless all other visibilities are 1.

The routine vis() calculates actual Boolean visibilities of a target, given an RA, Dec, and reference to an ephemeris line (eg. the first line from the first orbit in a parsed ephemeris called $orbits from parse_ephem() would be $orbits->[0]->[0]).  At any given time, a target is either visible to Chandra or it is not.  vis() returns a total visibility of 1 if the target is visible and 0 if it is not, but it also provides the breakdown of why a target is or is not visible: it returns a reference to an array containing:

  0:  total visibility (0 or 1)
  1:  sun visibility (0 or 1)
  2:  earth visibility (0 or 1)
  3:  moon visibility (0 or 1)
  4:  radzone visibility (0 or 1)


I<Arguments>:

    RA = target RA in deg.
    Dec = taregt Dec in deg.
    jd = Julian Date of time you wish to know.
    orbits = parsed ephemeris file.

I<Output>:

Reference to array containing total_vis, sun_vis, earth_vis, moon_vis, radzone_vis

I<Examples>:

	my $vis = vis( $ra, $dec, $eph_line ); 
	unshift @svis, $vis->[1] * .56;
	unshift @svis, $vis->[2] * .36;
	unshift @evis, $vis->[2] * .36;
	unshift @mvis, $vis->[3] * .16;
	unshift @rvis, $vis->[4] * .06;
	     


=back

=head1 EXAMPLES

=over 8 

=item Example 1:

The following script prints to STDOUT:

  orbit_nbr  JD  %vis  pitch  roll +/- roll_tol

for every orbit in the default ephemeris.


  #!/data/mpcrit1/bin/perl -w

  use strict;
  use MP::Visibility;

  my ($targ_ra, $targ_dec);
  if ( @ARGV == 2 ) {
    $targ_ra  = $ARGV[0];
    $targ_dec = $ARGV[1];
  } else {
    die "usage: example.pl ra dec\n";
  }

  my $orbits = parse_ephem();

  my $i = 0;
  for my $orbit (@$orbits) {

    my $eph_line = $orbit->[0];

    printf "%3.3s  %.6f  %.3f  %.3f  ",
           $i, $eph_line->[1],
           vis_per_orbit( $targ_ra, $targ_dec, $eph_line->[1], $orbits ),
           pitch( $targ_ra, $targ_dec, $eph_line->[1], $orbits );
    
    my $roll = roll( $targ_ra, $targ_dec, $eph_line->[1], $orbits );
    printf "%.3f +/- %.3f\n", 
           $roll->[0], $roll->[1];

    $i++;
  }



=item Example 2:

This script tests the actual visibility of a target on a given JD and prints the information to STDOUT, including reason(s) for why it is not visible.


  #!/data/mpcrit1/bin/perl -w

  use strict;
  use Visibility;

  my ($target_ra, $target_dec, $jd);
  if ( @ARGV == 3 ) {
    $target_ra  = $ARGV[0];
    $target_dec = $ARGV[1];
    $jd         = $ARGV[2];
  } else {
    die "usage: example2.pl ra dec jd\n";
  }

  my $orbits = parse_ephem();
  my $ephemeris_line = interpolate( $jd, $orbits );
  my $vis = vis( $target_ra, $target_dec, $ephemeris_line );

  if ( $vis->[0] == 1 ) {
    print "Target at RA $target_ra, Dec $target_dec ",
          "is visible at JD $jd.\n";
  } else {
    print "Target at RA $target_ra, Dec $target_dec ",
          "is not visible at JD $jd.\n";
    if ( $vis->[1] == 0 ) {
	print "It is sunblocked.\n";
    }
    if ( $vis->[2] == 0 ) {
	print "It is earthblocked.\n";
    }
    if ( $vis->[3] == 0 ) {
	print "It is moonblocked.\n";
    }
    if ( $vis->[4] == 0 ) {
	print "It is in radzone.\n";
    }
 }

=back

=head1 FILES

=over 8

=item I< MPVis ephemeris >

Default MPVis ephemeris (created by JCOAST -- see http://hea-www.harvard.edu/asclocal/mp/html/ckbk/ephem.html for more information on how to create a new ephemeris)

C<my $EPHEMERIS => F</data/mpcrit1/bin/visplot/cxo.cycle8.eph>

    Current ephemeris columns:    
     0:  Elapsed time (minutes)
     1:  whole Julian date
     2:  fractional Julian date
     3:  mean anomaly
     4:  Earth RA  (satellite FOR)
     5:  Earth dec
     6:  Earth distance
     7:  Moon RA
     8:  Moon dec
     9:  Moon distance
     10: Sun RA
     11: Sun dec


=back

=head1 NOTES


Based on K. Eriksen's visibility.c.  Only changes from visibility.c are in usage and implementation, as well as minor bug fixes -- all algorithms that actually calculate visibility, roll, and pitch are either K. Eriksen's or P. Slane's.

=head2 Constants

=over 8

=item Sun

C<my $SUN_C => F<46.25> 

Constraint angle for sun (from the center).


C<my $SUN_D => F<1.5e8> 

Mean solar distance


C<my $SUN_R => F<6.96e5> 

Sun diameter

=item Earth

C<my $EARTH_C => F<10.0>  

Constraint angle for earth



C<my $EARTH_R => F<6378.0>  

Earth diameter

=item Moon

C<my $MOON_C => F<6.0>   

Constraint angle for moon

C<my $MOON_R => F<1738.0>  

Moon diameter

=item Rad Zone

C<my $RADZONE => F<8.0e4> 

Altitude of radiation zone

=item Time Tolerance

C<$my T_TOL => F<10.0> 

Time tolerance for hunting (used in change_time() ) in minutes

=back 


=head1 DEPENDENCIES

  use strict;
  use warnings;
  use AutoLoader qw(AUTOLOAD);
  require Exporter;
  use Carp;
  use POSIX;

=head1 VERSION

$Revision: 1.9 $

=head1 AUTHOR

Author:  M. Clarke; rel 7/12/2001

  Last Update:    $Date: 2008/11/24 21:15:41 $ 
  Last Update by: $Author: kkingsbury $


=head1 HISTORY

=over 8

=item Ver: 1.9

- Updated ephemeris for Cycle10.

kkingsbury - 11/24/2008


=item Ver: 1.8

-added low_vis_reason() routine

heidi - 08/08/2008


=item Ver: 1.7

Modified change_time so that it doesn't modify the emphemeris stored in $orbits.

srandall - 01/22/2008


=item Ver: 1.6

Updated for cycle 9.

srandall - 11/19/2007


=item Ver: 1.5

- Made certain vars be "our" instead of "my" to allow other scripts (such as pool_picker) to use these as defaults.

kkingsbury - 11/27/2006


=item Ver: 1.4

- Still working out install location bug.

kkingsbury - 11/27/2006


=item Ver: 1.3

- Changed ephemeris for cycle 8 changeover.

kkingsbury - 11/27/2006


=item Ver: 1.2

- Updated POD, imported into CVS control.

- Updated Sun restriction to match the FOT (46.25)

kkingsbury - 11/20/2006


=item Ver: 1.1

Initial revision

K Eriksen - 7/12/2001 

=back

=cut
########################################################################
#                        START CODE                                    #
########################################################################

require 5.005_62;

use strict;
use warnings;
use AutoLoader qw(AUTOLOAD);

require Exporter;

our @ISA = qw(Exporter);
our @EXPORT = qw( 
		  &parse_ephem
		  &vis_per_orbit 
		  &roll 
		  &pitch 
		  &interpolate 
		  &vis
                  &low_vis_reason
		);

our $VERSION = '1.9';

use Carp;
use POSIX;

our $SUN_C   = 46.25;      # constraint angle for sun
our $EARTH_C = 10.0;      # constraint angle for earth
our $MOON_C  = 6.0;       # constraint angle for moon
our $SUN_R   = 6.96e5;    # sun diameter
our $EARTH_R = 6378.0;    # earth diameter
our $MOON_R  = 1738.0;    # moon diameter
our $RADZONE = 8.0e4;     # altitude of radiation zone
our $SUN_D   = 1.5e8;     # mean solar distance
our $T_TOL   = 10.0;      # time tolerance for hunting 
                         #  (used in &change_time) in
                         #  minutes

my $pi  = acos(-1.0);
my $deg2rad = $pi/180.0; # for angle conversions


# Default MPVis ephemeris (created by JCOAST -- see
# http://hea-www.harvard.edu/asclocal/mp/html/ckbk/ephem.html
# for more information on how to create a new ephemeris)

my $EPHEMERIS = "/data/mpcrit1/bin/visplot/cxo.cycle10.eph";


    # Current ephemeris columns:    
    #  0:  Elapsed time (minutes)
    #  1:  whole Julian date
    #  2:  fractional Julian date
    #  3:  mean anomaly
    #  4:  Earth RA  (satellite FOR)
    #  5:  Earth dec
    #  6:  Earth distance
    #  7:  Moon RA
    #  8:  Moon dec
    #  9:  Moon distance
    #  10: Sun RA
    #  11: Sun dec



# parse_ephem
#
# Description: This subroutine takes an ephemeris file name,
#     opens the file, and parses the fields into a usable
#     format, splitting it into an array of orbits, each
#     containing an array of ephemeris lines, split into an
#     array of ephemeris fields.
# Arguments: ephemeris file name
# Output: reference to array of ephemeris fields, split by orbits
#     Structure:
#     $orbits -> ( orbit_0 -> ( line_0 -> ( field_0, field_1 ... ),
#                               line_1 -> ( field_0, field_1 ... ),
#                               ... ),
#                  orbit_1 -> ( line_0 -> ( field_0, field_1 ... ),
#                               line_1 -> ( field_0, field_1 ... ),
#                               ... ),
#                  ...)

sub parse_ephem {

    my $eph;
    if ( @_ ) {
	$eph = $_[0];  # if &parse_ephem is called with an
	               # argument, use the argument as the 
	               # ephemeris

    } elsif ( $ENV{ASCDS_MPVIS_EPHEMERIS} ) {  # otherwise, use
	                                       # whatever's in the
                                               # ASCDS_MPVIS_EPHEMERIS
	$eph = $ENV{ASCDS_MPVIS_EPHEMERIS};    # environment variable

    } else {                  

	$eph = $EPHEMERIS;   # otherwise, use the default ephemeris
    }

    open (EPHEM, $eph) or
	croak "Error: could not open ephemeris file $eph\n".
	      "Try unsetting the environment variable ".
	      "ASCDS_MPVIS_EPHEMERIS.\n";

    chomp ( my @ephem = <EPHEM> );  # read ephemeris into an array


    my @orbits;

    my $i = 0; # for orbit tracking

    for ( my $j=0; $j < @ephem; $j++ ) {
	my $eph_line = $ephem[$j];
	my @fields = split " ", $eph_line;

	# Add fractional JD to whole JD:
	$fields[1] += $fields[2];

	push @{$orbits[$i]}, \@fields;

	my $next_line;
	if ($j == @ephem - 1) {
	    $next_line = $eph_line;
	} else {
	    $next_line = $ephem[$j+1];
	}
	my @next_fields = split " ", $next_line;
	$next_fields[1] += $next_fields[2];
	
	if ( 
	     $fields[3] > 340 
	    and 
	     $next_fields[3] < 20
	   )
	    # when mean anomaly == 360, Chandra is at perigee.
	    # Usually there is a line in the ephemeris with
	    # mean anomaly > 359.99, but occasionally there is
	    # an orbit that ends with mean anomaly ~348 -- the
	    # first condition below takes care of that
	{   

	    if ($fields[3] < 359.99) {
		my $perigee_line = perigee_time( \@fields, \@next_fields );
		push @{$orbits[$i]}, $perigee_line;

		$i++;
		push @{$orbits[$i]}, $perigee_line;
	    } else {
		$i++;
		push @{$orbits[$i]}, \@fields;
	    }
	      # this pushes the ephemeris line onto the
	      # end of one orbit, and the beginning of
	      # the next -- otherwise, it may be difficult
	      # to tell which orbit an arbitrary time
	      # belongs to
	}
    }

    return \@orbits;
}


# vis_per_orbit
#
# Description: This subroutine returns the percent of
#     the total time in an orbit that a target at a 
#     particular RA and Dec is visible.  
# Arguments: RA (deg), Dec (deg), jd, reference to array 
#     containing ephemeris lines (from &parse_ephem)
# Output: percent visibility in orbit containing jd

sub vis_per_orbit {
    
    my $ra         = $_[0];
    my $dec        = $_[1];
    my $jd         = $_[2];
    my $orbits_ref = $_[3];

    my @orbits = @{$orbits_ref};

    my $targ_orbit;
    if ( $jd < $orbits[0]->[0]->[1] ) {
	croak "JD $jd is earlier than earliest time in ephemeris\n";
    } elsif ( $jd > $orbits[-1]->[-1]->[1] ) {
	croak "JD $jd is later than latest time in ephemeris\n";
    } else {

	$targ_orbit = 0;

	# find the orbit containing $jd:
	for ( my $j = 0; $j < @orbits; $j++ ) {

	    if ( 
		 $jd >= $orbits[$j]->[0]->[1]
		and
		 $jd <  $orbits[$j]->[-1]->[1]
	       )
	    {
		$targ_orbit = $j;
		last;
	    }

	}
    }

    my $orbit_start = $orbits[ $targ_orbit ]->[0]->[1];
    my $orbit_end   = $orbits[ $targ_orbit ]->[-1]->[1];
    my $init_vis    = vis( $ra, $dec, $orbits[ $targ_orbit ]->[0] );
      # this is the total visibility at the beginning 
      # of the orbit
    

    my $view_time  = 0; # this variable holds the total
                        # amount of time that target is
                        # visible from Chandra


    # initialize with first line of the orbit:
    my $start_time = $orbit_start;                                      
    my $start_line = $orbits[ $targ_orbit ]->[0];

    # step through the orbit, line by line, adding time
    # to $view_time if the target is visible
    for my $next_line ( @{ $orbits[ $targ_orbit ] } ) {
	
	# previously, this routine was using a reference, which
	# cause the global $orbits structure to get modified.
	# This didn't seem intentional, and broke some things
	# in random ways, so this hack makes a local copy of the 
	# array and references it, rather than update the array
	# for the passed reference.
	my @local_next_line = @$next_line;
	my $local_next_ref = \@local_next_line;

	my $next_vis  = vis( $ra, $dec, $local_next_ref );
	my $next_time = $local_next_ref->[1];

	unless ( $next_vis->[0] == $init_vis->[0] ) {
	    $local_next_ref = change_time( $ra, $dec, $init_vis, 
				      $start_line, $local_next_ref );
	       # this calculates the exact point in 
	       # the orbit (to within 10 minutes) when
	       # the visibility switches from 0 to 1 or
	       # vice versa

	    $next_time = $local_next_ref->[1];
	}

	if ( $init_vis->[0] == 1 ) {	    
	    $view_time += $next_time - $start_time;
	}
	
	# make the 'next' values the new 'start' values:
	$init_vis = $next_vis;
	$start_time = $next_time;
	$start_line = $local_next_ref;
    }

    return ( $view_time / ( $orbit_end - $orbit_start ) );

}


# vis
#
# Description: calculates Boolean values for visiblity
#     of target at a given RA and Dec with respect to 
#     the Sun, Earth, Moon, and Radiation Zones, as well
#     as a total visibility.  Values are: 1 if visible, 
#     0 if not.  Total visibility will be zero unless all
#     other visibilities are 1.
# Arguments: ra(deg), dec(deg), reference to array of 
#     ephemeris line fields (from &parse_ephem)
# Output: reference to array containing total_vis, sun_vis, 
#     earth_vis, moon_vis, radzone_vis

sub vis {

    my ( $ra, $dec, $eph_line ) = @_;

    # calculate sun, earth, and moon visibilities:
    my $sun_vis = vis_calc( $ra, $dec, $eph_line->[10],
			    $eph_line->[11], $SUN_D, $SUN_C, 
			    $SUN_R );
    
    my $earth_vis = vis_calc( $ra, $dec, $eph_line->[4], $eph_line->[5], 
			      ($eph_line->[6] + $EARTH_R), $EARTH_C, 
			      $EARTH_R );

    my $moon_vis = vis_calc( $ra, $dec, $eph_line->[7], 
			     $eph_line->[8], $eph_line->[9],
			     $MOON_C, $MOON_R );


    my ( $radzone_vis, $total_vis );

    # calculate radzone visibility:
    if ( $eph_line->[6] < $RADZONE ) {
        $radzone_vis = 0;
    } else {
        $radzone_vis = 1;
    }

    # find total visibility:
    if ( $sun_vis + $earth_vis + $moon_vis + $radzone_vis == 4 ) {
        $total_vis = 1;
    } else {
        $total_vis = 0;
    }

    return [ $total_vis, $sun_vis, $earth_vis, $moon_vis, $radzone_vis ];

}


# vis_calc
#
# Description: performs actual visibility calculations for
#     solar system objects, given all the relevant parameters
# Arguments: target ra (deg), target dec (deg),  object ra (deg),
#     object dec (deg), object distance, constraint angle (deg),
#     object radius
# Output: Boolean value (1 = visible, 0 = not)

sub vis_calc {
    
    my ( $targ_ra, $targ_dec, $obj_ra, 
	 $obj_dec, $distance, $constraint, $radius ) = @_;

    # convert degrees to radians:
    $targ_ra  *= $deg2rad;
    $targ_dec *= $deg2rad;

    $obj_ra   *= $deg2rad;
    $obj_dec  *= $deg2rad;


    # trigonometry:
    my $t1 = sin( $targ_dec ) * sin( $obj_dec );
    my $t2 = cos( $targ_dec ) * cos( $obj_dec ) 
	                      * cos( $targ_ra - $obj_ra ); 

    # if calculating the sun visibility, use the distance
    # from the center of the sun; otherwise, use the distance
    # from the limb of the object

    my $theta;
    if ( $constraint == $SUN_C ) {
	$theta = acos( $t1 + $t2 ) * 180.0 / $pi;
    } else {
	$theta = ( acos( $t1 + $t2 ) - $radius/$distance ) * 180.0 / $pi;
    }

    if ( $theta < $constraint ) {
        return 0;
    } else {
        return 1;
    }
}


# change_time
#
# Description: This is a recursive bisection hunt used by 
#     &vis_per_orbit to find the time at which visibility
#     of a target changes from visible to not visible, or
#     vice versa.  The precision of the time of change is
#     set by the $T_TOL variable at the top of this file.
# Arguments: ra(deg), dec(deg), initial visibility, 
#     beginning ephemeris line reference, ending ephemeris
#     line reference
# Output: ephemeris line based on time of visibility change, 
#         within $T_TOL minutes

sub change_time {
    
    my ( $ra, $dec, $init_vis, $eph_early, $eph_late ) = @_;
    
    # define the stopping case for the recursive function:
    if ( abs( $eph_late->[0] - $eph_early->[0] ) < $T_TOL/2.0 ) {

	return $eph_late;

    } else {
	
	# interpolate midpoint values between the first
	# and last ephemeris lines given, for each
	# ephemeris field:
	my $eph_mid = populate_eph( $eph_early, $eph_late, .5);

	# find the visibility at this point:
	my $mid_vis = vis( $ra, $dec, $eph_mid );
	

	# if the visibility is the same as it was before,
	# set the earlier ephemeris line to the midpoint
	# values; otherwise, set the later ephemeris line
	# to the midpoint values

	if ( $mid_vis->[0] == $init_vis->[0] ) {
	    $eph_early = $eph_mid;
	} else {
	    $eph_late = $eph_mid;
	}
	
	# call the function again:
	return change_time( $ra, $dec, $init_vis, 
			    $eph_early, $eph_late );
    }
}



# perigee_time
#
# Description: This is another recursive bisection hunt used by 
#     &parse_ephem to find the time of perigee, for those
#     orbits for which it's not obvious in the ephemeris.The 
#     precision of the perigee time is set by the $T_TOL variable 
#     at the top of this file.
# Arguments: beginning ephemeris line reference, ending ephemeris 
#     line reference
# Output: ephemeris line based on time of perigee, within $T_TOL 
#         minutes

sub perigee_time {
    
    my ( $eph_early, $eph_late ) = @_;
    
    # define the stopping case for the recursive function:
    if ( 
	 abs( $eph_late->[0] - $eph_early->[0] ) < $T_TOL/2.0 
	or
	 $eph_early->[3] == 360
       ) 
    {

	return $eph_early;

    } else {
	
	# interpolate midpoint values between the first
	# and last ephemeris lines given, for each
	# ephemeris field:
	my $eph_mid = populate_eph( $eph_early, $eph_late, .5);


	# mean anomaly for eph_early should be 360 or less;
	# eph_late should be 0 or more
	if ( $eph_mid->[3] >= $eph_early->[3] ) {
	    $eph_early = $eph_mid;
	} else {
	    $eph_late = $eph_mid;
	}

	# call the function again:
	return perigee_time( $eph_early, $eph_late );
    }
}



# interpolate
#
# Description: This subroutine finds ephemeris values for 
#     arbitrary dates within the overall range of the 
#     ephemeris
# Argument: jd, orbit ephemeris reference (from &parse_ephem)
# Output: reference to an interpolated ephem. line.
#     Format is same as that from &parse_ephem -- whole JD
#     is added to the fractional JD.

sub interpolate {

    my ( $jd, $orbits_ref ) = @_;

    my @orbits = @{$orbits_ref}; # dereference $orbits_ref
                                 # for efficiency

    if ( $jd < $orbits[0]->[0]->[1] ) {
	croak "JD $jd is earlier than earliest time in ephemeris\n";
    } elsif ( $jd > $orbits[-1]->[-1]->[1] ) {
	croak "JD $jd is later than latest time in ephemeris\n";
    } else {

	my $eph_line;

	for ( my $i = 0; $i < @orbits; $i++ ) {

	    # find the orbit containing $jd:

	    if ( $jd == $orbits[-1]->[-1]->[1] ) {
		return $orbits[-1]->[-1];
	    }
	    if ( 
		 $jd >= $orbits[$i]->[0]->[1]
		and
		 $jd <  $orbits[$i]->[-1]->[1]
	       )
	    {
	      
		for ( my $j = 0; $j < @{$orbits[$i]}; $j++ ) {
		    
		    my $first = $orbits[$i]->[$j];
		    my $last  = $orbits[$i]->[$j+1];
		    
		    # find the ephemeris lines for which $jd
		    # falls between given ephemeris dates:
		    if (
			 $jd >= $first->[1]
			and
			 $jd <   $last->[1]
		       )
		    {
			# find how far JD is from the first
			# JD as a fraction of the distance between
			# the first and last JD
			my $fraction = ($jd - $first->[1]) / 
			                     ($last->[1] - $first->[1]);

			# use the calculated fraction to interpolate
			# the other ephemeris values

			$eph_line = populate_eph( $first, $last, $fraction);

			# set values 1 and 2 by hand, since we
			# already know them more precisely than we
			# can calculate them
			$eph_line->[1] = $jd;
			$eph_line->[2] = $jd - int($jd);
			
			
			return $eph_line;  # quit the subroutine

		    }
		}
		
	    }
	}
	
    }
}


# populate_eph
#
# Description: internal subroutine used by &interpolate
#     and &change_time to interpolate ephemeris values,
#     accounting for roll-over points in the angles
# Arguments: first ephemeris line, last ephemeris line,
#     fraction of distance between first and last ephemeris
#     values -- for &interpolate, this depends on the JD given, 
#     while for &change_time, it is always .5.
# Output: an ephemeris line (in reference to array form, with
#     fractional JD added to whole JD)

sub populate_eph {

    my $first    = $_[0];
    my $last     = $_[1];
    my $fraction = $_[2];

    my @eph_line;

    # the following is for ephemeris fields that
    # do not roll over (ie. elapsed time, JD,
    # fractional JD, Earth Dec, Earth distance,
    # Moon Dec, Moon distance, and Sun Dec

    for my $k (0,1,2,5,6,8,9,11) {
	$eph_line[$k] =   $fraction * ($last->[$k] - $first->[$k])
	                + $first->[$k];
    }


    # the following is a correction for 
    # interpolation with fields that do roll over:
    #    mean anomaly rolls over from 360->0
    #        earth RA rolls over from 360->0
    #         moon RA rolls over from 360->0
    #          sun RA rolls over from 180->-180

    for my $l (3,4,7,10) {
	
	# the distance in degree-space between the angle
	# values in the the two lines will be the shortest
	# of the following differences:
	
	my @distance;
	$distance[0] = abs(  $last->[$l]      - $first->[$l] );
	$distance[1] = abs( ($last->[$l]+360) - $first->[$l] );
	$distance[2] = abs( ($last->[$l]-360) - $first->[$l] );
	
	my @sort_distance = sort { $a <=> $b } @distance;
	
	
	# figure out whether there was a roll-over, and
	# if so, in which direction:

	my $rolled_down = 0;
	my $rolled_up   = 0;
	if ($sort_distance[0] == $distance[1]) {
	    $rolled_down++;
	} elsif ($sort_distance[0] == $distance[2]) {
	    $rolled_up++;
	}
	
	# Since values can be going up or down in the
	# ephemeris, we will want to add the distance
	# if we are going up, and subtract the distance
	# if we are going down.  Also, we know that if
	# we have rolled down (ie. the last value is 
	# higher than the first, but appears to be lower),
	# then we want to add the distance; if we have
	# rolled up, we know we want to subtract the
	# distance.

	my $distance;
	if ($rolled_down) {
	    $distance =  $sort_distance[0];
	} elsif ($rolled_up) {
	    $distance = -$sort_distance[0];
	} else {
	    if ( $last->[$l] >= $first->[$l] ) {
		$distance =  $sort_distance[0];
	    } else {
		$distance = -$sort_distance[0];
	    } 
	}				
	

	# Calculate the actual value:

	my $value = $first->[$l] + $fraction * $distance;
	

	# correct the value so that it fits within the
	# allowed values for that field:

	if ( $l == 10 ) { # for Sun RA
	    $value -= 360 if $value >  180;
	    $value += 360 if $value < -180;
	} else {
	    $value -= 360 if $value > 360;
	    $value += 360 if $value < 0;
	}
	
	# put the value in the ephemeris line array:
	$eph_line[$l] = $value;
    }
    
    return \@eph_line;

}
   


# eci
#
# Description: converts RA and Dec from decimal degrees
#     to ECI (earth-centered inertial) coordinates.
# Arguments: ra, dec in degrees
# Output: reference to array containing normalized ECI 
#     (cartesian) position vector 

sub eci {

    # convert to radians
    my $ra  = $_[0] * $deg2rad;
    my $dec = $_[1] * $deg2rad;
    
    my @eci;
    my $polar = ($pi/2.0) - $dec;

    $eci[0] = sin( $polar ) * cos( $ra );
    $eci[1] = sin( $polar ) * sin( $ra );
    $eci[2] = cos( $polar );

    return \@eci;
}


# roll
# Description: Calculates the nominal roll angle and maximum
#     off-nominal roll.
# Arguments: ra, dec (in degrees), jd
# Output: nominal roll angle (deg), max. off-nominal roll (deg)

sub roll {

    my ( $ra, $dec, $jd, $orbits ) = @_;
    
    # convert to radians:
    my $radra  = $ra  * $deg2rad;
    my $raddec = $dec * $deg2rad;

    my $eph_line = interpolate( $jd, $orbits );
    my $sunx = eci( $eph_line->[10], $eph_line->[11] );

    # Pat Slane's components for calculating nominal roll
    my ( $t1, $t2, $t3, $eta, $phi);

    $t1 = 0.0;
    $t2 = (
	    -$sunx->[0] * cos($radra) 
	                * sin($raddec) 
	  )
	    - (
	        $sunx->[1] * sin($radra) 
	                   * sin($raddec) 
	      )
	    + 
	      ( $sunx->[2] * cos($raddec) );


    $t3 = (-$sunx->[0] * sin($radra)) + ($sunx->[1] * cos($radra));
    $eta = atan2( $t2, $t3);

       # The acos term here is always Pi/2, but is calculated
       # here because that's how Pat wrote it
    $phi = ( $eta + acos( -$t1 / sqrt( $t2 * $t2 + $t3 * $t3 ) ) ) / $deg2rad;
    $phi += 360.0 if ( $phi < 0.0 );



    # now find the tolerance on the roll angle
    my $pitch_angle = pitch( $ra, $dec, $jd, $orbits );

    my $NVALS = 31; # the number of values in @RolDeviation


    # the following are the latest numbers from FOT MP -- 
    # the first value is the pitch angle, the second is the
    # maximum off-nominal roll.  This table will have to
    # be modified if these numbers change.  To find the 
    # latest values, ask the FOT for the latest CONSTRAINTS
    # file (as of 5/8/02, the latest is CONSTRAINTS_15APR02)
    # and use the ODB_SUNTOX_ANG values as the first field
    # in the following array, and the ODB_MAX_ROLL_DEV values
    # as the second field.

    my @RolDeviation = ( 
			 [46.000, 0.0000], [46.40, 2.0520],
			 [46.800, 3.1110], [47.20, 3.9420],
			 [47.500, 4.5010], [48.00, 5.1920],
			 [48.500, 5.7710], [49.00, 6.2680],
			 [49.500, 6.7260], [50.00, 7.1420],
			 [55.000, 10.043], [60.00, 11.753],
			 [65.000, 12.894], [70.00, 13.659],
			 [75.000, 12.894], [80.00, 11.753],
			 [85.000, 10.043], [122.0, 9.6000],
			 [127.00, 8.5000], [132.0, 7.7750],
			 [137.08, 7.3340], [140.0, 7.7750],
			 [145.00, 8.6970], [150.0, 9.9790],
			 [153.00, 11.021], [157.0, 12.785],
			 [160.00, 14.628], [163.0, 17.153],
			 [166.00, 19.999], [170.0, 19.999],
			 [180.00, 19.999]    
		       );


    # for arbitrary pitch angle, take the tolerance that
    # is given for the nearest pitch angle less than or
    # equal to it

    my $tol = 0;
    for ( my $i = 0; $i < $NVALS-1; $i++ ) {
	if (
	     $pitch_angle >= $RolDeviation[$i]->[0]
	    and 
	     $pitch_angle < $RolDeviation[$i+1]->[0]
	   ) 
	{
	    $tol = $RolDeviation[$i]->[1];
	    last;
	}
    }

    return [ $phi, $tol ];
}

# pitch
#
# Description: calculates Chandra's pitch angle for a 
#     given RA/Dec
# Arguments: ra, dec in degrees, jd, orbits ref.
# Output: angle between sun and target (in degrees)

sub pitch {

    my ( $ra, $dec, $jd, $orbits ) = @_;
    
    my $eph_line = interpolate( $jd, $orbits );
    my $sunx = eci( $eph_line->[10], $eph_line->[11] );
    my $targ = eci( $ra, $dec );

    my ( $polar, $dot_product, $pitch_angle);

    for ( my $i=0; $i < 3; $i++ ) {
	$dot_product += $sunx->[$i] * $targ->[$i];
    }

    $pitch_angle = acos( $dot_product ) / $deg2rad;

    return $pitch_angle;
}


# low_vis_reason
#
# Description: This subroutine returns a hash of date and 
#     visibility reason pairs for the total time in the orbits
#     containing and in between the two jds given.
# Arguments: RA (deg), Dec (deg), jd1, jd2, reference to array 
#     containing ephemeris lines (from &parse_ephem)
# Output: hash of date and vis reason pairs

sub low_vis_reason {
    my $ra         = $_[0];
    my $dec        = $_[1];
    my $jd         = $_[2];
    my $jd2        = $_[3];
    my $orbits_ref = $_[4];

    my @orbits = @{$orbits_ref};

    my ($start_orbit, $end_orbit);
    #make sure the arguments are in order
    if ($jd > $jd2) {
	print "Starting JD $jd is later than ending JD $jd. Switching ..\n";
	my $temp = $jd;
	$jd = $jd2;
	$jd2 = $jd;
    }

    #make sure the dates are within the ephemeris
    if ( $jd < $orbits[0]->[0]->[1] ) {
	croak "JD $jd is earlier than earliest time in ephemeris\n";
    } elsif ( $jd2 > $orbits[-1]->[-1]->[1] ) {
	croak "JD $jd2 is later than latest time in ephemeris\n";
    } else {

	$start_orbit = 0;
	$end_orbit = 0;

	# find the orbit containing $jd:
	for ( my $j = 0; $j < @orbits; $j++ ) {
	    if ( $jd >= $orbits[$j]->[0]->[1] and
		 $jd <  $orbits[$j]->[-1]->[1]) {

		$start_orbit = $j;
		
		for (my $k = $start_orbit; $k < @orbits; $k++ ) {
		    if ( $jd2 >= $orbits[$k]->[0]->[1] and
			 $jd2 <  $orbits[$k]->[-1]->[1] ) {

			$end_orbit = $k;
			last;
		    }
		}
		last;
	    }
	} #end for j loop
    } #end else

    
    my $init_vis    = vis( $ra, $dec, $orbits[ $start_orbit ]->[0] );
    # this is the total visibility at the beginning of the orbit
  
    my %reason; # this will hold the jd for sun, earth, and moon block
    
    # initialize with first line of the orbit:
    my $start_time = $orbits[ $start_orbit ]->[0]->[1];
    my $start_line = $orbits[ $start_orbit ]->[0];
    

    for (my $orb=$start_orbit; $orb<=$end_orbit; $orb++ ) {
	# step through the orbit, line by line, looking for low vis
	for my $next_line ( @{ $orbits[ $orb ] } ) {
	    
	    # previously, this routine was using a reference, which
	    # cause the global $orbits structure to get modified.
	    # This didn't seem intentional, and broke some things
	    # in random ways, so this hack makes a local copy of the 
	    # array and references it, rather than update the array
	    # for the passed reference.
	    my @local_next_line = @$next_line;
	    my $local_next_ref = \@local_next_line;
	    
	    my $next_vis  = vis( $ra, $dec, $local_next_ref );
	    my $next_time = $local_next_ref->[1];
	    
	    unless ( $next_vis->[0] == $init_vis->[0] ) {
		$local_next_ref = MP::Visibility::change_time( $ra, $dec, $init_vis, 
							      $start_line, $local_next_ref );
		# this calculates the exact point in 
		# the orbit (to within 10 minutes) when
		# the visibility switches from 0 to 1 or
		# vice versa
		
		$next_time = $local_next_ref->[1];
	    }
	    
	    if ($init_vis->[0] == 0) {
		#figure out the reason it is blocked
		#and store it to the hash e.g. $reason{$jd}='s' for sun

		if ($init_vis->[1] == 0 ) {
		    $reason{$start_time} = 's';
		}
		if ( $init_vis->[2] == 0 ) {
		    $reason{$start_time} = 'e';
		}
		if ( $init_vis->[3] == 0 ) {
		    $reason{$start_time} = 'm';
		}
		if ( $init_vis->[4] == 0 ) {
		    $reason{$start_time} = 'r';
		}
	    }
	    # make the 'next' values the new 'start' values:
	    $init_vis = $next_vis;
	    $start_time = $next_time;
	    $start_line = $local_next_ref;
	}
    }	    
    return  %reason; #key value pairs of jd of low vis and cause
}


1;

__END__

