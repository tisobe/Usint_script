package MP::SOE;

=head1 NAME

MP::SOE

=head1 PURPOSE

A Perl Extension  to parse a Chandra SOE file.

=head1 SYNOPSIS

  use MP::SOE;

  $soe = read_soe( $soefile );
  foreach $record (@$soe){
     $type = $record->{'odb_rec_type'};
     if( $type eq 'OBS' || $type eq 'CAL' ){
        print "$record->{'odb_req_id'}\n";
     }
  }

=head1 DESCRIPTION

This Perl Module provides the function " read_soe() ", which parses an OFLS returned scheduled OR/ER data file, and populates a data structure with its contents.

The routine read_soe() takes the name of the soe as input, and returns a reference to an array. Each array element contains a reference to a hash, whose keys are the tags specified in OP-19. The hash values are scalars for single valued elements, and array references for multivalued elements (ie obd_target_quat, which has four elements).

Note that read_soe() handles the opening and closing of the SOE data file, so only the name need be passed to the routine (as opposed to passing a file handle)


=head2 EXPORTS
    
    read_soe()

=head2 Methods

=over 8

=item read_soe

I<Usage>: 

    my $soe_ref = read_soe( $soe );

I<Provides>: Given the name of the soe as input it returns a reference to an array. Each array element contains a reference to a hash, whose keys are the tags specified in OP-19. The hash values are scalars for single valued elements, and array references for multivalued elements (ie obd_target_quat, which has four elements).

I<Arguments>:

    $soe = Soe filename.

I<Output>:

Reference to an array. Each array element contains a reference to a hash, whose keys are the tags specified in OP-19.

I<Examples>:
    
    my $soe_ref = read_soe( $soe );

    my @obsids;
    for my $record (@$soe_ref){
        my $type = $record->{'odb_rec_type'};

        if ( $type eq 'OBS' ) {
            my $obsid = $record->{'odb_req_id'};
        }
    }

=back


=head1 EXAMPLES

    my $soe_ref = read_soe( $soe );

    my @obsids;
    for my $record (@$soe_ref){
        my $type = $record->{'odb_rec_type'};

        if ( $type eq 'OBS' ) {
            my $obsid = $record->{'odb_req_id'};
        }
    }

=head1 NOTES

Values in these constants and tags in following arrays from OP-19 of 12-Aug-1999 

  my $HDRLEN = 490;
  my $DATLEN = 3363;
  my $VISLEN = 40;
  my $IDLLEN = 45;
  my $SSRLEN = 45;
  my $CMTLEN = 91;
  my $SIRLEN = 94;
  
           # name              length dim1 dim2
  my @HDR =  (['odb_sched_id',        8,    1,  1],
	    ['odb_prev_sched_id',   8,    1,  1],
	    ['odb_orlist_id',      11,    1,  1],
	    ['odb_erlist_id',     110,   10,  1],
	    ['odb_sched_obj',       2,    1,  1],
	    ['odb_start_time',     21,    1,  1],
	    ['odb_end_time',       21,    1,  1],
	    ['odb_sched_time',     17,    1,  1],
	    ['odb_or_list_name',   25,    1,  1],
	    ['odb_or_list_update', 21,    1,  1],
	    ['odb_tot_obs_time',   17,    1,  1],
	    ['odb_tot_src_time',   17,    1,  1],
	    ['odb_tot_add_time',   17,    1,  1],
	    ['odb_frac_add_time',  10,    1,  1],
	    ['odb_tot_sub_time',   17,    1,  1],
	    ['odb_frac_sub_time',  10,    1,  1],
	    ['odb_tot_slew_time',  17,    1,  1],
	    ['odb_frac_slew_time', 10,    1,  1],
	    ['odb_tot_acq_time',   17,    1,  1],
	    ['odb_frac_acq_time',  10,    1,  1],
	    ['odb_tot_idle_time',  17,    1,  1],
	    ['odb_frac_idle_time', 10,    1,  1],
	    ['odb_tot_rad_time',   17,    1,  1],
	    ['odb_frac_rad_time',  10,    1,  1],
	    ['odb_tot_ecl_time',   17,    1,  1],
	    ['odb_frac_ecl_time',  10,    1,  1],
	    ['odb_av_efficiency',  10,    1,  1],
	    ['odb_total_gas_used', 10,    1,  1],
	    );

           # name              length dim1 dim2
  my @DAT =  (['odb_target_quat',    40,    4,  1],
	    ['odb_sstart_ang',     10,    1,  1],
	    ['odb_send_ang',       10,    1,  1],
	    ['pdb_sclose_ang',     10,    1,  1],
	    ['pdb_estart_ang',     10,    1,  1],
	    ['pdb_eend_ang',       10,    1,  1],
	    ['pdb_eclose_ang',     10,    1,  1],
	    ['pdb_mstart_ang',     10,    1,  1],
	    ['pdb_mend_ang',       10,    1,  1],
	    ['pdb_mclose_ang',     10,    1,  1],
	    ['pdb_pstart_ang',    200,   20,  1],
	    ['pdb_pend_ang',      200,   20,  1],
	    ['pdb_pclose_ang',    200,   20,  1],
	    ['pdb_kstart_ang',    200,   20,  1],
	    ['pdb_kend_ang',      200,   20,  1],
	    ['pdb_kclose_ang',    200,   20,  1],
	    ['odb_acq_stars',     160,    8,  2],
	    ['odb_guide_images',  240,    8,  3],
	    ['odb_fom',            10,    1,  1],
	    ['odb_roll_ang',       10,    1,  1],
	    ['odb_slew_ang',       10,    1,  1],
	    ['odb_instance_num',    2,    1,  1],
	    ['odb_req_id',          8,    1,  1],
	    ['odb_obs_id',          5,    1,  1],
	    ['odb_acq_id',         80,    8,  1],
	    ['odb_guide_id',       80,    8,  1],
	    ['odb_obs_start_time', 21,    1,  1],
	    ['odb_obs_end_time',   21,    1,  1],
	    ['odb_obs_dur',        17,    1,  1],
	    ['odb_obs_dur_extra',  17,    1,  1],
	    ['odb_mstart_time',    21,    1,  1],
	    ['odb_mend_time',      21,    1,  1],
	    ['odb_trans_stime',    21,    1,  1],
	    ['odb_trans_etime',    21,    1,  1],
	    ['odb_trans_wetime',   21,    1,  1],
	    ['odb_sclose_time',    21,    1,  1],
	    ['odb_eclose_time',    21,    1,  1],
	    ['odb_mclose_time',    21,    1,  1],
	    ['odb_pclose_time',   420,   20,  1],
	    ['odb_pclose_id',     160,   20,  1],
	    ['odb_kclose_time',   420,   20,  1],
	    ['odb_kclose_id',     160,   20,  1],
	    );

  my @SIR = (['odb_rec_id',          3,    1,  1],
	   ['odb_instance_num',    2,    1,  1],
	   ['odb_req_id',          8,    1,  1],
	   ['odb_obs_id',          5,    1,  1],
	   ['odb_obs_start_time', 21,    1,  1],
	   ['odb_obs_end_time',   21,    1,  1],
	   ['odb_obs_dur',        17,    1,  1],
	   ['odb_obs_dur_extra',  17,    1,  1],
	   ); 

            # name              length dim1 dim2
  my @VIS =  (['odb_obs_id',          8,    1,  1],
	    ['odb_vis_type',        8,    1,  1],
	    ['odb_event_time',     21,    1,  1],
	    );

            # name              length dim1 dim2
  my @IDL =  (['odb_istart_time',    21,    1,  1],
	    ['odb_iend_time',      21,    1,  1],
	    );

            # name              length dim1 dim2
  my @SSR =  (['odb_start_time',     21,    1,  1],
	    ['odb_end_time',       21,    1,  1],
	    );

            # name              length dim1 dim2
  my @CMT =  (['odb_obs_id',          8,    1,  1],
	    ['odb_comment_file',   80,    1,  1],
	    );

  my %RecDef  = (
	       HDR => \@HDR,  # header record

	       OBS => \@DAT,  # data record
	       CAL => \@DAT,
               SIR => \@SIR,

	       VIS => \@VIS,  # visibility record

	       IDL => \@IDL,  # idle record

	       PBK => \@SSR,  # SSR support record
	       COM => \@SSR,
	       MOM => \@SSR,
	       TLM => \@SSR,
	       ACT => \@SSR,

	       CMT => \@CMT,  # comment record
	       ERR => \@CMT,
	       );

  my %RecSize = (
	       HDR => $HDRLEN,  # header record

	       OBS => $DATLEN,  # data record
	       CAL => $DATLEN,
               SIR => $SIRLEN,

	       VIS => $VISLEN,  # visibility record

	       IDL => $IDLLEN,  # idle record

	       PBK => $SSRLEN,  # SSR support record
	       COM => $SSRLEN,
	       MOM => $SSRLEN,
	       TLM => $SSRLEN,
	       ACT => $SSRLEN,

	       CMT => $CMTLEN,  # comment record
	       ERR => $CMTLEN,
	       );


=head1 DEPENDENCIES

  use strict;
  use warnings;
  require Exporter;
  use Carp;
  use FileHandle;

=head1 VERSION

$Revision: 1.3 $

=head1 AUTHOR

Author:  K Eriksen; rel 7/12/2001

  Last Update:    $Date: 2008/03/14 19:01:28 $ 
  Last Update by: $Author: kkingsbury $


=head1 HISTORY

=over 8

=item Ver: 1.3

- Updated to be able to parse the new SIR records in the upcoming OFLS changes.

kkingsbury - 03/14/2008


=item Ver: 1.2

- Added POD, put under CVS Control.

kkingsbury - 11/20/2006


=item Ver: 1.1

Initial revision

K Eriksen - 7/12/2001 

=back

=cut
########################################################################
#                        START CODE                                    #
########################################################################

require 5.005_62;
use strict;
use warnings;

require Exporter;

our @ISA = qw(Exporter);
our @EXPORT = qw( &read_soe );
	
our $VERSION = '1.3';

use Carp;
use FileHandle;

#################################################
#                                               #
# values in these constants and tags            #
# in following arrays from OP-19 of 12-Aug-1999 #
#                                               #
#################################################
my $HDRLEN = 490;
my $DATLEN = 3363;
my $VISLEN = 40;
my $IDLLEN = 45;
my $SSRLEN = 45;
my $CMTLEN = 91;
my $SIRLEN = 94;

           # name              length dim1 dim2
my @HDR =  (['odb_sched_id',        8,    1,  1],
	    ['odb_prev_sched_id',   8,    1,  1],
	    ['odb_orlist_id',      11,    1,  1],
	    ['odb_erlist_id',     110,   10,  1],
	    ['odb_sched_obj',       2,    1,  1],
	    ['odb_start_time',     21,    1,  1],
	    ['odb_end_time',       21,    1,  1],
	    ['odb_sched_time',     17,    1,  1],
	    ['odb_or_list_name',   25,    1,  1],
	    ['odb_or_list_update', 21,    1,  1],
	    ['odb_tot_obs_time',   17,    1,  1],
	    ['odb_tot_src_time',   17,    1,  1],
	    ['odb_tot_add_time',   17,    1,  1],
	    ['odb_frac_add_time',  10,    1,  1],
	    ['odb_tot_sub_time',   17,    1,  1],
	    ['odb_frac_sub_time',  10,    1,  1],
	    ['odb_tot_slew_time',  17,    1,  1],
	    ['odb_frac_slew_time', 10,    1,  1],
	    ['odb_tot_acq_time',   17,    1,  1],
	    ['odb_frac_acq_time',  10,    1,  1],
	    ['odb_tot_idle_time',  17,    1,  1],
	    ['odb_frac_idle_time', 10,    1,  1],
	    ['odb_tot_rad_time',   17,    1,  1],
	    ['odb_frac_rad_time',  10,    1,  1],
	    ['odb_tot_ecl_time',   17,    1,  1],
	    ['odb_frac_ecl_time',  10,    1,  1],
	    ['odb_av_efficiency',  10,    1,  1],
	    ['odb_total_gas_used', 10,    1,  1],
	    );





           # name              length dim1 dim2
my @DAT =  (['odb_target_quat',    40,    4,  1],
	    ['odb_sstart_ang',     10,    1,  1],
	    ['odb_send_ang',       10,    1,  1],
	    ['pdb_sclose_ang',     10,    1,  1],
	    ['pdb_estart_ang',     10,    1,  1],
	    ['pdb_eend_ang',       10,    1,  1],
	    ['pdb_eclose_ang',     10,    1,  1],
	    ['pdb_mstart_ang',     10,    1,  1],
	    ['pdb_mend_ang',       10,    1,  1],
	    ['pdb_mclose_ang',     10,    1,  1],
	    ['pdb_pstart_ang',    200,   20,  1],
	    ['pdb_pend_ang',      200,   20,  1],
	    ['pdb_pclose_ang',    200,   20,  1],
	    ['pdb_kstart_ang',    200,   20,  1],
	    ['pdb_kend_ang',      200,   20,  1],
	    ['pdb_kclose_ang',    200,   20,  1],
	    ['odb_acq_stars',     160,    8,  2],
	    ['odb_guide_images',  240,    8,  3],
	    ['odb_fom',            10,    1,  1],
	    ['odb_roll_ang',       10,    1,  1],
	    ['odb_slew_ang',       10,    1,  1],
	    ['odb_instance_num',    2,    1,  1],
	    ['odb_req_id',          8,    1,  1],
	    ['odb_obs_id',          5,    1,  1],
	    ['odb_acq_id',         80,    8,  1],
	    ['odb_guide_id',       80,    8,  1],
	    ['odb_obs_start_time', 21,    1,  1],
	    ['odb_obs_end_time',   21,    1,  1],
	    ['odb_obs_dur',        17,    1,  1],
	    ['odb_obs_dur_extra',  17,    1,  1],
	    ['odb_mstart_time',    21,    1,  1],
	    ['odb_mend_time',      21,    1,  1],
	    ['odb_trans_stime',    21,    1,  1],
	    ['odb_trans_etime',    21,    1,  1],
	    ['odb_trans_wetime',   21,    1,  1],
	    ['odb_sclose_time',    21,    1,  1],
	    ['odb_eclose_time',    21,    1,  1],
	    ['odb_mclose_time',    21,    1,  1],
	    ['odb_pclose_time',   420,   20,  1],
	    ['odb_pclose_id',     160,   20,  1],
	    ['odb_kclose_time',   420,   20,  1],
	    ['odb_kclose_id',     160,   20,  1],
	    );

my @SIR = (['odb_rec_id',          3,    1,  1],
	   ['odb_instance_num',    2,    1,  1],
	   ['odb_req_id',          8,    1,  1],
	   ['odb_obs_id',          5,    1,  1],
	   ['odb_obs_start_time', 21,    1,  1],
	   ['odb_obs_end_time',   21,    1,  1],
	   ['odb_obs_dur',        17,    1,  1],
	   ['odb_obs_dur_extra',  17,    1,  1],
	   );


            # name              length dim1 dim2
my @VIS =  (['odb_obs_id',          8,    1,  1],
	    ['odb_vis_type',        8,    1,  1],
	    ['odb_event_time',     21,    1,  1],
	    );

            # name              length dim1 dim2
my @IDL =  (['odb_istart_time',    21,    1,  1],
	    ['odb_iend_time',      21,    1,  1],
	    );

            # name              length dim1 dim2
my @SSR =  (['odb_start_time',     21,    1,  1],
	    ['odb_end_time',       21,    1,  1],
	    );

            # name              length dim1 dim2
my @CMT =  (['odb_obs_id',          8,    1,  1],
	    ['odb_comment_file',   80,    1,  1],
	    );

my %RecDef  = (
	       HDR => \@HDR,  # header record

	       OBS => \@DAT,  # data record
	       CAL => \@DAT,
	       SIR => \@SIR,

	       VIS => \@VIS,  # visibility record

	       IDL => \@IDL,  # idle record

	       PBK => \@SSR,  # SSR support record
	       COM => \@SSR,
	       MOM => \@SSR,
	       TLM => \@SSR,
	       ACT => \@SSR,

	       CMT => \@CMT,  # comment record
	       ERR => \@CMT,
	       );

my %RecSize = (
	       HDR => $HDRLEN,  # header record

	       OBS => $DATLEN,  # data record
	       CAL => $DATLEN,
	       SIR => $SIRLEN,

	       VIS => $VISLEN,  # visibility record

	       IDL => $IDLLEN,  # idle record

	       PBK => $SSRLEN,  # SSR support record
	       COM => $SSRLEN,
	       MOM => $SSRLEN,
	       TLM => $SSRLEN,
	       ACT => $SSRLEN,

	       CMT => $CMTLEN,  # comment record
	       ERR => $CMTLEN,
	       );

sub read_soe {
    my $file = shift;

    my $soe = new FileHandle;
    $soe->open($file) or
	croak "Could not open $file for reading: $!\n";
    
    my $rec_type;
    my %SoeRec;
    my @soe;

    my $nread;
    while( 3 == ( $nread = sysread( $soe, $rec_type, 3 ) ) ){

	croak( "unknown record type: $rec_type\n" )
	    unless exists $RecDef{$rec_type};
	
	%SoeRec = read_record($soe,
				 $RecDef{$rec_type},
				 $RecSize{$rec_type} - 3);

	$SoeRec{odb_rec_type} = $rec_type;
	push @soe, { %SoeRec };
    }
    $soe->close;

    warn( "trailing garbage; ignored: $rec_type\n" )
      if ( $nread );

    return \@soe;
}

sub read_record {
    my ($soe,$def,$len) = @_;

    my ($record,$name,$offset,$value,$i,$dims,$dim1,$dim2,
	$svalue,$irec,$j,$k,$tag,@rec,
	%SoeRec);

    croak( "incomplete record: $record\n" )
	unless $len == sysread( $soe, $record, $len );

    $offset = 0;
    $i = 0;
    foreach $name (@$def){
	$value = substr($record, $offset, $def->[$i][1]);
	$dim1 = $def->[$i][2];
	$dim2 = $def->[$i][3];
	$dims = $dim1 * $dim2;
	$tag = $def->[$i][0];

	if( $dims == 1 ){
	    $SoeRec{$tag} = $value;
	}
	else {
	    my ($j,$k);
	    my @rec = ();
	    my $joffset = 0;
	    my $jrecsize = ($def->[$i][1])/($dims);
	    my $koffset = 0;
	    for($j = 1; $j <= $dim1 ; $j++){		
		if( $dim2 == 1 ){
		    push @rec, substr($value, $joffset, $jrecsize);
		} else{
		    my @krec = ();
		    for($k = 1; $k <= $dim2; $k++){
			my $krec = substr($value, $koffset, $jrecsize);
			push @krec, $krec;
			$koffset += $jrecsize;
		    }
		    push @rec, [ @krec ];
		}
		$joffset += $jrecsize;
	    }
	    $SoeRec{$tag} = [ @rec ];
	}
	$offset += $def->[$i][1];
        $i++;
    }    

    return %SoeRec;
}

1;


1;
__END__

